import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
import yaml
import os
import time
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split

from models.image2wave import Image2Wave
from data.synth_dataset import (
    SynthECGDataset, 
    get_synth_transforms,
    generate_synthetic_ecg_signals
)

def load_config(path='configs/config.yaml'):
    """加载配置文件"""
    with open(path, 'r') as f:
        return yaml.safe_load(f)

def setup_seed(seed=42):
    """设置随机种子"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def create_dataloaders(cfg, num_samples=10000):
    """创建数据加载器"""
    # 生成合成数据
    print("Generating synthetic ECG signals...")
    signals = generate_synthetic_ecg_signals(
        num_samples=num_samples,
        duration=4,
        fs=500
    )
    
    # 划分训练集和验证集
    train_signals, val_signals = train_test_split(
        signals, 
        test_size=0.1, 
        random_state=42
    )
    
    # 创建数据集
    transforms = get_synth_transforms()
    
    train_dataset = SynthECGDataset(
        train_signals,
        transforms=transforms
    )
    
    val_dataset = SynthECGDataset(
        val_signals,
        transforms=None  # 验证集不使用数据增强
    )
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=cfg['train']['batch_size'],
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=cfg['train']['batch_size'],
        shuffle=False,
        num_workers=2,
        pin_memory=True
    )
    
    return train_loader, val_loader

def dice_loss(pred, target, smooth=1e-6):
    """Dice损失"""
    pred = torch.sigmoid(pred)
    intersection = (pred * target).sum()
    union = pred.sum() + target.sum()
    dice = (2. * intersection + smooth) / (union + smooth)
    return 1 - dice

def compute_loss(mask_logits, pred_seq, target_mask, target_seq, cfg):
    """计算总损失"""
    # 掩码损失 (BCE + Dice)
    bce_loss = nn.BCEWithLogitsLoss()(mask_logits, target_mask)
    
    # 创建目标掩码（基于y_target）
    B, H, W = target_mask.shape
    target_mask = torch.zeros(B, 1, H, W, device=mask_logits.device)
    
    # 对于每个样本，在y_target位置创建掩码
    for i in range(B):
        for j in range(W):
            y = int(round(target_seq[i, j].item()))
            if 0 <= y < H:
                target_mask[i, 0, y, j] = 1.0
    
    dice = dice_loss(mask_logits, target_mask)
    mask_loss = bce_loss + dice
    
    # 序列损失 (Smooth L1)
    seq_loss = nn.SmoothL1Loss()(pred_seq, target_seq)
    
    # 总损失
    total_loss = mask_loss * cfg['train']['mask_loss_weight'] + \
                 seq_loss * cfg['train']['seq_loss_weight']
    
    return total_loss, mask_loss, seq_loss

def train_one_epoch(model, loader, optimizer, device, cfg, scaler):
    """训练一个epoch"""
    model.train()
    running_loss = 0.0
    running_mask_loss = 0.0
    running_seq_loss = 0.0
    
    pbar = tqdm(loader, desc='Training')
    
    for batch in pbar:
        images = batch['image']
        y_target = batch['y_target']
        
        # 数据预处理
        images_t = torch.tensor(images).permute(0, 3, 1, 2).float().to(device) / 255.0
        y_t = torch.tensor(y_target).float().to(device)
        
        # 创建目标掩码（基于y_target）
        B, H, W = images_t.shape[0], images_t.shape[2], images_t.shape[3]
        target_mask = torch.zeros(B, 1, H, W, device=device)
        
        # 清空梯度
        optimizer.zero_grad()
        
        # 混合精度训练
        with autocast():
            # 前向传播
            mask_logits, pred_seq = model(images_t)
            
            # 计算损失
            loss, mask_loss, seq_loss = compute_loss(
                mask_logits, pred_seq, target_mask, y_t, cfg
            )
        
        # 反向传播
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        
        # 更新统计
        running_loss += loss.item()
        running_mask_loss += mask_loss.item()
        running_seq_loss += seq_loss.item()
        
        # 更新进度条
        pbar.set_postfix({
            'loss': running_loss / (pbar.n + 1),
            'mask_loss': running_mask_loss / (pbar.n + 1),
            'seq_loss': running_seq_loss / (pbar.n + 1)
        })
    
    return {
        'loss': running_loss / len(loader),
        'mask_loss': running_mask_loss / len(loader),
        'seq_loss': running_seq_loss / len(loader)
    }

def validate(model, loader, device, cfg):
    """验证"""
    model.eval()
    running_loss = 0.0
    running_mask_loss = 0.0
    running_seq_loss = 0.0
    
    with torch.no_grad():
        pbar = tqdm(loader, desc='Validating')
        
        for batch in pbar:
            images = batch['image']
            y_target = batch['y_target']
            
            # 数据预处理
            images_t = torch.tensor(images).permute(0, 3, 1, 2).float().to(device) / 255.0
            y_t = torch.tensor(y_target).float().to(device)
            
            # 创建目标掩码
            B, H, W = images_t.shape[0], images_t.shape[2], images_t.shape[3]
            target_mask = torch.zeros(B, 1, H, W, device=device)
            
            # 前向传播
            mask_logits, pred_seq = model(images_t)
            
            # 计算损失
            loss, mask_loss, seq_loss = compute_loss(
                mask_logits, pred_seq, target_mask, y_t, cfg
            )
            
            # 更新统计
            running_loss += loss.item()
            running_mask_loss += mask_loss.item()
            running_seq_loss += seq_loss.item()
            
            pbar.set_postfix({
                'loss': running_loss / (pbar.n + 1)
            })
    
    return {
        'loss': running_loss / len(loader),
        'mask_loss': running_mask_loss / len(loader),
        'seq_loss': running_seq_loss / len(loader)
    }

def save_checkpoint(model, optimizer, epoch, val_loss, cfg):
    """保存检查点"""
    os.makedirs(cfg['train']['ckpt_dir'], exist_ok=True)
    
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'val_loss': val_loss,
        'config': cfg
    }
    
    torch.save(checkpoint, os.path.join(cfg['train']['ckpt_dir'], f'checkpoint_epoch_{epoch}.pth'))
    
    # 保存最佳模型
    best_path = os.path.join(cfg['train']['ckpt_dir'], 'best_model.pth')
    if not os.path.exists(best_path) or val_loss < torch.load(best_path)['val_loss']:
        torch.save(checkpoint, best_path)
        print(f"New best model saved with val loss: {val_loss:.4f}")

def main():
    # 加载配置
    cfg = load_config()
    
    # 设置随机种子
    setup_seed(cfg.get('seed', 42))
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 创建数据加载器
    train_loader, val_loader = create_dataloaders(cfg, num_samples=10000)
    
    # 创建模型
    model = Image2Wave(seq_len=1024).to(device)
    
    # 创建优化器
    optimizer = optim.AdamW(
        model.parameters(),
        lr=cfg['train']['lr'],
        weight_decay=cfg.get('train', {}).get('weight_decay', 1e-4)
    )
    
    # 学习率调度器
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=0.5,
        patience=5,
        verbose=True
    )
    
    # 混合精度训练
    scaler = GradScaler()
    
    # 训练配置
    num_epochs = cfg['train']['epochs']
    best_val_loss = float('inf')
    
    print(f"Starting training for {num_epochs} epochs...")
    
    # 训练循环
    for epoch in range(num_epochs):
        print(f"\nEpoch {epoch + 1}/{num_epochs}")
        print("-" * 50)
        
        # 训练
        train_metrics = train_one_epoch(model, train_loader, optimizer, device, cfg, scaler)
        print(f"Train Loss: {train_metrics['loss']:.4f}, "
              f"Mask Loss: {train_metrics['mask_loss']:.4f}, "
              f"Seq Loss: {train_metrics['seq_loss']:.4f}")
        
        # 验证
        val_metrics = validate(model, val_loader, device, cfg)
        print(f"Val Loss: {val_metrics['loss']:.4f}, "
              f"Mask Loss: {val_metrics['mask_loss']:.4f}, "
              f"Seq Loss: {val_metrics['seq_loss']:.4f}")
        
        # 更新学习率
        scheduler.step(val_metrics['loss'])
        
        # 保存检查点
        save_checkpoint(model, optimizer, epoch + 1, val_metrics['loss'], cfg)
        
        # 更新最佳验证损失
        if val_metrics['loss'] < best_val_loss:
            best_val_loss = val_metrics['loss']
    
    print(f"\nTraining completed! Best validation loss: {best_val_loss:.4f}")

if __name__ == "__main__":
    main()