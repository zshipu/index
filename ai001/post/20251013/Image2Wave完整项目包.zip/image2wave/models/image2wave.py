import torch
import torch.nn as nn
from .unet_encoder import UNetEncoder
from .transformer_decoder import TransformerDecoder, LearnableTransformerDecoder

class Image2Wave(nn.Module):
    def __init__(self, seq_len=1024, use_learnable_decoder=True, pretrained=False):
        super().__init__()
        
        # U-Net编码器，默认不使用预训练权重
        self.encoder = UNetEncoder(pretrained=pretrained)
        
        # Transformer解码器
        if use_learnable_decoder:
            self.decoder = LearnableTransformerDecoder(
                input_dim=64,  # 编码器输出的通道数
                d_model=256,
                nhead=8,
                num_layers=4,
                seq_len=seq_len
            )
        else:
            self.decoder = TransformerDecoder(
                input_dim=64,
                d_model=256,
                nhead=8,
                num_layers=4,
                seq_len=seq_len
            )
        
        # 输出缩放层（将预测的y坐标映射到合理范围）
        self.output_scaling = nn.Sequential(
            nn.Linear(seq_len, seq_len),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        """
        Args:
            x: (B, 3, H, W) - 输入图像
        Returns:
            mask_logits: (B, 1, H, W) - 掩码logits
            pred_seq: (B, seq_len) - 预测的y坐标序列
        """
        # 编码器前向传播
        mask_logits, feat = self.encoder(x)
        
        # 解码器前向传播
        # feat形状: (B, 64, H/4, W/4)
        pred_seq = self.decoder(feat, tgt_seq_len=mask_logits.shape[-1])
        
        # 将预测映射到图像高度范围
        # 假设输出是归一化的[0, 1]，映射到图像高度
        H = x.shape[2]
        pred_seq = pred_seq * H
        
        return mask_logits, pred_seq

class Image2WaveLight(nn.Module):
    """
    轻量级版本，适合部署
    """
    def __init__(self, seq_len=1024, pretrained=False):
        super().__init__()
        
        # 使用更轻量的编码器，默认不使用预训练权重
        self.encoder = UNetEncoderLight(pretrained=pretrained)
        
        # 简化的解码器
        self.decoder = TransformerDecoder(
            input_dim=32,
            d_model=128,
            nhead=4,
            num_layers=2,
            seq_len=seq_len
        )
        
    def forward(self, x):
        mask_logits, feat = self.encoder(x)
        pred_seq = self.decoder(feat, tgt_seq_len=mask_logits.shape[-1])
        
        # 映射到图像高度
        H = x.shape[2]
        pred_seq = pred_seq * H
        
        return mask_logits, pred_seq

class UNetEncoderLight(nn.Module):
    """
    轻量级U-Net编码器
    """
    def __init__(self, pretrained=False):
        super().__init__()
        
        # 使用MobileNetV2作为backbone，默认不使用预训练权重
        from torchvision.models import mobilenet_v2
        backbone = mobilenet_v2(pretrained=pretrained).features
        
        # 提取关键层
        self.initial = nn.Sequential(*backbone[:2])  # 16 channels
        self.enc1 = nn.Sequential(*backbone[2:4])    # 24 channels
        self.enc2 = nn.Sequential(*backbone[4:7])    # 32 channels
        self.enc3 = nn.Sequential(*backbone[7:14])   # 64 channels
        self.enc4 = nn.Sequential(*backbone[14:])    # 1280 channels
        
        # 简化的解码器
        self.up3 = nn.ConvTranspose2d(1280, 64, kernel_size=2, stride=2)
        self.up2 = nn.ConvTranspose2d(64, 32, kernel_size=2, stride=2)
        self.up1 = nn.ConvTranspose2d(32, 24, kernel_size=2, stride=2)
        
        self.out_conv = nn.Sequential(
            nn.Conv2d(24, 16, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 1, kernel_size=1)
        )
    
    def forward(self, x):
        x0 = self.initial(x)
        x1 = self.enc1(x0)
        x2 = self.enc2(x1)
        x3 = self.enc3(x2)
        x4 = self.enc4(x3)
        
        u3 = self.up3(x4)
        u3 = torch.cat([u3, x3], dim=1)
        u3 = nn.ReLU(inplace=True)(u3)
        
        u2 = self.up2(u3)
        u2 = torch.cat([u2, x2], dim=1)
        u2 = nn.ReLU(inplace=True)(u2)
        
        u1 = self.up1(u2)
        u1 = torch.cat([u1, x1], dim=1)
        u1 = nn.ReLU(inplace=True)(u1)
        
        mask_logits = self.out_conv(u1)
        mask_logits = nn.functional.interpolate(
            mask_logits, 
            size=x.shape[2:], 
            mode='bilinear', 
            align_corners=False
        )
        
        return mask_logits, u1

if __name__ == "__main__":
    # 测试模型
    model = Image2Wave(seq_len=1024, pretrained=False)
    dummy_input = torch.randn(1, 3, 512, 1024)
    
    mask_logits, pred_seq = model(dummy_input)
    print(f"Mask shape: {mask_logits.shape}")
    print(f"Pred seq shape: {pred_seq.shape}")
    
    # 测试轻量级模型
    model_light = Image2WaveLight(seq_len=1024, pretrained=False)
    mask_logits_light, pred_seq_light = model_light(dummy_input)
    print(f"Light mask shape: {mask_logits_light.shape}")
    print(f"Light pred seq shape: {pred_seq_light.shape}")