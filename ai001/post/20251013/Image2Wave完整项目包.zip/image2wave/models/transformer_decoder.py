import torch
import torch.nn as nn
import math

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=2048):
        super().__init__()
        
        # 预计算位置编码
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        
        # 应用正弦和余弦函数
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        # 注册为缓冲区（不参与梯度计算）
        self.register_buffer('pe', pe.unsqueeze(0))
    
    def forward(self, x):
        """
        Args:
            x: (seq_len, batch_size, d_model)
        Returns:
            x + positional encoding
        """
        return x + self.pe[:, :x.size(1), :]

class TransformerDecoder(nn.Module):
    def __init__(self, input_dim, d_model=256, nhead=8, num_layers=4, seq_len=1024):
        super().__init__()
        
        self.d_model = d_model
        self.seq_len = seq_len
        
        # 输入投影层
        self.proj = nn.Linear(input_dim, d_model)
        
        # 位置编码
        self.pos_encoder = PositionalEncoding(d_model, max_len=seq_len)
        
        # Transformer解码器层
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=1024,
            dropout=0.1,
            batch_first=False
        )
        
        # Transformer解码器
        self.transformer = nn.TransformerDecoder(decoder_layer, num_layers=num_layers)
        
        # 输出层
        self.out_proj = nn.Linear(d_model, 1)  # 预测y坐标
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        """初始化权重"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
    def forward(self, memory, tgt_seq_len=None):
        """
        Args:
            memory: (B, C, H, W) - 来自编码器的特征
            tgt_seq_len: 目标序列长度（如果为None则使用默认值）
        Returns:
            out_seq: (B, tgt_seq_len) - 预测的y坐标序列
        """
        B, C, H, W = memory.shape
        tgt_seq_len = tgt_seq_len or self.seq_len
        
        # 将空间特征展平
        # (B, C, H, W) -> (B, C, H*W) -> (H*W, B, C)
        mem = memory.view(B, C, -1).permute(2, 0, 1)
        
        # 投影到d_model维度
        mem = self.proj(mem)  # (H*W, B, d_model)
        
        # 添加位置编码
        mem = self.pos_encoder(mem)
        
        # 创建目标序列（可学习的初始序列）
        # 或者使用零初始化
        tgt = torch.zeros(tgt_seq_len, B, self.d_model, device=mem.device)
        
        # 如果需要可学习的初始序列，可以这样初始化：
        # self.tgt_embedding = nn.Parameter(torch.randn(tgt_seq_len, 1, self.d_model))
        # tgt = self.tgt_embedding.repeat(1, B, 1)
        
        # 添加位置编码到目标序列
        tgt = self.pos_encoder(tgt)
        
        # Transformer解码器前向传播
        out = self.transformer(tgt, mem)  # (tgt_seq_len, B, d_model)
        
        # 预测y坐标
        out = self.out_proj(out)  # (tgt_seq_len, B, 1)
        
        # 调整形状：(B, tgt_seq_len)
        out = out.squeeze(-1).permute(1, 0)
        
        return out

class LearnableTransformerDecoder(TransformerDecoder):
    """
    使用可学习初始序列的Transformer解码器
    """
    def __init__(self, input_dim, d_model=256, nhead=8, num_layers=4, seq_len=1024):
        super().__init__(input_dim, d_model, nhead, num_layers, seq_len)
        
        # 可学习的初始目标序列
        self.tgt_embedding = nn.Parameter(torch.randn(seq_len, 1, d_model))
        nn.init.xavier_uniform_(self.tgt_embedding)
    
    def forward(self, memory, tgt_seq_len=None):
        B, C, H, W = memory.shape
        tgt_seq_len = tgt_seq_len or self.seq_len
        
        # 编码器特征处理
        mem = memory.view(B, C, -1).permute(2, 0, 1)
        mem = self.proj(mem)
        mem = self.pos_encoder(mem)
        
        # 使用可学习的初始序列
        tgt = self.tgt_embedding.repeat(1, B, 1)
        
        # 添加位置编码
        tgt = self.pos_encoder(tgt)
        
        # Transformer解码器
        out = self.transformer(tgt, mem)
        out = self.out_proj(out)
        out = out.squeeze(-1).permute(1, 0)
        
        return out