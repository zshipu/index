import os
import numpy as np
import cv2
from torch.utils.data import Dataset
import matplotlib.pyplot as plt
from albumentations import Compose, RandomRotate90, Blur, RandomBrightnessContrast, ShiftScaleRotate

def render_ecg_to_image(signal, fs=500, img_h=256, img_w=1024, line_width=2):
    """
    将ECG信号渲染为图像
    """
    t = np.linspace(0, len(signal)/fs, len(signal))
    
    # 创建图形
    fig = plt.figure(figsize=(img_w/100, img_h/100), dpi=100)
    ax = fig.add_subplot(111)
    
    # 绘制ECG信号
    ax.plot(t, signal, color='black', linewidth=line_width)
    
    # 移除坐标轴和边距
    ax.axis('off')
    plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
    
    # 渲染为图像
    fig.canvas.draw()
    w, h = fig.canvas.get_width_height()
    img = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8).reshape(h, w, 3)
    
    # 关闭图形以释放内存
    plt.close(fig)
    
    return img

class SynthECGDataset(Dataset):
    def __init__(self, signals, fs=500, transforms=None):
        """
        合成ECG数据集
        
        Args:
            signals: list of np.array (原始ECG波形)
            fs: 采样频率
            transforms: 数据增强变换
        """
        self.signals = signals
        self.fs = fs
        self.transforms = transforms or Compose([])
        
    def __len__(self):
        return len(self.signals)
    
    def __getitem__(self, idx):
        sig = self.signals[idx]
        
        # 将信号渲染为图像
        img = render_ecg_to_image(sig, fs=self.fs)
        
        # 应用数据增强
        augmented = self.transforms(image=img)
        img = augmented['image']
        
        # 创建真实标签：每个x位置对应的y坐标
        h, w = img.shape[:2]
        
        # 重新渲染以获得精确的像素映射（用于创建标签）
        # 这里我们创建一个精确的y坐标映射
        t_render = np.linspace(0, len(sig)/self.fs, w)
        # 插值原始信号到图像宽度
        from scipy import interpolate
        f = interpolate.interp1d(np.linspace(0, len(sig)/self.fs, len(sig)), sig)
        sig_rendered = f(t_render)
        
        # 将信号值映射到像素坐标
        # 假设信号范围为[-1, 1]，映射到图像高度
        sig_min, sig_max = sig_rendered.min(), sig_rendered.max()
        if sig_max == sig_min:
            sig_max = sig_min + 1e-6  # 避免除以零
        
        # 归一化到[0, 1]然后映射到像素
        sig_norm = (sig_rendered - sig_min) / (sig_max - sig_min)
        y_target = (1 - sig_norm) * h  # 翻转y轴，因为图像坐标系y向下
        
        # 确保在有效范围内
        y_target = np.clip(y_target, 0, h-1)
        
        sample = {
            'image': cv2.resize(img, (1024, 512)),  # 固定输出尺寸
            'y_target': y_target.astype(np.float32),
            'signal': sig.astype(np.float32)  # 保存原始信号用于参考
        }
        
        return sample

def get_synth_transforms():
    """
    获取数据增强变换
    """
    return Compose([
        ShiftScaleRotate(
            shift_limit=0.02, 
            scale_limit=0.05, 
            rotate_limit=10, 
            p=0.8
        ),
        Blur(blur_limit=3, p=0.3),
        RandomBrightnessContrast(
            brightness_limit=0.2, 
            contrast_limit=0.2, 
            p=0.5
        ),
    ])

def generate_synthetic_ecg_signals(num_samples=1000, duration=4, fs=500):
    """
    生成合成ECG信号
    """
    signals = []
    
    for _ in range(num_samples):
        t = np.linspace(0, duration, int(duration * fs))
        
        # 基础心跳模式
        heart_rate = np.random.uniform(60, 100)  # 60-100 BPM
        beat_interval = fs * 60 / heart_rate
        
        # 生成多个心跳
        signal = np.zeros_like(t)
        num_beats = int(duration * heart_rate / 60) + 2
        
        for i in range(num_beats):
            beat_start = int(i * beat_interval)
            if beat_start >= len(t):
                break
            
            # P波
            p_wave_len = 10
            if beat_start + p_wave_len <= len(t):
                p_wave = np.exp(-((np.arange(p_wave_len) - p_wave_len//2) ** 2) / 8) * 0.2
                signal[beat_start:beat_start+p_wave_len] += p_wave
            
            # QRS波群
            qrs_start = beat_start + 15
            q_wave_len = 5
            r_wave_len = 10
            s_wave_len = 5
            
            if qrs_start + q_wave_len + r_wave_len + s_wave_len <= len(t):
                q_wave = np.exp(-((np.arange(q_wave_len) - q_wave_len//2) ** 2) / 2) * -0.3
                r_wave = np.exp(-((np.arange(r_wave_len) - r_wave_len//2) ** 2) / 4) * 1.0
                s_wave = np.exp(-((np.arange(s_wave_len) - s_wave_len//2) ** 2) / 2) * -0.4
                
                signal[qrs_start:qrs_start+q_wave_len] += q_wave
                signal[qrs_start+q_wave_len:qrs_start+q_wave_len+r_wave_len] += r_wave
                signal[qrs_start+q_wave_len+r_wave_len:qrs_start+q_wave_len+r_wave_len+s_wave_len] += s_wave
            
            # T波
            t_wave_start = beat_start + 40
            t_wave_len = 15
            
            if t_wave_start + t_wave_len <= len(t):
                t_wave = np.exp(-((np.arange(t_wave_len) - t_wave_len//2) ** 2) / 18) * 0.3
                signal[t_wave_start:t_wave_start+t_wave_len] += t_wave
        
        # 添加噪声
        noise = np.random.normal(0, 0.02, len(t))
        signal += noise
        
        # 标准化
        signal = (signal - np.mean(signal)) / np.std(signal)
        signal = np.clip(signal, -1, 1)
        
        signals.append(signal)
    
    return signals

if __name__ == "__main__":
    # 测试数据生成
    signals = generate_synthetic_ecg_signals(num_samples=10)
    transforms = get_synth_transforms()
    dataset = SynthECGDataset(signals, transforms=transforms)
    
    # 可视化第一个样本
    sample = dataset[0]
    print(f"Image shape: {sample['image'].shape}")
    print(f"Target shape: {sample['y_target'].shape}")
    print(f"Signal shape: {sample['signal'].shape}")
    
    # 显示图像和目标
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 1, 1)
    plt.imshow(sample['image'])
    plt.title('Rendered ECG Image')
    plt.axis('off')
    
    plt.subplot(2, 1, 2)
    plt.plot(sample['y_target'], 'b-', linewidth=2)
    plt.title('Ground Truth Y Coordinates')
    plt.xlabel('X Pixel')
    plt.ylabel('Y Pixel')
    
    plt.tight_layout()
    plt.show()