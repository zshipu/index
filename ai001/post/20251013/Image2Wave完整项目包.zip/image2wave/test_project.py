"""
测试脚本：验证项目基本功能
"""
import os
import sys
import numpy as np
import torch
import cv2
import matplotlib.pyplot as plt

def test_data_generation():
    """测试数据生成功能"""
    print("=" * 50)
    print("测试数据生成功能...")
    print("=" * 50)
    
    try:
        from data.synth_dataset import (
            generate_synthetic_ecg_signals,
            SynthECGDataset,
            get_synth_transforms,
            render_ecg_to_image
        )
        
        # 生成合成信号
        signals = generate_synthetic_ecg_signals(num_samples=5)
        print(f"生成了 {len(signals)} 个合成ECG信号")
        print(f"每个信号长度: {len(signals[0])} 样本点")
        
        # 测试渲染功能
        img = render_ecg_to_image(signals[0])
        print(f"渲染图像形状: {img.shape}")
        
        # 测试数据集
        transforms = get_synth_transforms()
        dataset = SynthECGDataset(signals, transforms=transforms)
        
        sample = dataset[0]
        print(f"样本图像形状: {sample['image'].shape}")
        print(f"目标序列形状: {sample['y_target'].shape}")
        print(f"原始信号形状: {sample['signal'].shape}")
        
        print("✓ 数据生成功能测试通过")
        return True
        
    except Exception as e:
        print(f"✗ 数据生成功能测试失败: {e}")
        return False

def test_model_creation():
    """测试模型创建功能"""
    print("\n" + "=" * 50)
    print("测试模型创建功能...")
    print("=" * 50)
    
    try:
        from models.image2wave import Image2Wave, Image2WaveLight
        
        # 创建完整模型
        model_full = Image2Wave(seq_len=1024)
        print("✓ 完整模型创建成功")
        
        # 创建轻量级模型
        model_light = Image2WaveLight(seq_len=1024)
        print("✓ 轻量级模型创建成功")
        
        # 测试前向传播
        dummy_input = torch.randn(1, 3, 512, 1024)
        
        mask_logits, pred_seq = model_full(dummy_input)
        print(f"✓ 完整模型前向传播成功")
        print(f"  掩码形状: {mask_logits.shape}")
        print(f"  序列形状: {pred_seq.shape}")
        
        mask_logits_light, pred_seq_light = model_light(dummy_input)
        print(f"✓ 轻量级模型前向传播成功")
        print(f"  掩码形状: {mask_logits_light.shape}")
        print(f"  序列形状: {pred_seq_light.shape}")
        
        print("✓ 模型创建功能测试通过")
        return True
        
    except Exception as e:
        print(f"✗ 模型创建功能测试失败: {e}")
        return False

def test_training_loop():
    """测试训练循环"""
    print("\n" + "=" * 50)
    print("测试训练循环...")
    print("=" * 50)
    
    try:
        import yaml
        from torch.utils.data import DataLoader
        from models.image2wave import Image2Wave
        from data.synth_dataset import (
            generate_synthetic_ecg_signals,
            SynthECGDataset,
            get_synth_transforms
        )
        
        # 加载配置
        with open('configs/config.yaml', 'r') as f:
            cfg = yaml.safe_load(f)
        
        # 生成少量测试数据
        signals = generate_synthetic_ecg_signals(num_samples=20)
        transforms = get_synth_transforms()
        dataset = SynthECGDataset(signals, transforms=transforms)
        loader = DataLoader(dataset, batch_size=2, shuffle=True)
        
        # 创建模型
        model = Image2Wave(seq_len=1024)
        
        # 创建优化器
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
        
        # 测试一个训练迭代
        model.train()
        batch = next(iter(loader))
        
        images = torch.tensor(batch['image']).permute(0, 3, 1, 2).float() / 255.0
        y_target = torch.tensor(batch['y_target']).float()
        
        optimizer.zero_grad()
        mask_logits, pred_seq = model(images)
        
        # 简化的损失计算
        loss = torch.nn.SmoothL1Loss()(pred_seq, y_target)
        loss.backward()
        optimizer.step()
        
        print(f"✓ 训练迭代测试成功")
        print(f"  损失值: {loss.item():.4f}")
        
        print("✓ 训练循环测试通过")
        return True
        
    except Exception as e:
        print(f"✗ 训练循环测试失败: {e}")
        return False

def test_visualization():
    """测试可视化功能"""
    print("\n" + "=" * 50)
    print("测试可视化功能...")
    print("=" * 50)
    
    try:
        from data.synth_dataset import (
            generate_synthetic_ecg_signals,
            SynthECGDataset,
            render_ecg_to_image
        )
        
        # 生成测试数据
        signals = generate_synthetic_ecg_signals(num_samples=1)
        dataset = SynthECGDataset(signals, transforms=None)
        sample = dataset[0]
        
        # 创建可视化
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
        
        # 原始图像
        ax1.imshow(sample['image'])
        ax1.set_title('Rendered ECG Image')
        ax1.axis('off')
        
        # 原始信号
        ax2.plot(sample['signal'])
        ax2.set_title('Original ECG Signal')
        ax2.set_xlabel('Sample')
        ax2.set_ylabel('Amplitude')
        
        # 目标序列可视化
        ax3.plot(sample['y_target'], 'r-', linewidth=2)
        ax3.set_title('Ground Truth Y Coordinates')
        ax3.set_xlabel('X Pixel')
        ax3.set_ylabel('Y Pixel')
        
        # 叠加显示
        img_with_overlay = sample['image'].copy()
        for x, y in enumerate(sample['y_target']):
            y = int(round(y))
            if 0 <= y < img_with_overlay.shape[0]:
                img_with_overlay[y-1:y+2, x-1:x+2] = [255, 0, 0]
        
        ax4.imshow(img_with_overlay)
        ax4.set_title('Image with Target Overlay')
        ax4.axis('off')
        
        plt.tight_layout()
        
        # 保存可视化结果
        os.makedirs('test_results', exist_ok=True)
        plt.savefig('test_results/visualization_test.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print("✓ 可视化功能测试通过")
        print("  结果已保存到 test_results/visualization_test.png")
        return True
        
    except Exception as e:
        print(f"✗ 可视化功能测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("Image2Wave 项目功能测试\n")
    
    # 运行所有测试
    tests = [
        test_data_generation,
        test_model_creation,
        test_training_loop,
        test_visualization
    ]
    
    results = []
    for test in tests:
        result = test()
        results.append(result)
    
    # 总结
    print("\n" + "=" * 50)
    print("测试总结")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"\n通过测试: {passed}/{total}")
    
    if passed == total:
        print("✓ 所有测试通过！项目可以正常使用。")
    else:
        print("✗ 部分测试失败，请检查相关功能。")
    
    return passed == total

if __name__ == "__main__":
    # 切换到项目根目录
    project_root = os.path.dirname(os.path.abspath(__file__))
    os.chdir(project_root)
    
    # 运行测试
    success = main()
    sys.exit(0 if success else 1)