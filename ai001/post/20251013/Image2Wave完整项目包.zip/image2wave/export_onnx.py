import torch
import torch.nn as nn
import yaml
import os
from models.image2wave import Image2Wave, Image2WaveLight

def load_config(path='configs/config.yaml'):
    """加载配置文件"""
    with open(path, 'r') as f:
        return yaml.safe_load(f)

def export_onnx(model, dummy_input, output_path, opset=13, dynamic_axes=None):
    """
    导出ONNX模型
    
    Args:
        model: PyTorch模型
        dummy_input: 虚拟输入张量
        output_path: 输出文件路径
        opset: ONNX opset版本
        dynamic_axes: 动态轴配置
    """
    # 设置动态轴默认配置
    if dynamic_axes is None:
        dynamic_axes = {
            'input_image': {0: 'batch', 2: 'height', 3: 'width'},
            'mask_logits': {0: 'batch', 2: 'height', 3: 'width'},
            'pred_seq': {0: 'batch', 1: 'seq_length'}
        }
    
    # 导出ONNX
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        input_names=['input_image'],
        output_names=['mask_logits', 'pred_seq'],
        dynamic_axes=dynamic_axes,
        opset_version=opset,
        do_constant_folding=True,
        verbose=False,
        export_params=True
    )
    
    print(f"ONNX model exported to: {output_path}")

def export_model_variants(cfg):
    """导出不同版本的模型"""
    # 创建输出目录
    os.makedirs(os.path.dirname(cfg['onnx']['out_path']), exist_ok=True)
    
    # 1. 导出完整模型
    print("Exporting full model...")
    model_full = Image2Wave(seq_len=1024)
    
    # 加载最佳权重
    best_ckpt = os.path.join(cfg['train']['ckpt_dir'], 'best_model.pth')
    if os.path.exists(best_ckpt):
        checkpoint = torch.load(best_ckpt, map_location='cpu')
        model_full.load_state_dict(checkpoint['model_state_dict'])
        print("Loaded best model weights")
    
    model_full.eval()
    
    # 虚拟输入
    dummy_input = torch.randn(1, 3, 512, 1024)
    
    # 导出完整模型
    export_onnx(
        model_full,
        dummy_input,
        cfg['onnx']['out_path'],
        opset=13
    )
    
    # 2. 导出轻量级模型
    print("\nExporting lightweight model...")
    model_light = Image2WaveLight(seq_len=1024)
    
    # 如果有轻量级模型权重，加载它们
    light_ckpt = os.path.join(cfg['train']['ckpt_dir'], 'best_light_model.pth')
    if os.path.exists(light_ckpt):
        checkpoint = torch.load(light_ckpt, map_location='cpu')
        model_light.load_state_dict(checkpoint['model_state_dict'])
        print("Loaded lightweight model weights")
    
    model_light.eval()
    
    # 导出轻量级模型
    light_output_path = cfg['onnx']['out_path'].replace('.onnx', '_light.onnx')
    export_onnx(
        model_light,
        dummy_input,
        light_output_path,
        opset=13
    )
    
    # 3. 导出固定尺寸版本（优化推理速度）
    print("\nExporting fixed size model...")
    fixed_dynamic_axes = {
        'input_image': {0: 'batch'},
        'mask_logits': {0: 'batch'},
        'pred_seq': {0: 'batch'}
    }
    
    fixed_output_path = cfg['onnx']['out_path'].replace('.onnx', '_fixed.onnx')
    export_onnx(
        model_full,
        dummy_input,
        fixed_output_path,
        opset=13,
        dynamic_axes=fixed_dynamic_axes
    )
    
    return {
        'full_model': cfg['onnx']['out_path'],
        'light_model': light_output_path,
        'fixed_model': fixed_output_path
    }

def verify_onnx_export(model_path):
    """验证ONNX导出"""
    try:
        import onnx
        import onnxruntime as ort
        
        # 检查ONNX模型有效性
        model = onnx.load(model_path)
        onnx.checker.check_model(model)
        print(f"ONNX model {model_path} is valid")
        
        # 测试推理
        session = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])
        
        # 创建测试输入
        test_input = np.random.randn(1, 3, 512, 1024).astype(np.float32)
        
        # 推理
        input_name = session.get_inputs()[0].name
        outputs = session.run(None, {input_name: test_input})
        
        print(f"Test inference successful. Output shapes:")
        print(f"  Mask logits: {outputs[0].shape}")
        print(f"  Predicted sequence: {outputs[1].shape}")
        
        return True
        
    except Exception as e:
        print(f"ONNX verification failed: {e}")
        return False

def main():
    # 加载配置
    cfg = load_config()
    
    # 导出模型
    exported_models = export_model_variants(cfg)
    
    # 验证导出
    print("\nVerifying ONNX exports...")
    for name, path in exported_models.items():
        print(f"\nVerifying {name}...")
        verify_onnx_export(path)
    
    print("\nONNX export completed successfully!")

if __name__ == "__main__":
    main()