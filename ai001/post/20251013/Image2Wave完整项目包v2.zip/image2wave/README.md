# Image2Wave: ECG图像到波形的深度学习转换系统

## 项目概述

Image2Wave是一个基于深度学习的ECG（心电图）图像数字化系统，能够将纸质或扫描的ECG图像转换为可分析的数字化波形数据。该系统采用U-Net编码器提取图像特征，结合Transformer解码器生成时序坐标序列，实现高精度的ECG波形重建。

## 主要特性

- **端到端学习**：从图像直接生成数字化波形
- **混合架构**：U-Net + Transformer的强大组合
- **多版本支持**：提供完整版和轻量级版本
- **ONNX部署**：支持高效的生产环境部署
- **数据合成**：内置合成ECG信号生成器
- **批量处理**：支持单张和批量图像处理

## 项目结构

```
image2wave/
├── data/
│   └── synth_dataset.py       # 数据合成和数据集定义
├── models/
│   ├── unet_encoder.py        # U-Net编码器
│   ├── transformer_decoder.py # Transformer解码器
│   └── image2wave.py          # 完整模型定义
├── configs/
│   └── config.yaml            # 配置文件
├── train.py                   # 训练脚本
├── export_onnx.py             # ONNX导出脚本
├── infer_onnx.py              # ONNXRuntime推理脚本
├── requirements.txt           # 依赖包列表
└── README.md                  # 项目说明
```

## 快速开始

### 1. 环境准备

```bash
# 创建虚拟环境
conda create -n image2wave python=3.8
conda activate image2wave

# 安装依赖
pip install -r requirements.txt
```

### 2. 数据准备

系统支持两种数据方式：

**方式一：使用合成数据（推荐快速测试）**
```python
from data.synth_dataset import generate_synthetic_ecg_signals

# 生成1000个合成ECG信号
signals = generate_synthetic_ecg_signals(num_samples=1000)
```

**方式二：使用真实数据**
```python
# 需要准备真实的ECG信号和对应的渲染图像
# 并创建自定义的Dataset类
```

### 3. 模型训练

```bash
# 开始训练
python train.py

# 训练过程中会自动生成合成数据
# 模型权重将保存在 checkpoints/ 目录下
```

训练配置可以在 `configs/config.yaml` 中修改：
```yaml
train:
  batch_size: 4          # 批次大小
  lr: 1e-4               # 学习率
  epochs: 60             # 训练轮数
  ckpt_dir: ./checkpoints # 检查点目录
  mask_loss_weight: 1.0  # 掩码损失权重
  seq_loss_weight: 1.0   # 序列损失权重

onnx:
  out_path: ./models/image2wave.onnx  # ONNX输出路径
```

### 4. 导出ONNX模型

```bash
# 导出ONNX模型
python export_onnx.py

# 将生成三个版本：
# - image2wave.onnx (完整版本)
# - image2wave_light.onnx (轻量级版本)
# - image2wave_fixed.onnx (固定尺寸版本)
```

### 5. 推理预测

```bash
# 单张图像推理
python infer_onnx.py \
    --model models/image2wave.onnx \
    --image test_ecg.jpg \
    --output results \
    --gpu

# 批量推理
python infer_onnx.py \
    --model models/image2wave.onnx \
    --batch ecg1.jpg ecg2.jpg ecg3.jpg \
    --output results
```

## API使用示例

### Python API

```python
from infer_onnx import ECGImageProcessor

# 创建处理器实例
processor = ECGImageProcessor(
    model_path='models/image2wave.onnx',
    use_gpu=True
)

# 单张图像预测
result = processor.predict('test_ecg.jpg')

# 打印结果
print(f"信号长度: {len(result['signal_values'])}")
print(f"置信度: {result['confidence']:.3f}")
print(f"处理时间: {result['timing']['total']:.3f}秒")

# 批量预测
image_paths = ['ecg1.jpg', 'ecg2.jpg', 'ecg3.jpg']
results = processor.batch_predict(image_paths)

# 保存结果
processor.save_prediction(result, 'output_dir', 'ecg_result')
```

### 结果说明

推理返回的结果字典包含：
- `signal_values`: 重建的ECG信号值（范围[-1, 1]）
- `predicted_sequence`: 预测的像素坐标序列
- `relative_sequence`: 归一化的坐标序列
- `mask`: 生成的注意力掩码
- `confidence`: 预测置信度
- `timing`: 各阶段处理时间

## 模型版本说明

| 版本 | 特点 | 参数量 | 适用场景 |
|------|------|--------|----------|
| 完整版 | 高精度 | 较大 | 研究和高精度需求 |
| 轻量版 | 快速推理 | 较小 | 移动设备和实时应用 |
| 固定尺寸版 | 最快推理 | 中等 | 固定输入尺寸的生产环境 |

## 性能优化建议

### 训练优化

1. **混合精度训练**：启用AMP加速训练
2. **学习率调度**：使用ReduceLROnPlateau自动调整
3. **数据增强**：增加旋转、缩放、噪声等变换
4. **批量归一化**：稳定训练过程

### 推理优化

1. **ONNX Runtime优化**：
```python
session_options = ort.SessionOptions()
session_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
```

2. **GPU加速**：
```python
providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
```

3. **批量处理**：使用batch_predict提高吞吐量

## 临床应用注意事项

1. **验证要求**：在临床使用前必须在真实数据上充分验证
2. **设备兼容性**：需测试不同设备、纸张、拍摄条件
3. **合规性**：确保符合HIPAA/GDPR等数据隐私法规
4. **人工确认**：建议医生对输出结果进行二次确认

## 调参指南

### 关键超参数

1. **模型参数**：
   - `d_model`: Transformer维度（建议128-512）
   - `nhead`: 注意力头数（建议4-16）
   - `num_layers`: Transformer层数（建议2-6）

2. **训练参数**：
   - `batch_size`: 批次大小（根据GPU内存调整）
   - `lr`: 学习率（建议1e-4到1e-3）
   - `weight_decay`: 权重衰减（建议1e-4）

3. **损失权重**：
   - `mask_loss_weight`: 掩码损失权重
   - `seq_loss_weight`: 序列损失权重

### 性能评估指标

```python
# 常用评估指标
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error

# RMSE (Root Mean Squared Error)
rmse = np.sqrt(mean_squared_error(y_true, y_pred))

# MAE (Mean Absolute Error)
mae = mean_absolute_error(y_true, y_pred)

# CC (Correlation Coefficient)
cc = np.corrcoef(y_true, y_pred)[0, 1]
```

## 扩展功能

### 自定义数据集

```python
class CustomECGDataset(Dataset):
    def __init__(self, image_paths, signal_paths, transforms=None):
        self.image_paths = image_paths
        self.signal_paths = signal_paths
        self.transforms = transforms
        
    def __getitem__(self, idx):
        # 读取图像和信号
        img = cv2.imread(self.image_paths[idx])
        signal = np.load(self.signal_paths[idx])
        
        # 预处理...
        return {'image': img, 'signal': signal, 'y_target': ...}
```

### 模型扩展

可以通过继承基础类来扩展功能：

```python
class Image2WaveWithAttention(Image2Wave):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 添加注意力机制...
```

## 常见问题

### Q1: 训练时内存不足怎么办？

A1: 可以尝试：
- 减小batch_size
- 使用轻量级模型
- 启用梯度累积
- 使用混合精度训练

### Q2: 如何提高预测精度？

A2: 建议：
- 增加训练数据量
- 调整超参数
- 使用数据增强
- 延长训练时间

### Q3: 支持哪些图像格式？

A3: 支持所有OpenCV能读取的格式：
- JPG/JPEG
- PNG
- TIFF
- BMP

## 技术支持

如果您在使用过程中遇到问题，请：

1. 查看项目文档和示例代码
2. 检查是否使用了最新版本
3. 在GitHub Issues中提交问题描述

## 引用

如果您在研究中使用了本项目，请考虑引用：

```
@misc{image2wave2024,
    title={Image2Wave: Deep Learning for ECG Image to Waveform Conversion},
    author={Your Name},
    year={2024},
    howpublished={\url{https://github.com/yourusername/image2wave}}
}
```

## 许可证

本项目采用MIT许可证，详情请参见LICENSE文件。

## 免责声明

本项目仅供研究和教育目的使用，不得用于临床诊断或医疗决策。在医疗应用中使用前，必须经过充分的临床验证和监管部门批准。