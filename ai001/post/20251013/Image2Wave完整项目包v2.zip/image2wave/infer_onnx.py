import onnxruntime as ort
import numpy as np
import cv2
import time
import os
from typing import Dict, Tuple, Optional

class ECGImageProcessor:
    """
    ECG图像处理器，用于将ECG图像转换为波形数据
    """
    
    def __init__(self, model_path: str, use_gpu: bool = True):
        """
        初始化处理器
        
        Args:
            model_path: ONNX模型路径
            use_gpu: 是否使用GPU
        """
        self.model_path = model_path
        self.use_gpu = use_gpu
        
        # 初始化ONNX Runtime会话
        self.session = self._create_session()
        
        # 获取输入输出信息
        self.input_info = self.session.get_inputs()[0]
        self.output_info = self.session.get_outputs()
        
        print(f"Model loaded: {model_path}")
        print(f"Input shape: {self.input_info.shape}")
        print(f"Output shapes: {[o.shape for o in self.output_info]}")
    
    def _create_session(self) -> ort.InferenceSession:
        """创建ONNX Runtime会话"""
        # 选择执行提供器
        providers = ['CPUExecutionProvider']
        if self.use_gpu and ort.get_device() == 'GPU':
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
        
        # 会话配置
        session_options = ort.SessionOptions()
        session_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        session_options.intra_op_num_threads = os.cpu_count() or 4
        session_options.inter_op_num_threads = 2
        
        return ort.InferenceSession(
            self.model_path,
            providers=providers,
            sess_options=session_options
        )
    
    def preprocess_image(self, image_path: str, target_size: Tuple[int, int] = (1024, 512)) -> np.ndarray:
        """
        预处理图像
        
        Args:
            image_path: 图像文件路径
            target_size: 目标尺寸 (width, height)
        Returns:
            预处理后的图像张量 (1, 3, H, W)
        """
        # 读取图像
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"Failed to read image: {image_path}")
        
        # 转换为RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # 调整尺寸
        img = cv2.resize(img, target_size)
        
        # 归一化
        img = img.astype(np.float32) / 255.0
        
        # 调整通道顺序 (H, W, 3) -> (1, 3, H, W)
        img = np.transpose(img, (2, 0, 1))[np.newaxis, ...]
        
        return img
    
    def predict(self, image_path: str, target_size: Tuple[int, int] = (1024, 512)) -> Dict:
        """
        预测ECG波形
        
        Args:
            image_path: 图像文件路径
            target_size: 目标尺寸
        Returns:
            预测结果字典
        """
        # 预处理
        start_time = time.time()
        input_tensor = self.preprocess_image(image_path, target_size)
        preprocess_time = time.time() - start_time
        
        # 推理
        inference_start = time.time()
        outputs = self.session.run(
            None,
            {self.input_info.name: input_tensor}
        )
        inference_time = time.time() - inference_start
        
        mask_logits, pred_seq = outputs
        
        # 后处理
        postprocess_start = time.time()
        result = self.postprocess(mask_logits, pred_seq, target_size)
        postprocess_time = time.time() - postprocess_start
        
        # 添加时间信息
        result['timing'] = {
            'preprocess': preprocess_time,
            'inference': inference_time,
            'postprocess': postprocess_time,
            'total': time.time() - start_time
        }
        
        return result
    
    def postprocess(self, mask_logits: np.ndarray, pred_seq: np.ndarray, 
                   target_size: Tuple[int, int]) -> Dict:
        """
        后处理
        
        Args:
            mask_logits: 掩码logits
            pred_seq: 预测序列
            target_size: 目标尺寸
        Returns:
            后处理结果
        """
        # 掩码后处理
        mask = 1 / (1 + np.exp(-mask_logits))  # sigmoid
        mask = (mask > 0.5).astype(np.float32)
        
        # 序列后处理
        pred_seq = pred_seq[0]  # 去除batch维度
        
        # 确保在有效范围内
        H = target_size[1]
        pred_seq = np.clip(pred_seq, 0, H - 1)
        
        # 转换为相对坐标 (0-1)
        pred_seq_rel = pred_seq / H
        
        # 从像素坐标转换为信号值（假设信号范围为[-1, 1]）
        signal_values = 1 - 2 * pred_seq_rel  # 翻转y轴并归一化
        
        return {
            'mask': mask,
            'predicted_sequence': pred_seq,
            'relative_sequence': pred_seq_rel,
            'signal_values': signal_values,
            'confidence': np.mean(mask)  # 平均置信度
        }
    
    def batch_predict(self, image_paths: list, target_size: Tuple[int, int] = (1024, 512)) -> list:
        """
        批量预测
        
        Args:
            image_paths: 图像路径列表
            target_size: 目标尺寸
        Returns:
            预测结果列表
        """
        # 预处理所有图像
        start_time = time.time()
        input_tensors = []
        
        for path in image_paths:
            input_tensor = self.preprocess_image(path, target_size)
            input_tensors.append(input_tensor)
        
        # 合并为批量
        batch_tensor = np.concatenate(input_tensors, axis=0)
        preprocess_time = time.time() - start_time
        
        # 批量推理
        inference_start = time.time()
        outputs = self.session.run(
            None,
            {self.input_info.name: batch_tensor}
        )
        inference_time = time.time() - inference_start
        
        mask_logits_batch, pred_seq_batch = outputs
        
        # 后处理
        results = []
        postprocess_start = time.time()
        
        for i in range(len(image_paths)):
            mask_logits = mask_logits_batch[i:i+1]
            pred_seq = pred_seq_batch[i:i+1]
            
            result = self.postprocess(mask_logits, pred_seq, target_size)
            result['image_path'] = image_paths[i]
            
            results.append(result)
        
        postprocess_time = time.time() - postprocess_start
        
        # 添加时间信息
        total_time = time.time() - start_time
        avg_time = total_time / len(image_paths)
        
        for result in results:
            result['timing'] = {
                'batch_preprocess': preprocess_time,
                'batch_inference': inference_time,
                'batch_postprocess': postprocess_time,
                'total_batch_time': total_time,
                'avg_per_image': avg_time
            }
        
        return results
    
    def save_prediction(self, result: Dict, output_dir: str, filename: str = 'prediction'):
        """
        保存预测结果
        
        Args:
            result: 预测结果字典
            output_dir: 输出目录
            filename: 文件名前缀
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # 保存信号值为CSV
        signal_csv = os.path.join(output_dir, f"{filename}_signal.csv")
        np.savetxt(signal_csv, result['signal_values'], delimiter=',')
        
        # 保存序列坐标
        seq_csv = os.path.join(output_dir, f"{filename}_sequence.csv")
        np.savetxt(seq_csv, result['predicted_sequence'], delimiter=',')
        
        # 保存掩码图像
        mask_img = os.path.join(output_dir, f"{filename}_mask.png")
        mask_vis = (result['mask'][0, 0] * 255).astype(np.uint8)
        cv2.imwrite(mask_img, mask_vis)
        
        print(f"Results saved to {output_dir}")
        
        return {
            'signal_csv': signal_csv,
            'sequence_csv': seq_csv,
            'mask_image': mask_img
        }

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='ECG Image to Waveform Inference')
    parser.add_argument('--model', type=str, required=True, help='ONNX model path')
    parser.add_argument('--image', type=str, required=True, help='Input image path')
    parser.add_argument('--output', type=str, default='output', help='Output directory')
    parser.add_argument('--gpu', action='store_true', help='Use GPU for inference')
    parser.add_argument('--batch', type=str, nargs='*', help='Batch predict multiple images')
    
    args = parser.parse_args()
    
    # 创建处理器
    processor = ECGImageProcessor(args.model, use_gpu=args.gpu)
    
    # 确保输出目录存在
    os.makedirs(args.output, exist_ok=True)
    
    if args.batch:
        # 批量预测
        print(f"Batch predicting {len(args.batch)} images...")
        results = processor.batch_predict(args.batch)
        
        for i, result in enumerate(results):
            print(f"\nResults for {result['image_path']}:")
            print(f"Signal length: {len(result['signal_values'])}")
            print(f"Confidence: {result['confidence']:.3f}")
            print(f"Timing: {result['timing']['avg_per_image']:.3f}s per image")
            
            # 保存结果
            base_name = os.path.splitext(os.path.basename(result['image_path']))[0]
            processor.save_prediction(result, args.output, base_name)
    
    else:
        # 单张图像预测
        print(f"Predicting {args.image}...")
        result = processor.predict(args.image)
        
        # 打印结果
        print("\nPrediction Results:")
        print(f"Signal length: {len(result['signal_values'])}")
        print(f"Confidence: {result['confidence']:.3f}")
        print(f"Signal range: {result['signal_values'].min():.3f} to {result['signal_values'].max():.3f}")
        print("\nTiming:")
        print(f"  Preprocess: {result['timing']['preprocess']:.3f}s")
        print(f"  Inference: {result['timing']['inference']:.3f}s")
        print(f"  Postprocess: {result['timing']['postprocess']:.3f}s")
        print(f"  Total: {result['timing']['total']:.3f}s")
        
        # 保存结果
        save_paths = processor.save_prediction(result, args.output)
        print(f"\nResults saved to:")
        for key, path in save_paths.items():
            print(f"  {key}: {path}")

if __name__ == "__main__":
    main()