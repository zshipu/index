import torch
import torch.nn as nn
import torchvision.models as models

class UNetEncoder(nn.Module):
    def __init__(self, pretrained=False, out_channels=64):
        super().__init__()
        
        # 使用ResNet34作为backbone，默认不使用预训练权重
        backbone = models.resnet34(pretrained=pretrained)
        
        # 编码器部分
        self.initial = nn.Sequential(
            backbone.conv1,
            backbone.bn1,
            backbone.relu,
            backbone.maxpool
        )
        self.enc1 = backbone.layer1  # 64 channels
        self.enc2 = backbone.layer2  # 128 channels
        self.enc3 = backbone.layer3  # 256 channels
        self.enc4 = backbone.layer4  # 512 channels
        
        # 解码器部分（简化版本，避免通道数错误）
        self.up3 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.conv3 = nn.Sequential(
            nn.Conv2d(256 + 256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True)
        )
        
        self.up2 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.conv2 = nn.Sequential(
            nn.Conv2d(128 + 128, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True)
        )
        
        self.up1 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.conv1 = nn.Sequential(
            nn.Conv2d(64 + 64, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True)
        )
        
        # 输出卷积层
        self.out_conv = nn.Sequential(
            nn.Conv2d(64, 32, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, kernel_size=1)
        )
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        """初始化权重"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        # 编码器前向传播
        x0 = self.initial(x)  # (B, 64, H/4, W/4)
        x1 = self.enc1(x0)    # (B, 64, H/4, W/4)
        x2 = self.enc2(x1)    # (B, 128, H/8, W/8)
        x3 = self.enc3(x2)    # (B, 256, H/16, W/16)
        x4 = self.enc4(x3)    # (B, 512, H/32, W/32)
        
        # 解码器前向传播（带残差连接）
        u3 = self.up3(x4)
        # 调整尺寸以匹配x3
        u3 = nn.functional.interpolate(u3, size=x3.shape[2:], mode='bilinear', align_corners=False)
        u3 = torch.cat([u3, x3], dim=1)  # 残差连接
        u3 = self.conv3(u3)
        
        u2 = self.up2(u3)
        u2 = nn.functional.interpolate(u2, size=x2.shape[2:], mode='bilinear', align_corners=False)
        u2 = torch.cat([u2, x2], dim=1)  # 残差连接
        u2 = self.conv2(u2)
        
        u1 = self.up1(u2)
        u1 = nn.functional.interpolate(u1, size=x1.shape[2:], mode='bilinear', align_corners=False)
        u1 = torch.cat([u1, x1], dim=1)  # 残差连接
        u1 = self.conv1(u1)
        
        # 输出层
        mask_logits = self.out_conv(u1)  # (B, 1, H/4, W/4)
        
        # 上采样到原始输入分辨率
        mask_logits = nn.functional.interpolate(
            mask_logits, 
            size=x.shape[2:], 
            mode='bilinear', 
            align_corners=False
        )
        
        return mask_logits, u1  # 返回mask logits和中间特征