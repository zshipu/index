"""
演示脚本：展示Image2Wave项目的完整工作流程
"""
import os
import sys
import numpy as np
import torch
import cv2
import matplotlib.pyplot as plt
import time
from tqdm import tqdm

def create_demo_images(num_images=5):
    """创建演示用的ECG图像"""
    print("1. 创建演示ECG图像...")
    
    from data.synth_dataset import (
        generate_synthetic_ecg_signals,
        render_ecg_to_image
    )
    
    # 生成合成信号
    signals = generate_synthetic_ecg_signals(num_samples=num_images)
    
    # 创建输出目录
    demo_dir = 'demo_data'
    os.makedirs(demo_dir, exist_ok=True)
    
    saved_paths = []
    for i, signal in enumerate(signals):
        # 渲染图像
        img = render_ecg_to_image(signal)
        
        # 添加一些真实感效果
        img = add_realistic_effects(img)
        
        # 保存图像
        img_path = os.path.join(demo_dir, f'ecg_demo_{i+1}.png')
        cv2.imwrite(img_path, cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        
        # 保存原始信号用于对比
        np.save(os.path.join(demo_dir, f'ecg_demo_{i+1}_signal.npy'), signal)
        
        saved_paths.append(img_path)
        print(f"  生成图像 {i+1}/{num_images}: {img_path}")
    
    return saved_paths, signals

def add_realistic_effects(img):
    """为图像添加真实感效果"""
    import random
    
    # 添加纸张纹理
    h, w = img.shape[:2]
    paper_texture = np.random.normal(240, 10, (h, w, 3)).astype(np.uint8)
    img = cv2.addWeighted(img, 0.85, paper_texture, 0.15, 0)
    
    # 添加一些噪声
    noise = np.random.normal(0, 3, (h, w, 3)).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    
    # 随机旋转
    angle = random.uniform(-2, 2)
    M = cv2.getRotationMatrix2D((w/2, h/2), angle, 1)
    img = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
    
    return img

def train_demo_model():
    """训练一个演示模型"""
    print("\n2. 训练演示模型...")
    
    import yaml
    from torch.utils.data import DataLoader
    from models.image2wave import Image2Wave
    from data.synth_dataset import (
        generate_synthetic_ecg_signals,
        SynthECGDataset,
        get_synth_transforms
    )
    
    # 加载配置
    with open('configs/config.yaml', 'r') as f:
        cfg = yaml.safe_load(f)
    
    # 生成训练数据
    print("  生成训练数据...")
    signals = generate_synthetic_ecg_signals(num_samples=1000)
    
    # 创建数据集和加载器
    transforms = get_synth_transforms()
    dataset = SynthECGDataset(signals, transforms=transforms)
    loader = DataLoader(dataset, batch_size=4, shuffle=True, num_workers=2)
    
    # 创建模型
    model = Image2Wave(seq_len=1024)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    
    # 创建优化器和损失函数
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    
    # 训练几个epoch
    num_epochs = 5
    print(f"  在{device}上训练{num_epochs}个epoch...")
    
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        
        pbar = tqdm(loader, desc=f'Epoch {epoch+1}/{num_epochs}')
        
        for batch in pbar:
            images = torch.tensor(batch['image']).permute(0, 3, 1, 2).float().to(device) / 255.0
            y_target = torch.tensor(batch['y_target']).float().to(device)
            
            optimizer.zero_grad()
            mask_logits, pred_seq = model(images)
            
            # 简化的损失计算
            loss = torch.nn.SmoothL1Loss()(pred_seq, y_target)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            pbar.set_postfix({'loss': total_loss / (pbar.n + 1)})
        
        avg_loss = total_loss / len(loader)
        print(f"  Epoch {epoch+1} 平均损失: {avg_loss:.4f}")
    
    # 保存模型
    demo_ckpt_dir = 'demo_checkpoints'
    os.makedirs(demo_ckpt_dir, exist_ok=True)
    ckpt_path = os.path.join(demo_ckpt_dir, 'demo_model.pth')
    torch.save(model.state_dict(), ckpt_path)
    
    print(f"  模型已保存到: {ckpt_path}")
    
    return model, ckpt_path

def export_demo_onnx(ckpt_path):
    """导出演示ONNX模型"""
    print("\n3. 导出ONNX模型...")
    
    from models.image2wave import Image2Wave
    
    # 创建模型
    model = Image2Wave(seq_len=1024)
    model.load_state_dict(torch.load(ckpt_path, map_location='cpu'))
    model.eval()
    
    # 虚拟输入
    dummy_input = torch.randn(1, 3, 512, 1024)
    
    # 导出ONNX
    onnx_path = 'demo_model.onnx'
    torch.onnx.export(
        model,
        dummy_input,
        onnx_path,
        input_names=['input_image'],
        output_names=['mask_logits', 'pred_seq'],
        dynamic_axes={
            'input_image': {0: 'batch', 2: 'height', 3: 'width'},
            'mask_logits': {0: 'batch', 2: 'height', 3: 'width'},
            'pred_seq': {0: 'batch', 1: 'seq_length'}
        },
        opset_version=13,
        do_constant_folding=True
    )
    
    print(f"  ONNX模型已导出到: {onnx_path}")
    
    return onnx_path

def run_demo_inference(onnx_path, image_paths):
    """运行演示推理"""
    print("\n4. 运行推理演示...")
    
    from infer_onnx import ECGImageProcessor
    
    # 创建处理器
    processor = ECGImageProcessor(onnx_path, use_gpu=torch.cuda.is_available())
    
    # 推理
    results = []
    for img_path in image_paths:
        print(f"  处理图像: {os.path.basename(img_path)}")
        result = processor.predict(img_path)
        results.append((img_path, result))
        
        # 打印基本信息
        print(f"    信号长度: {len(result['signal_values'])}")
        print(f"    置信度: {result['confidence']:.3f}")
        print(f"    处理时间: {result['timing']['total']:.3f}秒")
    
    return results

def create_visualization(image_paths, results, original_signals):
    """创建可视化结果"""
    print("\n5. 创建可视化结果...")
    
    # 创建输出目录
    viz_dir = 'demo_visualizations'
    os.makedirs(viz_dir, exist_ok=True)
    
    for i, (img_path, result) in enumerate(results):
        # 读取原始图像
        img = cv2.imread(img_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # 获取原始信号（如果有的话）
        orig_signal = original_signals[i] if i < len(original_signals) else None
        
        # 创建子图
        fig = plt.figure(figsize=(16, 12))
        
        # 1. 原始图像
        ax1 = plt.subplot(3, 2, 1)
        ax1.imshow(img)
        ax1.set_title('Input ECG Image')
        ax1.axis('off')
        
        # 2. 预测的掩码
        ax2 = plt.subplot(3, 2, 2)
        mask_vis = result['mask'][0, 0]
        ax2.imshow(mask_vis, cmap='viridis')
        ax2.set_title('Predicted Mask')
        ax2.axis('off')
        
        # 3. 原始信号 vs 预测信号
        ax3 = plt.subplot(3, 2, 3)
        if orig_signal is not None:
            # 插值原始信号到相同长度
            from scipy import interpolate
            f = interpolate.interp1d(
                np.linspace(0, 1, len(orig_signal)),
                orig_signal
            )
            orig_interp = f(np.linspace(0, 1, len(result['signal_values'])))
            ax3.plot(orig_interp, 'b-', linewidth=2, label='Original Signal')
        
        ax3.plot(result['signal_values'], 'r--', linewidth=2, label='Predicted Signal')
        ax3.set_title('Signal Comparison')
        ax3.set_xlabel('Time')
        ax3.set_ylabel('Amplitude')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # 4. 预测序列在图像上的叠加
        ax4 = plt.subplot(3, 2, 4)
        img_with_pred = img.copy()
        pred_seq = result['predicted_sequence']
        
        # 绘制预测序列
        for x, y in enumerate(pred_seq):
            y = int(round(y))
            if 0 <= y < img_with_pred.shape[0]:
                img_with_pred[y-1:y+2, x-1:x+2] = [255, 0, 0]
        
        ax4.imshow(img_with_pred)
        ax4.set_title('Predicted Sequence Overlay')
        ax4.axis('off')
        
        # 5. 信号细节
        ax5 = plt.subplot(3, 2, 5)
        ax5.plot(result['signal_values'], 'g-', linewidth=2)
        ax5.set_title('Predicted Signal Detail')
        ax5.set_xlabel('Sample')
        ax5.set_ylabel('Amplitude')
        ax5.grid(True, alpha=0.3)
        
        # 6. 统计信息
        ax6 = plt.subplot(3, 2, 6)
        ax6.axis('off')
        
        stats_text = f"""
Inference Statistics:
=====================
Signal Length: {len(result['signal_values'])} samples
Confidence: {result['confidence']:.3f}
Processing Time: {result['timing']['total']:.3f}s

Timing Breakdown:
- Preprocess: {result['timing']['preprocess']:.3f}s
- Inference: {result['timing']['inference']:.3f}s
- Postprocess: {result['timing']['postprocess']:.3f}s

Signal Characteristics:
- Min: {result['signal_values'].min():.3f}
- Max: {result['signal_values'].max():.3f}
- Mean: {result['signal_values'].mean():.3f}
- Std: {result['signal_values'].std():.3f}
        """
        
        ax6.text(0.05, 0.95, stats_text, transform=ax6.transAxes,
                verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout()
        
        # 保存图像
        viz_path = os.path.join(viz_dir, f'demo_result_{i+1}.png')
        plt.savefig(viz_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"  可视化结果已保存: {viz_path}")
    
    return viz_dir

def create_summary_report(results):
    """创建总结报告"""
    print("\n6. 生成总结报告...")
    
    report_path = 'demo_summary_report.md'
    
    report_content = f"""# Image2Wave 演示报告

## 概述
本报告展示了Image2Wave系统从ECG图像到数字化波形的完整转换过程。

## 实验配置
- **模型**: Image2Wave (U-Net + Transformer)
- **训练数据**: 1000个合成ECG信号
- **训练轮数**: 5个epoch
- **推理设备**: {'GPU' if torch.cuda.is_available() else 'CPU'}

## 性能指标

### 总体性能
- **平均处理时间**: {np.mean([r[1]['timing']['total'] for r in results]):.3f}秒
- **平均置信度**: {np.mean([r[1]['confidence'] for r in results]):.3f}

### 各阶段时间分布
| 阶段 | 平均时间 (秒) | 占比 |
|------|--------------|------|
| 预处理 | {np.mean([r[1]['timing']['preprocess'] for r in results]):.3f} | {np.mean([r[1]['timing']['preprocess']/r[1]['timing']['total'] for r in results])*100:.1f}% |
| 推理 | {np.mean([r[1]['timing']['inference'] for r in results]):.3f} | {np.mean([r[1]['timing']['inference']/r[1]['timing']['total'] for r in results])*100:.1f}% |
| 后处理 | {np.mean([r[1]['timing']['postprocess'] for r in results]):.3f} | {np.mean([r[1]['timing']['postprocess']/r[1]['timing']['total'] for r in results])*100:.1f}% |

### 信号质量
| 图像 | 信号长度 | 置信度 | 处理时间 |
|------|----------|--------|----------|"""
    
    for i, (img_path, result) in enumerate(results):
        img_name = os.path.basename(img_path)
        report_content += f"\n| {img_name} | {len(result['signal_values'])} | {result['confidence']:.3f} | {result['timing']['total']:.3f}s |"
    
    report_content += f"""

## 结论
1. 系统成功将ECG图像转换为数字化波形数据
2. 平均处理时间为{np.mean([r[1]['timing']['total'] for r in results]):.3f}秒，满足实时性要求
3. 预测置信度平均为{np.mean([r[1]['confidence'] for r in results]):.3f}，表明结果可靠性良好
4. 生成的波形数据可用于进一步的ECG分析和诊断

## 建议
1. 使用更多真实数据进行训练以提高精度
2. 针对特定的ECG设备和纸张类型进行微调
3. 在临床应用前进行充分的验证测试
"""
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    print(f"  总结报告已生成: {report_path}")
    
    return report_path

def main():
    """主演示函数"""
    print("=" * 60)
    print("Image2Wave 完整流程演示")
    print("=" * 60)
    
    try:
        start_time = time.time()
        
        # 1. 创建演示图像
        image_paths, original_signals = create_demo_images(num_images=3)
        
        # 2. 训练演示模型
        model, ckpt_path = train_demo_model()
        
        # 3. 导出ONNX模型
        onnx_path = export_demo_onnx(ckpt_path)
        
        # 4. 运行推理
        results = run_demo_inference(onnx_path, image_paths)
        
        # 5. 创建可视化
        viz_dir = create_visualization(image_paths, results, original_signals)
        
        # 6. 生成报告
        report_path = create_summary_report(results)
        
        total_time = time.time() - start_time
        
        print("\n" + "=" * 60)
        print("演示完成！")
        print("=" * 60)
        print(f"总耗时: {total_time:.1f}秒")
        print(f"\n生成的文件:")
        print(f"- 演示图像: demo_data/")
        print(f"- 模型文件: {ckpt_path}, {onnx_path}")
        print(f"- 可视化结果: {viz_dir}/")
        print(f"- 总结报告: {report_path}")
        
        return True
        
    except KeyboardInterrupt:
        print("\n演示被用户中断")
        return False
    except Exception as e:
        print(f"\n演示过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    # 切换到项目根目录
    project_root = os.path.dirname(os.path.abspath(__file__))
    os.chdir(project_root)
    
    # 运行演示
    success = main()
    sys.exit(0 if success else 1)