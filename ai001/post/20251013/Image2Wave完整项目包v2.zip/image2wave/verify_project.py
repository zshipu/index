"""
简化的项目验证脚本
"""
import os
import sys
import numpy as np
import torch

def test_basic_functionality():
    """测试项目基本功能"""
    print("=" * 60)
    print("Image2Wave 项目基本功能验证")
    print("=" * 60)
    
    all_passed = True
    
    # 1. 测试数据生成
    print("\n1. 测试数据生成模块...")
    try:
        from data.synth_dataset import generate_synthetic_ecg_signals, SynthECGDataset
        
        # 生成少量合成信号
        signals = generate_synthetic_ecg_signals(num_samples=2, duration=1)
        print(f"✓ 生成了 {len(signals)} 个合成信号")
        
        # 创建数据集
        dataset = SynthECGDataset(signals, transforms=None)
        print(f"✓ 创建了包含 {len(dataset)} 个样本的数据集")
        
        # 获取样本
        sample = dataset[0]
        print(f"✓ 样本图像形状: {sample['image'].shape}")
        print(f"✓ 目标序列形状: {sample['y_target'].shape}")
        
    except Exception as e:
        print(f"✗ 数据生成模块失败: {e}")
        all_passed = False
    
    # 2. 测试模型导入
    print("\n2. 测试模型模块导入...")
    try:
        from models.unet_encoder import UNetEncoder
        from models.transformer_decoder import TransformerDecoder
        from models.image2wave import Image2Wave
        
        print("✓ 所有模型模块导入成功")
        
    except Exception as e:
        print(f"✗ 模型模块导入失败: {e}")
        all_passed = False
    
    # 3. 测试配置文件
    print("\n3. 测试配置文件...")
    try:
        import yaml
        
        with open('configs/config.yaml', 'r') as f:
            cfg = yaml.safe_load(f)
        
        print("✓ 配置文件加载成功")
        print(f"  训练批次大小: {cfg['train']['batch_size']}")
        print(f"  学习率: {cfg['train']['lr']}")
        print(f"  训练轮数: {cfg['train']['epochs']}")
        
    except Exception as e:
        print(f"✗ 配置文件测试失败: {e}")
        all_passed = False
    
    # 4. 测试训练脚本导入
    print("\n4. 测试训练脚本导入...")
    try:
        # 只测试导入，不实际运行
        import train
        print("✓ 训练脚本导入成功")
        
    except Exception as e:
        print(f"✗ 训练脚本导入失败: {e}")
        all_passed = False
    
    # 5. 测试ONNX相关模块
    print("\n5. 测试ONNX相关模块...")
    try:
        import onnx
        import onnxruntime
        
        print("✓ ONNX模块导入成功")
        print(f"  ONNX版本: {onnx.__version__}")
        print(f"  ONNX Runtime版本: {onnxruntime.__version__}")
        
    except Exception as e:
        print(f"✗ ONNX模块导入失败: {e}")
        all_passed = False
    
    # 6. 测试推理脚本导入
    print("\n6. 测试推理脚本导入...")
    try:
        # 只测试导入，不实际运行
        import infer_onnx
        print("✓ 推理脚本导入成功")
        
    except Exception as e:
        print(f"✗ 推理脚本导入失败: {e}")
        all_passed = False
    
    # 总结
    print("\n" + "=" * 60)
    if all_passed:
        print("✓ 所有基本功能验证通过！")
        print("\n项目状态良好，可以进行实际使用。")
        print("建议按照以下步骤开始:")
        print("1. 运行 python train.py 开始训练")
        print("2. 运行 python export_onnx.py 导出模型")
        print("3. 运行 python infer_onnx.py 进行推理")
    else:
        print("✗ 部分功能验证失败，请检查相关模块。")
    
    return all_passed

if __name__ == "__main__":
    # 切换到项目根目录
    project_root = os.path.dirname(os.path.abspath(__file__))
    os.chdir(project_root)
    
    # 运行验证
    success = test_basic_functionality()
    sys.exit(0 if success else 1)