"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Heart, Watch, Target, CheckCircle2 } from "lucide-react"

export default function OnboardingPage() {
  const [step, setStep] = useState(1)

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-background to-background">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
              <Heart className="w-7 h-7 text-primary-foreground" fill="currentColor" />
            </div>
          </div>
          <CardTitle className="text-2xl">个性化设置</CardTitle>
          <CardDescription>帮助我们了解您的健康目标</CardDescription>

          {/* Progress */}
          <div className="flex items-center justify-center gap-2 mt-6">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className={`h-2 rounded-full transition-all ${i <= step ? "w-12 bg-primary" : "w-8 bg-muted"}`}
              />
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Watch className="w-5 h-5 text-primary" />
                  您有 Apple Watch 吗？
                </h3>
                <RadioGroup defaultValue="yes" className="space-y-3">
                  <div className="flex items-center space-x-3 p-4 rounded-lg border border-border hover:border-primary transition-colors cursor-pointer">
                    <RadioGroupItem value="yes" id="watch-yes" />
                    <Label htmlFor="watch-yes" className="flex-1 cursor-pointer">
                      <div className="font-medium">是的，我有 Apple Watch</div>
                      <div className="text-sm text-muted-foreground">可以使用 ECG 功能</div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-4 rounded-lg border border-border hover:border-primary transition-colors cursor-pointer">
                    <RadioGroupItem value="no" id="watch-no" />
                    <Label htmlFor="watch-no" className="flex-1 cursor-pointer">
                      <div className="font-medium">没有，但计划购买</div>
                      <div className="text-sm text-muted-foreground">我们会提供购买建议</div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              <Button className="w-full" size="lg" onClick={() => setStep(2)}>
                下一步
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  您的健康目标是什么？
                </h3>
                <div className="space-y-3">
                  {[
                    { id: "monitor", label: "日常心脏健康监测", desc: "了解心脏状态" },
                    { id: "condition", label: "管理已知心脏疾病", desc: "跟踪病情变化" },
                    { id: "fitness", label: "提升运动表现", desc: "优化训练效果" },
                    { id: "stress", label: "压力和焦虑管理", desc: "改善心理健康" },
                  ].map((goal) => (
                    <div
                      key={goal.id}
                      className="flex items-center space-x-3 p-4 rounded-lg border border-border hover:border-primary transition-colors cursor-pointer"
                    >
                      <input type="checkbox" id={goal.id} className="w-4 h-4" />
                      <Label htmlFor={goal.id} className="flex-1 cursor-pointer">
                        <div className="font-medium">{goal.label}</div>
                        <div className="text-sm text-muted-foreground">{goal.desc}</div>
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 bg-transparent" onClick={() => setStep(1)}>
                  上一步
                </Button>
                <Button className="flex-1" onClick={() => setStep(3)}>
                  下一步
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6 text-center">
              <div className="flex justify-center">
                <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10 text-success" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-semibold mb-2">设置完成！</h3>
                <p className="text-muted-foreground">您的个性化健康监测已准备就绪</p>
              </div>
              <div className="bg-muted/50 rounded-lg p-6 space-y-3 text-left">
                <h4 className="font-semibold">接下来：</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>连接您的 Apple Watch</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>完成首次心电测量</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>查看您的 SignalValue 评分</span>
                  </li>
                </ul>
              </div>
              <Button className="w-full" size="lg" asChild>
                <Link href="/dashboard">进入控制台</Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
