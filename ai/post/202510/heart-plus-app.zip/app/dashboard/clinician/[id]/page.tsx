"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Activity, Heart, Clock, AlertCircle, Send, Save, User, Calendar, TrendingUp } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function ClinicianReviewDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [diagnosis, setDiagnosis] = useState("")
  const [recommendation, setRecommendation] = useState("")
  const [severity, setSeverity] = useState("normal")
  const [followUp, setFollowUp] = useState(false)
  const [referral, setReferral] = useState(false)

  // Mock data
  const review = {
    id: params.id,
    measurementId: "meas-789",
    patient: {
      name: "张伟",
      id: "user-123",
      age: 45,
      gender: "男",
      medicalHistory: ["高血压", "糖尿病"],
      medications: ["降压药", "二甲双胍"],
    },
    measurement: {
      signalValue: 92,
      heartRate: 145,
      hrv: 28,
      timestamp: "2024-01-15 14:30:25",
      duration: 30,
      quality: "excellent",
    },
    symptoms: ["心悸", "胸闷"],
    reason: "检测到罕见心律事件",
    aiAnalysis: {
      rhythm: "窦性心律伴频发室性早搏",
      findings: [
        "心率145 bpm，超出正常范围",
        "检测到12次室性早搏（PVC）",
        "QRS波群形态正常",
        "PR间期正常（160ms）",
        "QT间期正常（380ms）",
      ],
      confidence: 0.89,
      riskLevel: "medium",
    },
    context: {
      recentActivity: "运动后30分钟",
      stressLevel: "high",
      sleepQuality: "poor",
      recentMeasurements: [
        { date: "2024-01-14", hr: 72, signalValue: 65 },
        { date: "2024-01-13", hr: 68, signalValue: 58 },
        { date: "2024-01-12", hr: 75, signalValue: 62 },
      ],
    },
  }

  const handleSubmit = () => {
    console.log("[v0] Submitting review:", { diagnosis, recommendation, severity, followUp, referral })
    // In real app, would submit to API
    router.push("/dashboard/clinician")
  }

  const handleSaveDraft = () => {
    console.log("[v0] Saving draft")
    // In real app, would save draft to API
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard/clinician">
              <ArrowLeft className="w-5 h-5" />
            </Link>
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground mb-1">专家审阅</h1>
            <p className="text-sm text-muted-foreground">审阅编号: {review.id}</p>
          </div>
          <Badge variant="destructive">高优先级</Badge>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Left Column - Patient & Measurement Info */}
          <div className="md:col-span-2 space-y-6">
            {/* Patient Info */}
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-foreground">{review.patient.name}</h2>
                  <p className="text-sm text-muted-foreground">
                    {review.patient.age}岁 · {review.patient.gender} · ID: {review.patient.id}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-muted-foreground mb-1">既往病史</div>
                  <div className="flex flex-wrap gap-2">
                    {review.patient.medicalHistory.map((item) => (
                      <Badge key={item} variant="secondary" className="text-xs">
                        {item}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">当前用药</div>
                  <div className="flex flex-wrap gap-2">
                    {review.patient.medications.map((item) => (
                      <Badge key={item} variant="secondary" className="text-xs">
                        {item}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* Measurement Data */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">测量数据</h3>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span className="text-xs text-muted-foreground">心率</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground">{review.measurement.heartRate}</div>
                  <div className="text-xs text-muted-foreground">bpm</div>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Activity className="w-4 h-4 text-primary" />
                    <span className="text-xs text-muted-foreground">HRV</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground">{review.measurement.hrv}</div>
                  <div className="text-xs text-muted-foreground">ms</div>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    <span className="text-xs text-muted-foreground">SignalValue</span>
                  </div>
                  <div className="text-2xl font-bold text-primary">{review.measurement.signalValue}</div>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">时长</span>
                  </div>
                  <div className="text-2xl font-bold text-foreground">{review.measurement.duration}</div>
                  <div className="text-xs text-muted-foreground">秒</div>
                </div>
              </div>

              {/* ECG Waveform Visualization */}
              <div className="mb-4">
                <div className="text-sm font-medium text-foreground mb-2">心电图波形</div>
                <div className="h-48 bg-muted/30 rounded-lg border-2 border-muted flex items-center justify-center relative overflow-hidden">
                  <svg className="w-full h-full" viewBox="0 0 800 200" preserveAspectRatio="none">
                    <path
                      d="M 0 100 L 50 100 L 55 100 L 60 40 L 65 100 L 70 110 L 90 110 L 95 100 L 150 100 L 155 100 L 160 40 L 165 100 L 170 110 L 190 110 L 195 100 L 250 100 L 255 100 L 260 40 L 265 100 L 270 110 L 290 110 L 295 100 L 350 100 L 355 100 L 360 40 L 365 100 L 370 110 L 390 110 L 395 100 L 450 100 L 455 100 L 460 40 L 465 100 L 470 110 L 490 110 L 495 100 L 550 100 L 555 100 L 560 40 L 565 100 L 570 110 L 590 110 L 595 100 L 650 100 L 655 100 L 660 40 L 665 100 L 670 110 L 690 110 L 695 100 L 750 100 L 755 100 L 760 40 L 765 100 L 770 110 L 790 110 L 795 100 L 800 100"
                      stroke="hsl(var(--primary))"
                      strokeWidth="2"
                      fill="none"
                    />
                    {/* Highlight abnormal beats */}
                    <circle cx="260" cy="40" r="8" fill="red" opacity="0.3" />
                    <circle cx="560" cy="40" r="8" fill="red" opacity="0.3" />
                  </svg>
                  <div className="absolute top-2 right-2 bg-red-500/10 text-red-600 text-xs px-2 py-1 rounded border border-red-500/20">
                    检测到异常波形
                  </div>
                </div>
              </div>

              {/* Symptoms & Context */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-foreground mb-2">患者症状</div>
                  <div className="flex flex-wrap gap-2">
                    {review.symptoms.map((symptom) => (
                      <Badge
                        key={symptom}
                        variant="outline"
                        className="bg-orange-500/10 text-orange-600 border-orange-500/20"
                      >
                        {symptom}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground mb-2">测量背景</div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>活动: {review.context.recentActivity}</div>
                    <div>压力水平: {review.context.stressLevel}</div>
                    <div>睡眠质量: {review.context.sleepQuality}</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* AI Analysis */}
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold text-foreground">AI分析结果</h3>
                <Badge variant="outline" className="ml-auto">
                  置信度: {(review.aiAnalysis.confidence * 100).toFixed(0)}%
                </Badge>
              </div>

              <div className="mb-4 p-4 bg-primary/5 rounded-lg border border-primary/20">
                <div className="text-sm font-medium text-foreground mb-1">初步诊断</div>
                <div className="text-base text-foreground">{review.aiAnalysis.rhythm}</div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-foreground mb-2">详细发现</div>
                {review.aiAnalysis.findings.map((finding, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" />
                    <span>{finding}</span>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-3 bg-orange-500/10 rounded-lg border border-orange-500/20">
                <div className="flex items-center gap-2 text-orange-600">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">风险等级: 中等</span>
                </div>
              </div>
            </Card>

            {/* Historical Trend */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">近期趋势</h3>
              <div className="space-y-3">
                {review.context.recentMeasurements.map((m, index) => (
                  <div key={index} className="flex items-center gap-4 p-3 bg-muted/30 rounded-lg">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-foreground">{m.date}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">心率: {m.hr} bpm</div>
                      <div className="text-xs text-muted-foreground">SignalValue: {m.signalValue}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Right Column - Review Form */}
          <div className="space-y-6">
            <Card className="p-6 sticky top-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">审阅意见</h3>

              <div className="space-y-4">
                {/* Severity */}
                <div>
                  <Label className="text-sm font-medium text-foreground mb-2 block">严重程度</Label>
                  <RadioGroup value={severity} onValueChange={setSeverity}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="normal" id="normal" />
                      <Label htmlFor="normal" className="text-sm cursor-pointer">
                        正常
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="mild" id="mild" />
                      <Label htmlFor="mild" className="text-sm cursor-pointer">
                        轻度异常
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="moderate" id="moderate" />
                      <Label htmlFor="moderate" className="text-sm cursor-pointer">
                        中度异常
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="severe" id="severe" />
                      <Label htmlFor="severe" className="text-sm cursor-pointer">
                        严重异常
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Diagnosis */}
                <div>
                  <Label htmlFor="diagnosis" className="text-sm font-medium text-foreground mb-2 block">
                    诊断结果
                  </Label>
                  <Textarea
                    id="diagnosis"
                    placeholder="请输入详细的诊断结果..."
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>

                {/* Recommendation */}
                <div>
                  <Label htmlFor="recommendation" className="text-sm font-medium text-foreground mb-2 block">
                    医疗建议
                  </Label>
                  <Textarea
                    id="recommendation"
                    placeholder="请输入医疗建议和注意事项..."
                    value={recommendation}
                    onChange={(e) => setRecommendation(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>

                {/* Follow-up Options */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="followUp"
                      checked={followUp}
                      onCheckedChange={(checked) => setFollowUp(checked as boolean)}
                    />
                    <Label htmlFor="followUp" className="text-sm cursor-pointer">
                      需要随访复查
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="referral"
                      checked={referral}
                      onCheckedChange={(checked) => setReferral(checked as boolean)}
                    />
                    <Label htmlFor="referral" className="text-sm cursor-pointer">
                      建议转诊专科
                    </Label>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 pt-4">
                  <Button onClick={handleSubmit} className="w-full">
                    <Send className="w-4 h-4 mr-2" />
                    提交审阅报告
                  </Button>
                  <Button onClick={handleSaveDraft} variant="outline" className="w-full bg-transparent">
                    <Save className="w-4 h-4 mr-2" />
                    保存草稿
                  </Button>
                </div>
              </div>
            </Card>

            {/* Quick Reference */}
            <Card className="p-4">
              <h4 className="text-sm font-semibold text-foreground mb-3">快速参考</h4>
              <div className="space-y-2 text-xs text-muted-foreground">
                <div>正常心率: 60-100 bpm</div>
                <div>正常HRV: 20-200 ms</div>
                <div>PR间期: 120-200 ms</div>
                <div>QRS时限: 60-100 ms</div>
                <div>QT间期: 350-450 ms</div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
