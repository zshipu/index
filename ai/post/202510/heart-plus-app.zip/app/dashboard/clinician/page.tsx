"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Clock, CheckCircle2, Calendar, TrendingUp, FileText, Star } from "lucide-react"
import Link from "next/link"

export default function ClinicianReviewPage() {
  const [selectedTab, setSelectedTab] = useState("pending")

  const pendingReviews = [
    {
      id: "rev-001",
      measurementId: "meas-789",
      patientName: "张伟",
      patientId: "user-123",
      signalValue: 92,
      priority: "high",
      reason: "检测到罕见心律事件",
      submittedAt: "2024-01-15 14:30",
      waitTime: "2小时",
      symptoms: ["心悸", "胸闷"],
      heartRate: 145,
      tags: ["高心率", "PAC检出"],
    },
    {
      id: "rev-002",
      measurementId: "meas-790",
      patientName: "李娜",
      patientId: "user-124",
      signalValue: 88,
      priority: "medium",
      reason: "用户主动请求专家审阅",
      submittedAt: "2024-01-15 15:45",
      waitTime: "45分钟",
      symptoms: ["头晕"],
      heartRate: 52,
      tags: ["低心率", "窦性心律"],
    },
    {
      id: "rev-003",
      measurementId: "meas-791",
      patientName: "王强",
      patientId: "user-125",
      signalValue: 95,
      priority: "high",
      reason: "AI检测到异常模式",
      submittedAt: "2024-01-15 16:20",
      waitTime: "10分钟",
      symptoms: ["胸痛", "气短", "出汗"],
      heartRate: 168,
      tags: ["高心率", "疑似房颤"],
    },
  ]

  const completedReviews = [
    {
      id: "rev-004",
      measurementId: "meas-785",
      patientName: "赵敏",
      patientId: "user-126",
      signalValue: 85,
      clinician: "李医生",
      diagnosis: "窦性心律，偶发室性早搏",
      recommendation: "建议继续观察，保持良好作息",
      reviewedAt: "2024-01-15 13:20",
      reviewTime: "8分钟",
      rating: 5,
    },
    {
      id: "rev-005",
      measurementId: "meas-786",
      patientName: "孙丽",
      patientId: "user-127",
      signalValue: 78,
      clinician: "王医生",
      diagnosis: "窦性心律",
      recommendation: "心电图正常，无需特殊处理",
      reviewedAt: "2024-01-15 12:45",
      reviewTime: "5分钟",
      rating: 5,
    },
  ]

  const stats = {
    pending: 3,
    inProgress: 1,
    completedToday: 12,
    avgResponseTime: "15分钟",
    avgReviewTime: "8分钟",
    satisfaction: 4.8,
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">专家审阅</h1>
          <p className="text-muted-foreground">高价值心电图的专业医生审阅服务</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-orange-500" />
              <span className="text-sm text-muted-foreground">待审阅</span>
            </div>
            <div className="text-2xl font-bold text-foreground">{stats.pending}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Activity className="w-4 h-4 text-blue-500" />
              <span className="text-sm text-muted-foreground">进行中</span>
            </div>
            <div className="text-2xl font-bold text-foreground">{stats.inProgress}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span className="text-sm text-muted-foreground">今日完成</span>
            </div>
            <div className="text-2xl font-bold text-foreground">{stats.completedToday}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">平均响应</span>
            </div>
            <div className="text-lg font-bold text-foreground">{stats.avgResponseTime}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Calendar className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">平均时长</span>
            </div>
            <div className="text-lg font-bold text-foreground">{stats.avgReviewTime}</div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Star className="w-4 h-4 text-yellow-500" />
              <span className="text-sm text-muted-foreground">满意度</span>
            </div>
            <div className="text-lg font-bold text-foreground">{stats.satisfaction}</div>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="pending">待审阅 ({stats.pending})</TabsTrigger>
            <TabsTrigger value="completed">已完成 ({stats.completedToday})</TabsTrigger>
          </TabsList>

          {/* Pending Reviews */}
          <TabsContent value="pending" className="space-y-4">
            {pendingReviews.map((review) => (
              <Card key={review.id} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-foreground">{review.patientName}</h3>
                      <Badge variant={review.priority === "high" ? "destructive" : "secondary"}>
                        {review.priority === "high" ? "高优先级" : "中优先级"}
                      </Badge>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        SignalValue: {review.signalValue}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{review.reason}</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {review.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground mb-1">等待时间</div>
                    <div className="text-lg font-semibold text-orange-500">{review.waitTime}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 p-4 bg-muted/50 rounded-lg">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">心率</div>
                    <div className="text-lg font-semibold text-foreground">{review.heartRate} bpm</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">提交时间</div>
                    <div className="text-sm text-foreground">{review.submittedAt}</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-xs text-muted-foreground mb-1">症状</div>
                    <div className="text-sm text-foreground">{review.symptoms.join("、")}</div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button asChild className="flex-1">
                    <Link href={`/dashboard/clinician/${review.id}`}>
                      <FileText className="w-4 h-4 mr-2" />
                      开始审阅
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href={`/dashboard/measurements/${review.measurementId}`}>查看详情</Link>
                  </Button>
                </div>
              </Card>
            ))}
          </TabsContent>

          {/* Completed Reviews */}
          <TabsContent value="completed" className="space-y-4">
            {completedReviews.map((review) => (
              <Card key={review.id} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-foreground">{review.patientName}</h3>
                      <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        已完成
                      </Badge>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        SignalValue: {review.signalValue}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-1">审阅医生: {review.clinician}</div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-yellow-500 mb-1">
                      {Array.from({ length: review.rating }).map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                    <div className="text-xs text-muted-foreground">用户评分</div>
                  </div>
                </div>

                <div className="space-y-3 mb-4 p-4 bg-muted/50 rounded-lg">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">诊断结果</div>
                    <div className="text-sm font-medium text-foreground">{review.diagnosis}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">医生建议</div>
                    <div className="text-sm text-foreground">{review.recommendation}</div>
                  </div>
                  <div className="flex gap-6 text-xs text-muted-foreground">
                    <div>审阅时间: {review.reviewedAt}</div>
                    <div>用时: {review.reviewTime}</div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button variant="outline" asChild className="flex-1 bg-transparent">
                    <Link href={`/dashboard/clinician/${review.id}`}>
                      <FileText className="w-4 h-4 mr-2" />
                      查看完整报告
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href={`/dashboard/measurements/${review.measurementId}`}>原始数据</Link>
                  </Button>
                </div>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
