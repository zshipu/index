"use client"

import { useState } from "react"
import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Wind, Brain, Coffee, Bed, Heart, ArrowLeft, TrendingDown, CheckCircle2 } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function NewBiofeedbackPage() {
  const router = useRouter()
  const [step, setStep] = useState<"select" | "pre-measure" | "activity" | "post-measure" | "complete">("select")
  const [selectedActivity, setSelectedActivity] = useState<string>("")
  const [preBpm, setPreBpm] = useState<number>(0)
  const [postBpm, setPostBpm] = useState<number>(0)
  const [activityProgress, setActivityProgress] = useState(0)

  const activities = [
    {
      id: "breathing",
      name: "呼吸练习",
      icon: Wind,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
      duration: "5 分钟",
      description: "深呼吸练习可以快速降低心率和压力水平",
    },
    {
      id: "meditation",
      name: "冥想",
      icon: Brain,
      color: "text-primary",
      bgColor: "bg-primary/10",
      duration: "10 分钟",
      description: "正念冥想帮助放松身心，改善心率变异性",
    },
    {
      id: "coffee",
      name: "咖啡因",
      icon: Coffee,
      color: "text-chart-3",
      bgColor: "bg-chart-3/10",
      duration: "30 分钟",
      description: "观察咖啡因对心率的影响",
    },
    {
      id: "sleep",
      name: "睡眠",
      icon: Bed,
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
      duration: "睡眠后",
      description: "测量睡眠对心率恢复的效果",
    },
  ]

  const startPreMeasure = (activityId: string) => {
    setSelectedActivity(activityId)
    setStep("pre-measure")
    // Simulate measurement
    setTimeout(() => {
      setPreBpm(82)
      setStep("activity")
    }, 3000)
  }

  const startActivity = () => {
    setActivityProgress(0)
    // Simulate activity progress
    const interval = setInterval(() => {
      setActivityProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setStep("post-measure")
          // Simulate post measurement
          setTimeout(() => {
            setPostBpm(68)
            setStep("complete")
          }, 3000)
          return 100
        }
        return prev + 2
      })
    }, 300)
  }

  const selectedActivityData = activities.find((a) => a.id === selectedActivity)

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-3xl">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" size="sm" className="mb-4" asChild>
              <Link href="/dashboard/biofeedback">
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回
              </Link>
            </Button>
            <h1 className="text-3xl font-bold mb-2">新建前后对比</h1>
            <p className="text-muted-foreground">测量活动干预对心率的即时影响</p>
          </div>

          {/* Select Activity */}
          {step === "select" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>选择活动类型</CardTitle>
                  <CardDescription>选择您想要测量效果的活动</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {activities.map((activity) => {
                      const Icon = activity.icon
                      return (
                        <button
                          key={activity.id}
                          onClick={() => startPreMeasure(activity.id)}
                          className="p-6 rounded-lg border border-border hover:border-primary hover:bg-muted/50 transition-all text-left"
                        >
                          <div
                            className={`w-14 h-14 rounded-full ${activity.bgColor} flex items-center justify-center mb-4`}
                          >
                            <Icon className={`w-7 h-7 ${activity.color}`} />
                          </div>
                          <h3 className="font-semibold text-lg mb-1">{activity.name}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{activity.description}</p>
                          <div className="text-xs text-muted-foreground">建议时长: {activity.duration}</div>
                        </button>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <h4 className="font-medium mb-2">如何使用前后对比？</h4>
                  <ol className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex gap-2">
                      <span className="font-medium text-foreground">1.</span>
                      <span>选择活动类型并进行第一次测量（前）</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-medium text-foreground">2.</span>
                      <span>完成选定的活动（如呼吸练习）</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-medium text-foreground">3.</span>
                      <span>立即进行第二次测量（后）</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="font-medium text-foreground">4.</span>
                      <span>查看活动对心率的即时影响</span>
                    </li>
                  </ol>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Pre-Measure */}
          {step === "pre-measure" && selectedActivityData && (
            <Card className="text-center">
              <CardContent className="pt-12 pb-12">
                <div
                  className={`w-24 h-24 rounded-full ${selectedActivityData.bgColor} flex items-center justify-center mx-auto mb-6 animate-pulse`}
                >
                  <Heart className="w-12 h-12 text-primary" fill="currentColor" />
                </div>
                <h2 className="text-2xl font-bold mb-2">测量前心率</h2>
                <p className="text-muted-foreground mb-8">请保持静止，手指放在 Apple Watch 表冠上</p>
                <div className="max-w-md mx-auto">
                  <Progress value={66} className="h-3" />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Activity */}
          {step === "activity" && selectedActivityData && (
            <div className="space-y-6">
              <Card className="bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
                <CardContent className="pt-12 pb-12 text-center">
                  <div
                    className={`w-24 h-24 rounded-full ${selectedActivityData.bgColor} flex items-center justify-center mx-auto mb-6`}
                  >
                    {(() => {
                      const Icon = selectedActivityData.icon
                      return <Icon className={`w-12 h-12 ${selectedActivityData.color}`} />
                    })()}
                  </div>
                  <h2 className="text-2xl font-bold mb-2">前测量完成</h2>
                  <div className="flex items-center justify-center gap-2 mb-6">
                    <Heart className="w-5 h-5 text-muted-foreground" />
                    <span className="text-4xl font-bold">{preBpm}</span>
                    <span className="text-muted-foreground">bpm</span>
                  </div>
                  <p className="text-muted-foreground">现在开始进行 {selectedActivityData.name}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{selectedActivityData.name}指导</CardTitle>
                  <CardDescription>跟随指导完成活动</CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedActivity === "breathing" && (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        深呼吸练习可以激活副交感神经系统，帮助降低心率和压力水平。
                      </p>
                      <ol className="space-y-3 text-sm">
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">1.</span>
                          <span>找一个舒适的坐姿，背部挺直</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">2.</span>
                          <span>用鼻子深吸气 4 秒</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">3.</span>
                          <span>屏住呼吸 4 秒</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">4.</span>
                          <span>用嘴慢慢呼气 6 秒</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">5.</span>
                          <span>重复 5-10 次</span>
                        </li>
                      </ol>
                    </div>
                  )}
                  {selectedActivity === "meditation" && (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        正念冥想帮助您专注当下，放松身心，改善心率变异性。
                      </p>
                      <ol className="space-y-3 text-sm">
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">1.</span>
                          <span>找一个安静的地方坐下</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">2.</span>
                          <span>闭上眼睛，专注于呼吸</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">3.</span>
                          <span>观察思绪来去，不做评判</span>
                        </li>
                        <li className="flex gap-3">
                          <span className="font-medium text-primary">4.</span>
                          <span>持续 10 分钟</span>
                        </li>
                      </ol>
                    </div>
                  )}
                  <Button className="w-full mt-6" size="lg" onClick={startActivity}>
                    开始活动
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Post-Measure */}
          {step === "post-measure" && (
            <Card className="text-center">
              <CardContent className="pt-12 pb-12">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6 animate-pulse">
                  <Heart className="w-12 h-12 text-primary" fill="currentColor" />
                </div>
                <h2 className="text-2xl font-bold mb-2">测量后心率</h2>
                <p className="text-muted-foreground mb-8">活动完成，正在测量效果</p>
                <div className="max-w-md mx-auto space-y-3">
                  <Progress value={activityProgress} className="h-3" />
                  <p className="text-sm text-muted-foreground">{Math.round(activityProgress)}% 完成</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Complete */}
          {step === "complete" && selectedActivityData && (
            <div className="space-y-6">
              <Card className="text-center bg-gradient-to-br from-success/10 via-card to-card border-success/20">
                <CardContent className="pt-12 pb-12">
                  <div className="w-24 h-24 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-12 h-12 text-success" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">对比完成</h2>
                  <p className="text-muted-foreground mb-8">{selectedActivityData.name}效果已记录</p>

                  <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-success/10 text-success font-medium text-lg">
                    <TrendingDown className="w-6 h-6" />
                    心率降低 {preBpm - postBpm} bpm
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>对比结果</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-around">
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground mb-2">活动前</div>
                      <div className="flex items-center justify-center gap-2">
                        <Heart className="w-5 h-5 text-muted-foreground" />
                        <span className="text-3xl font-bold">{preBpm}</span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">bpm</div>
                    </div>

                    <TrendingDown className="w-8 h-8 text-success" />

                    <div className="text-center">
                      <div className="text-sm text-muted-foreground mb-2">活动后</div>
                      <div className="flex items-center justify-center gap-2">
                        <Heart className="w-5 h-5 text-success" />
                        <span className="text-3xl font-bold text-success">{postBpm}</span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">bpm</div>
                    </div>
                  </div>

                  <div className="p-4 rounded-lg bg-success/5 border border-success/20">
                    <h4 className="font-medium mb-2">效果评估</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {selectedActivityData.name}使您的心率降低了 {preBpm - postBpm} bpm（
                      {Math.round(((preBpm - postBpm) / preBpm) * 100)}%），这是一个{" "}
                      {preBpm - postBpm > 10 ? "非常显著" : "良好"}的效果。继续保持这个习惯可以帮助改善您的心血管健康。
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 bg-transparent" asChild>
                  <Link href="/dashboard/biofeedback">查看历史</Link>
                </Button>
                <Button className="flex-1" onClick={() => setStep("select")}>
                  再次测量
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
