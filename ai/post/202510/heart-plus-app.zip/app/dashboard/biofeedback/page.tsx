"use client"

import { useState } from "react"
import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Activity, Heart, Wind, Brain, Coffee, Bed, Plus, TrendingDown, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function BiofeedbackPage() {
  const [selectedActivity, setSelectedActivity] = useState<string | null>(null)

  const activities = [
    { id: "breathing", name: "呼吸练习", icon: Wind, color: "text-chart-2", bgColor: "bg-chart-2/10" },
    { id: "meditation", name: "冥想", icon: Brain, color: "text-primary", bgColor: "bg-primary/10" },
    { id: "coffee", name: "咖啡因", icon: Coffee, color: "text-chart-3", bgColor: "bg-chart-3/10" },
    { id: "sleep", name: "睡眠", icon: Bed, color: "text-chart-4", bgColor: "bg-chart-4/10" },
  ]

  const comparisons = [
    {
      id: "1",
      activity: "呼吸练习",
      date: "2025-01-06",
      time: "15:30",
      preBpm: 82,
      postBpm: 68,
      change: -14,
      duration: "5 分钟",
      effectiveness: "高效",
    },
    {
      id: "2",
      activity: "冥想",
      date: "2025-01-05",
      time: "20:15",
      preBpm: 75,
      postBpm: 65,
      change: -10,
      duration: "10 分钟",
      effectiveness: "有效",
    },
    {
      id: "3",
      activity: "咖啡因",
      date: "2025-01-05",
      time: "09:00",
      preBpm: 68,
      postBpm: 78,
      change: 10,
      duration: "30 分钟后",
      effectiveness: "显著影响",
    },
  ]

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-7xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">前后对比</h1>
              <p className="text-muted-foreground">测量干预活动对心率的即时影响</p>
            </div>
            <Button size="lg" asChild>
              <Link href="/dashboard/biofeedback/new">
                <Plus className="w-5 h-5 mr-2" />
                新建对比
              </Link>
            </Button>
          </div>

          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>总对比次数</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>平均心率降低</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-success">-8 bpm</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>最有效活动</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold">呼吸练习</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>本周对比</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
              </CardContent>
            </Card>
          </div>

          {/* Activity Categories */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>活动类型</CardTitle>
              <CardDescription>选择查看特定活动的对比记录</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {activities.map((activity) => {
                  const Icon = activity.icon
                  const isSelected = selectedActivity === activity.id
                  return (
                    <button
                      key={activity.id}
                      onClick={() => setSelectedActivity(isSelected ? null : activity.id)}
                      className={`p-4 rounded-lg border transition-all ${
                        isSelected
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50 hover:bg-muted/50"
                      }`}
                    >
                      <div
                        className={`w-12 h-12 rounded-full ${activity.bgColor} flex items-center justify-center mx-auto mb-3`}
                      >
                        <Icon className={`w-6 h-6 ${activity.color}`} />
                      </div>
                      <div className="text-sm font-medium text-center">{activity.name}</div>
                    </button>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Effectiveness Insights */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>效果分析</CardTitle>
              <CardDescription>不同活动对您心率的影响</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-chart-2/10 flex items-center justify-center flex-shrink-0">
                    <Wind className="w-6 h-6 text-chart-2" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">呼吸练习</span>
                      <span className="text-sm text-success font-medium">平均 -12 bpm</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{ width: "85%" }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">8 次对比 · 效果最佳</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Brain className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">冥想</span>
                      <span className="text-sm text-success font-medium">平均 -9 bpm</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{ width: "70%" }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">6 次对比 · 效果良好</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-chart-4/10 flex items-center justify-center flex-shrink-0">
                    <Bed className="w-6 h-6 text-chart-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">睡眠</span>
                      <span className="text-sm text-success font-medium">平均 -15 bpm</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-success" style={{ width: "95%" }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">5 次对比 · 自然恢复</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-chart-3/10 flex items-center justify-center flex-shrink-0">
                    <Coffee className="w-6 h-6 text-chart-3" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">咖啡因</span>
                      <span className="text-sm text-destructive font-medium">平均 +11 bpm</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-destructive" style={{ width: "75%" }} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">5 次对比 · 刺激作用</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comparison History */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>对比历史</CardTitle>
                  <CardDescription>您的前后测量记录</CardDescription>
                </div>
                <Button variant="ghost" size="sm">
                  查看全部
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {comparisons.map((comparison) => (
                  <Card key={comparison.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                        {/* Activity Icon */}
                        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Activity className="w-7 h-7 text-primary" />
                        </div>

                        {/* Content */}
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-3">
                            <h3 className="font-semibold text-lg">{comparison.activity}</h3>
                            <Badge
                              variant={comparison.change < 0 ? "default" : "destructive"}
                              className={comparison.change < 0 ? "bg-success" : ""}
                            >
                              {comparison.change > 0 ? "+" : ""}
                              {comparison.change} bpm
                            </Badge>
                            <Badge variant="outline">{comparison.effectiveness}</Badge>
                          </div>

                          {/* Before/After Comparison */}
                          <div className="flex items-center gap-6 mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-muted-foreground">前:</span>
                              <div className="flex items-center gap-1">
                                <Heart className="w-4 h-4 text-muted-foreground" />
                                <span className="font-semibold">{comparison.preBpm}</span>
                              </div>
                            </div>

                            <TrendingDown
                              className={`w-5 h-5 ${comparison.change < 0 ? "text-success" : "text-destructive rotate-180"}`}
                            />

                            <div className="flex items-center gap-2">
                              <span className="text-sm text-muted-foreground">后:</span>
                              <div className="flex items-center gap-1">
                                <Heart className="w-4 h-4 text-muted-foreground" />
                                <span className="font-semibold">{comparison.postBpm}</span>
                              </div>
                            </div>
                          </div>

                          <p className="text-sm text-muted-foreground">持续时间: {comparison.duration}</p>
                        </div>

                        {/* Date & Action */}
                        <div className="flex items-center gap-4 lg:flex-col lg:items-end">
                          <div className="text-sm text-muted-foreground text-right">
                            <div className="font-medium text-foreground">{comparison.date}</div>
                            <div>{comparison.time}</div>
                          </div>
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={`/dashboard/biofeedback/${comparison.id}`}>查看详情</Link>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
