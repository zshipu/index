import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Activity, Plus, Filter, Heart, Zap } from "lucide-react"
import Link from "next/link"

export default function MeasurementsPage() {
  const measurements = [
    {
      id: "1",
      date: "2025-01-06",
      time: "14:32",
      signalValue: 87,
      result: "窦性心律",
      heartRate: 75,
      note: "检测到轻微变异",
      trigger: "SmartYield 触发",
      status: "high-value",
    },
    {
      id: "2",
      date: "2025-01-06",
      time: "09:15",
      signalValue: 45,
      result: "窦性心律",
      heartRate: 68,
      note: "正常范围",
      trigger: "手动测量",
      status: "normal",
    },
    {
      id: "3",
      date: "2025-01-05",
      time: "22:08",
      signalValue: 62,
      result: "窦性心律",
      heartRate: 72,
      note: "睡前测量",
      trigger: "自适应提醒",
      status: "medium-value",
    },
    {
      id: "4",
      date: "2025-01-05",
      time: "15:45",
      signalValue: 38,
      result: "窦性心律",
      heartRate: 70,
      note: "正常范围",
      trigger: "手动测量",
      status: "normal",
    },
    {
      id: "5",
      date: "2025-01-04",
      time: "18:20",
      signalValue: 78,
      result: "窦性心律",
      heartRate: 82,
      note: "运动后测量",
      trigger: "SmartYield 触发",
      status: "high-value",
    },
  ]

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-7xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">测量记录</h1>
              <p className="text-muted-foreground">查看和管理您的心电图测量历史</p>
            </div>
            <Button size="lg" asChild>
              <Link href="/dashboard/measurements/new">
                <Plus className="w-5 h-5 mr-2" />
                新建测量
              </Link>
            </Button>
          </div>

          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>总测量次数</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">156</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>高价值测量</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">23</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>平均 SignalValue</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">58</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>SmartYield 触发</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-chart-3">42</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-wrap items-center gap-3">
                <Button variant="outline" size="sm" className="bg-transparent">
                  <Filter className="w-4 h-4 mr-2" />
                  筛选
                </Button>
                <Badge variant="secondary" className="cursor-pointer">
                  全部
                </Badge>
                <Badge variant="outline" className="cursor-pointer">
                  高价值
                </Badge>
                <Badge variant="outline" className="cursor-pointer">
                  SmartYield
                </Badge>
                <Badge variant="outline" className="cursor-pointer">
                  本周
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Measurements List */}
          <div className="space-y-4">
            {measurements.map((measurement) => (
              <Card key={measurement.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    {/* Icon */}
                    <div
                      className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${
                        measurement.status === "high-value"
                          ? "bg-primary/10"
                          : measurement.status === "medium-value"
                            ? "bg-chart-3/10"
                            : "bg-muted"
                      }`}
                    >
                      <Activity
                        className={`w-7 h-7 ${
                          measurement.status === "high-value"
                            ? "text-primary"
                            : measurement.status === "medium-value"
                              ? "text-chart-3"
                              : "text-muted-foreground"
                        }`}
                      />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{measurement.result}</h3>
                        <Badge
                          variant={measurement.status === "high-value" ? "default" : "secondary"}
                          className={
                            measurement.status === "high-value"
                              ? "bg-primary"
                              : measurement.status === "medium-value"
                                ? "bg-chart-3"
                                : ""
                          }
                        >
                          SV: {measurement.signalValue}
                        </Badge>
                        {measurement.trigger.includes("SmartYield") && (
                          <Badge variant="outline" className="border-chart-3 text-chart-3">
                            <Zap className="w-3 h-3 mr-1" />
                            {measurement.trigger}
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          {measurement.heartRate} bpm
                        </span>
                        <span>{measurement.note}</span>
                      </div>
                    </div>

                    {/* Date & Action */}
                    <div className="flex items-center gap-4 lg:flex-col lg:items-end">
                      <div className="text-sm text-muted-foreground text-right">
                        <div className="font-medium text-foreground">{measurement.date}</div>
                        <div>{measurement.time}</div>
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <Link href={`/dashboard/measurements/${measurement.id}`}>查看详情</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
