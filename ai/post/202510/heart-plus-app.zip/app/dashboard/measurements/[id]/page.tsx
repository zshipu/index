import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Activity, Heart, TrendingUp, Zap, ArrowLeft, Download, Share2, Calendar } from "lucide-react"
import Link from "next/link"

export default function MeasurementDetailPage() {
  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-5xl">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" size="sm" className="mb-4" asChild>
              <Link href="/dashboard/measurements">
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回测量列表
              </Link>
            </Button>
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2">测量详情</h1>
                <p className="text-muted-foreground">2025-01-06 14:32</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="bg-transparent">
                  <Share2 className="w-4 h-4 mr-2" />
                  分享
                </Button>
                <Button variant="outline" size="sm" className="bg-transparent">
                  <Download className="w-4 h-4 mr-2" />
                  导出
                </Button>
              </div>
            </div>
          </div>

          {/* SignalValue Score */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardDescription className="text-primary font-medium mb-1">SignalValue 评分</CardDescription>
                  <CardTitle className="text-5xl font-bold mb-2">87</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-primary">高价值测量</Badge>
                    <Badge variant="outline" className="border-chart-3 text-chart-3">
                      <Zap className="w-3 h-3 mr-1" />
                      SmartYield 触发
                    </Badge>
                  </div>
                </div>
                <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="w-10 h-10 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">诊断价值</span>
                  <span className="font-medium">87/100</span>
                </div>
                <Progress value={87} className="h-2" />
                <p className="text-sm text-muted-foreground leading-relaxed">
                  此次测量具有较高的诊断价值。检测到的心率变异模式可能提供重要的健康信息，建议专家审阅。
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Basic Results */}
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>心律</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-1">窦性心律</div>
                <p className="text-sm text-success">正常</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>心率</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-1">75 bpm</div>
                <p className="text-sm text-muted-foreground">正常范围</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>测量时长</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold mb-1">30 秒</div>
                <p className="text-sm text-muted-foreground">标准测量</p>
              </CardContent>
            </Card>
          </div>

          {/* ECG Waveform */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>心电图波形</CardTitle>
              <CardDescription>30 秒心电图记录</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-muted/30 rounded-lg flex items-center justify-center relative overflow-hidden">
                {/* Simulated ECG waveform */}
                <svg className="w-full h-full" viewBox="0 0 800 200" preserveAspectRatio="none">
                  <path
                    d="M0,100 Q20,100 40,100 L50,100 L55,20 L60,180 L65,100 Q80,100 100,100 Q120,100 140,100 L150,100 L155,20 L160,180 L165,100 Q180,100 200,100 Q220,100 240,100 L250,100 L255,20 L260,180 L265,100 Q280,100 300,100 Q320,100 340,100 L350,100 L355,20 L360,180 L365,100 Q380,100 400,100 Q420,100 440,100 L450,100 L455,20 L460,180 L465,100 Q480,100 500,100 Q520,100 540,100 L550,100 L555,20 L560,180 L565,100 Q580,100 600,100 Q620,100 640,100 L650,100 L655,20 L660,180 L665,100 Q680,100 700,100 Q720,100 740,100 L750,100 L755,20 L760,180 L765,100 Q780,100 800,100"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    className="text-primary"
                  />
                </svg>
                <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background pointer-events-none" />
              </div>
              <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
                <span>0s</span>
                <span>15s</span>
                <span>30s</span>
              </div>
            </CardContent>
          </Card>

          {/* AI Insights */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                AI 分析洞察
              </CardTitle>
              <CardDescription>基于您的测量数据生成的个性化分析</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  心率变异检测
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  检测到轻微的心率变异模式。与您过去 7 天的基线相比，此次测量显示出 3.2%
                  的变化。这种变化虽然在正常范围内，但可能与您当前的活动状态或情绪状态相关。
                </p>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 border border-border">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-muted-foreground" />
                  与历史数据对比
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  您的心率（75 bpm）比 7 天平均值（72 bpm）略高。这可能是正常的日间波动。
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">7 天平均</span>
                    <span className="font-medium">72 bpm</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">30 天平均</span>
                    <span className="font-medium">73 bpm</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-chart-3/5 border border-chart-3/20">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Heart className="w-4 h-4 text-chart-3" />
                  建议
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  由于此次测量的 SignalValue 较高（87），建议记录当前的活动、情绪和身体感受。这些信息将帮助 AI
                  更好地理解您的心脏健康模式。
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Context & Notes */}
          <Card>
            <CardHeader>
              <CardTitle>测量背景</CardTitle>
              <CardDescription>记录测量时的情况</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium mb-1">触发方式</h4>
                  <p className="text-sm text-muted-foreground">SmartYield 智能触发 - 检测到 HRV 异常波动</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Activity className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium mb-1">活动状态</h4>
                  <p className="text-sm text-muted-foreground">静坐 - 工作中</p>
                </div>
              </div>

              <Button variant="outline" className="w-full bg-transparent">
                添加笔记
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
