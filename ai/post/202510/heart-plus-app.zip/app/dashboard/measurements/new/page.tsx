"use client"

import { useState } from "react"
import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Watch, Heart, Activity, CheckCircle2, Zap, ArrowLeft, TrendingUp } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function NewMeasurementPage() {
  const router = useRouter()
  const [step, setStep] = useState<"prepare" | "measuring" | "analyzing" | "complete">("prepare")
  const [progress, setProgress] = useState(0)

  const startMeasurement = () => {
    setStep("measuring")
    setProgress(0)

    // Simulate measurement progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setStep("analyzing")
          setTimeout(() => {
            setStep("complete")
          }, 2000)
          return 100
        }
        return prev + 3.33 // 30 seconds = 100%
      })
    }, 1000)
  }

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-3xl">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" size="sm" className="mb-4" asChild>
              <Link href="/dashboard/measurements">
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回
              </Link>
            </Button>
            <h1 className="text-3xl font-bold mb-2">新建测量</h1>
            <p className="text-muted-foreground">使用 Apple Watch 进行心电图测量</p>
          </div>

          {/* Prepare Step */}
          {step === "prepare" && (
            <div className="space-y-6">
              <Card className="bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <Zap className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle>SmartYield 建议</CardTitle>
                      <CardDescription>现在是测量的好时机</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    我们检测到您的心率变异性出现轻微波动，这可能提供有价值的诊断信息。建议现在进行测量。
                  </p>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">预计 SV: 75-90</div>
                    <div className="px-3 py-1 rounded-full bg-muted text-muted-foreground">高价值测量</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>测量准备</CardTitle>
                  <CardDescription>请确保以下条件满足</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-success/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4 text-success" />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">Apple Watch 已连接</h4>
                        <p className="text-sm text-muted-foreground">Series 4 或更新版本</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-success/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4 text-success" />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">保持静止</h4>
                        <p className="text-sm text-muted-foreground">找一个舒适的坐姿或站姿</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-success/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4 text-success" />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">手指放在表冠上</h4>
                        <p className="text-sm text-muted-foreground">轻轻触碰，无需用力按压</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-muted/50 mb-4">
                    <Watch className="w-8 h-8 text-primary flex-shrink-0" />
                    <div className="flex-1">
                      <h4 className="font-medium mb-1">测量时长</h4>
                      <p className="text-sm text-muted-foreground">约 30 秒</p>
                    </div>
                  </div>
                  <Button size="lg" className="w-full" onClick={startMeasurement}>
                    <Activity className="w-5 h-5 mr-2" />
                    开始测量
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Measuring Step */}
          {step === "measuring" && (
            <Card className="text-center">
              <CardContent className="pt-12 pb-12">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6 animate-pulse">
                  <Heart className="w-12 h-12 text-primary" fill="currentColor" />
                </div>
                <h2 className="text-2xl font-bold mb-2">正在测量...</h2>
                <p className="text-muted-foreground mb-8">请保持静止，手指放在表冠上</p>

                <div className="max-w-md mx-auto space-y-3">
                  <Progress value={progress} className="h-3" />
                  <p className="text-sm text-muted-foreground">{Math.round(progress)}% 完成</p>
                </div>

                <div className="mt-8 p-4 rounded-lg bg-muted/50 max-w-md mx-auto">
                  <p className="text-sm text-muted-foreground">测量过程中请勿移动手臂或说话</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Analyzing Step */}
          {step === "analyzing" && (
            <Card className="text-center">
              <CardContent className="pt-12 pb-12">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                  <Activity className="w-12 h-12 text-primary animate-pulse" />
                </div>
                <h2 className="text-2xl font-bold mb-2">AI 分析中...</h2>
                <p className="text-muted-foreground">正在计算 SignalValue 评分和微变化洞察</p>
              </CardContent>
            </Card>
          )}

          {/* Complete Step */}
          {step === "complete" && (
            <div className="space-y-6">
              <Card className="text-center bg-gradient-to-br from-success/10 via-card to-card border-success/20">
                <CardContent className="pt-12 pb-12">
                  <div className="w-24 h-24 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-12 h-12 text-success" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">测量完成</h2>
                  <p className="text-muted-foreground mb-6">您的心电图已成功记录</p>

                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-success/10 text-success font-medium">
                    <TrendingUp className="w-5 h-5" />
                    SignalValue: 87
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>测量结果</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <span className="text-muted-foreground">心律</span>
                    <span className="font-semibold">窦性心律</span>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <span className="text-muted-foreground">心率</span>
                    <span className="font-semibold">75 bpm</span>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <span className="text-muted-foreground">SignalValue</span>
                    <span className="font-semibold text-primary">87 / 100</span>
                  </div>

                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                    <div className="flex items-start gap-3">
                      <Zap className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-medium mb-1">AI 洞察</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          检测到轻微心率变异，这是高价值测量。建议记录当前活动和感受，以便后续分析。
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 bg-transparent" asChild>
                  <Link href="/dashboard/measurements">查看历史</Link>
                </Button>
                <Button className="flex-1" asChild>
                  <Link href="/dashboard/measurements/latest">查看详情</Link>
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
