"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Search, Book, MessageCircle, Mail, Phone, Video, FileText } from "lucide-react"
import Link from "next/link"

export default function HelpPage() {
  const faqs = [
    {
      category: "SignalValue",
      questions: [
        {
          q: "什么是SignalValue？",
          a: "SignalValue是我们独创的指标，用于评估每次心电图测量的诊断价值（0-100分）。分数越高，说明该次测量包含的临床信息越丰富，越值得医生审阅。",
        },
        {
          q: "SignalValue多少分算高？",
          a: "60分以下为常规测量，60-80分为中等价值，80分以上为高价值测量。高价值测量通常包含罕见心律事件、明显的心率变化或其他临床意义。",
        },
        {
          q: "如何提高SignalValue？",
          a: "SignalValue不是越高越好。它反映的是测量的诊断价值，而非健康状况。SmartYield会自动在最有价值的时机提醒您测量。",
        },
      ],
    },
    {
      category: "SmartYield",
      questions: [
        {
          q: "SmartYield如何工作？",
          a: "SmartYield通过分析您的PPG（光电容积脉搏波）、HRV（心率变异性）等被动信号，预测最佳测量时机。当检测到异常模式或高价值时机时，会主动提醒您进行ECG测量。",
        },
        {
          q: "为什么有时候不提醒我测量？",
          a: 'SmartYield采用"价值优先"策略。如果当前状态与近期测量相似，SignalValue预期较低，系统会减少提醒，避免测量疲劳。',
        },
      ],
    },
    {
      category: "生物反馈",
      questions: [
        {
          q: "生物反馈有什么用？",
          a: "生物反馈通过前后对比，让您直观看到放松练习（如深呼吸、冥想）对心率的即时影响。这种可视化反馈能增强练习效果，帮助您找到最适合自己的放松方法。",
        },
        {
          q: "多久做一次生物反馈？",
          a: "建议每天1-2次，特别是在感到压力或焦虑时。持续练习能提升自主神经调节能力，长期改善心率变异性。",
        },
      ],
    },
    {
      category: "专家审阅",
      questions: [
        {
          q: "什么情况需要专家审阅？",
          a: "当SignalValue≥80、AI检测到异常模式、或您主动请求时，可以提交专家审阅。专业医生会在24小时内提供诊断意见和医疗建议。",
        },
        {
          q: "专家审阅收费吗？",
          a: "基础会员每月包含2次免费审阅，高级会员不限次数。额外审阅单次收费49元。",
        },
      ],
    },
    {
      category: "数据隐私",
      questions: [
        {
          q: "我的健康数据安全吗？",
          a: "所有数据采用端到端加密存储，符合HIPAA和GDPR标准。未经您同意，我们不会分享任何可识别个人身份的数据。",
        },
        {
          q: "匿名数据分享是什么？",
          a: "您可以选择将完全匿名化的数据用于AI算法改进和医学研究。这些数据无法追溯到个人，有助于提升整体服务质量。",
        },
      ],
    },
  ]

  const resources = [
    {
      title: "用户手册",
      description: "完整的功能介绍和使用指南",
      icon: Book,
      href: "#",
    },
    {
      title: "视频教程",
      description: "观看视频快速上手",
      icon: Video,
      href: "#",
    },
    {
      title: "医学知识库",
      description: "了解心电图和心率健康",
      icon: FileText,
      href: "#",
    },
  ]

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">帮助中心</h1>
          <p className="text-muted-foreground">查找答案、学习功能、联系支持</p>
        </div>

        {/* Search */}
        <Card className="p-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input placeholder="搜索问题..." className="pl-10" />
          </div>
        </Card>

        {/* Quick Resources */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {resources.map((resource) => {
            const Icon = resource.icon
            return (
              <Card key={resource.title} className="p-6 hover:shadow-md transition-shadow">
                <Link href={resource.href} className="block">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{resource.title}</h3>
                  <p className="text-sm text-muted-foreground">{resource.description}</p>
                </Link>
              </Card>
            )
          })}
        </div>

        {/* FAQs */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">常见问题</h2>
          {faqs.map((category) => (
            <div key={category.category} className="mb-6 last:mb-0">
              <h3 className="text-lg font-semibold text-foreground mb-3">{category.category}</h3>
              <Accordion type="single" collapsible className="space-y-2">
                {category.questions.map((item, index) => (
                  <AccordionItem key={index} value={`${category.category}-${index}`} className="border rounded-lg px-4">
                    <AccordionTrigger className="text-left hover:no-underline">{item.q}</AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">{item.a}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </Card>

        {/* Contact Support */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">联系我们</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto py-4 flex-col gap-2 bg-transparent">
              <MessageCircle className="w-6 h-6 text-primary" />
              <span className="font-medium">在线客服</span>
              <span className="text-xs text-muted-foreground">9:00-21:00</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2 bg-transparent">
              <Mail className="w-6 h-6 text-primary" />
              <span className="font-medium">邮件支持</span>
              <span className="text-xs text-muted-foreground">support@heartplus.com</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2 bg-transparent">
              <Phone className="w-6 h-6 text-primary" />
              <span className="font-medium">电话支持</span>
              <span className="text-xs text-muted-foreground">400-123-4567</span>
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
