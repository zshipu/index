import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Activity, TrendingUp, Heart, Zap, ArrowRight, Calendar, Award } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-7xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">欢迎回来，张三</h1>
            <p className="text-muted-foreground">这是您今天的心脏健康概览</p>
          </div>

          {/* SignalValue Score - Hero Card */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardDescription className="text-primary font-medium mb-1">今日 SignalValue 评分</CardDescription>
                  <CardTitle className="text-5xl font-bold mb-2">87</CardTitle>
                  <p className="text-sm text-muted-foreground">高价值测量 · 建议专家审阅</p>
                </div>
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="w-8 h-8 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">诊断价值</span>
                  <span className="font-medium">87/100</span>
                </div>
                <Progress value={87} className="h-2" />
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Zap className="w-4 h-4 text-chart-3" />
                  <span>检测到轻微心率变异，建议记录当前活动</span>
                </div>
              </div>
              <Button className="w-full mt-4" asChild>
                <Link href="/dashboard/measurements/latest">
                  查看详细分析
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* Quick Stats Grid */}
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardDescription>本周测量</CardDescription>
                  <Activity className="w-4 h-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-1">12</div>
                <p className="text-sm text-muted-foreground">
                  <span className="text-success">↑ 3</span> 比上周
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardDescription>平均心率</CardDescription>
                  <Heart className="w-4 h-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-1">72</div>
                <p className="text-sm text-muted-foreground">
                  <span className="text-success">↓ 2</span> bpm
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardDescription>连续天数</CardDescription>
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-1">28</div>
                <p className="text-sm text-muted-foreground">保持良好习惯</p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Measurements */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>最近测量</CardTitle>
                  <CardDescription>您的心电图历史记录</CardDescription>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/dashboard/measurements">
                    查看全部
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    time: "今天 14:32",
                    signalValue: 87,
                    result: "窦性心律",
                    note: "检测到轻微变异",
                    color: "text-chart-3",
                  },
                  {
                    time: "今天 09:15",
                    signalValue: 45,
                    result: "窦性心律",
                    note: "正常范围",
                    color: "text-success",
                  },
                  {
                    time: "昨天 22:08",
                    signalValue: 62,
                    result: "窦性心律",
                    note: "睡前测量",
                    color: "text-primary",
                  },
                ].map((measurement, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-4 p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                      <Activity className={`w-6 h-6 ${measurement.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">{measurement.result}</span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                          SV: {measurement.signalValue}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">{measurement.note}</p>
                    </div>
                    <div className="text-right text-sm text-muted-foreground flex-shrink-0">{measurement.time}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Micro-Delta Insights */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>微变化洞察</CardTitle>
              <CardDescription>临床阈值以下的个人趋势</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium mb-1">静息心率下降趋势</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      过去 7 天，您的静息心率从 74 bpm 降至 72 bpm。虽然仍在正常范围，但这表明您的心血管健康正在改善。
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="h-1 flex-1 bg-gradient-to-r from-chart-3 via-primary to-success rounded-full" />
                      <span className="text-xs text-muted-foreground">74 → 72 bpm</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-lg bg-muted/50 border border-border">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                    <Activity className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium mb-1">HRV 稳定性提升</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      心率变异性（HRV）波动减小，表明您的自主神经系统更加平衡。继续保持规律作息。
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Smart Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                智能建议
              </CardTitle>
              <CardDescription>基于您的数据生成的个性化建议</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 rounded-lg bg-accent/50">
                  <Award className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium mb-1">完成"睡前放松"任务</p>
                    <p className="text-xs text-muted-foreground">您的晚间心率偏高，尝试睡前 5 分钟呼吸练习可能有帮助</p>
                  </div>
                  <Button size="sm" variant="ghost" asChild>
                    <Link href="/dashboard/missions">开始</Link>
                  </Button>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-lg bg-accent/50">
                  <Calendar className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium mb-1">生成本周报告</p>
                    <p className="text-xs text-muted-foreground">您本周的数据已足够生成完整的健康报告</p>
                  </div>
                  <Button size="sm" variant="ghost" asChild>
                    <Link href="/dashboard/reports">生成</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
