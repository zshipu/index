"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bell, Activity, Heart, FileText, Trophy, Stethoscope, Zap, CheckCheck, Trash2, Settings } from "lucide-react"
import Link from "next/link"

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "smartyield",
      icon: Zap,
      title: "SmartYield提醒",
      message: "检测到高价值测量时机：运动后恢复期",
      time: "5分钟前",
      read: false,
      action: { label: "立即测量", href: "/dashboard/measurements/new" },
    },
    {
      id: 2,
      type: "clinician",
      icon: Stethoscope,
      title: "专家审阅完成",
      message: "李医生已完成您的心电图审阅，诊断结果已更新",
      time: "1小时前",
      read: false,
      action: { label: "查看报告", href: "/dashboard/clinician/rev-004" },
    },
    {
      id: 3,
      type: "insight",
      icon: Activity,
      title: "新的健康洞察",
      message: "本周HRV提升15%，自主神经功能改善明显",
      time: "2小时前",
      read: false,
      action: { label: "查看详情", href: "/dashboard/insights" },
    },
    {
      id: 4,
      type: "mission",
      icon: Trophy,
      title: "成就解锁",
      message: '恭喜！您获得了"连续测量7天"成就徽章',
      time: "3小时前",
      read: true,
      action: { label: "查看成就", href: "/dashboard/missions" },
    },
    {
      id: 5,
      type: "report",
      icon: FileText,
      title: "周报已生成",
      message: "您的第3周健康报告已生成，可以分享给医生",
      time: "昨天",
      read: true,
      action: { label: "查看报告", href: "/dashboard/reports" },
    },
    {
      id: 6,
      type: "measurement",
      icon: Heart,
      title: "测量分析完成",
      message: "您的心电图测量已完成分析，SignalValue: 92",
      time: "昨天",
      read: true,
      action: { label: "查看结果", href: "/dashboard/measurements/meas-789" },
    },
  ])

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: number) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((n) => n.id !== id))
  }

  const getIconColor = (type: string) => {
    switch (type) {
      case "smartyield":
        return "text-yellow-600 bg-yellow-500/10"
      case "clinician":
        return "text-blue-600 bg-blue-500/10"
      case "insight":
        return "text-primary bg-primary/10"
      case "mission":
        return "text-purple-600 bg-purple-500/10"
      case "report":
        return "text-green-600 bg-green-500/10"
      case "measurement":
        return "text-red-600 bg-red-500/10"
      default:
        return "text-muted-foreground bg-muted"
    }
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">通知中心</h1>
            <p className="text-muted-foreground">
              {unreadCount > 0 ? `您有 ${unreadCount} 条未读通知` : "所有通知已读"}
            </p>
          </div>
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button variant="outline" size="sm" onClick={markAllAsRead}>
                <CheckCheck className="w-4 h-4 mr-2" />
                全部已读
              </Button>
            )}
            <Button variant="outline" size="sm" asChild>
              <Link href="/dashboard/settings">
                <Settings className="w-4 h-4 mr-2" />
                设置
              </Link>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">全部 ({notifications.length})</TabsTrigger>
            <TabsTrigger value="unread">未读 ({unreadCount})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-3">
            {notifications.length === 0 ? (
              <Card className="p-12 text-center">
                <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">暂无通知</h3>
                <p className="text-sm text-muted-foreground">您的通知将显示在这里</p>
              </Card>
            ) : (
              notifications.map((notification) => {
                const Icon = notification.icon
                return (
                  <Card
                    key={notification.id}
                    className={`p-4 transition-all ${!notification.read ? "border-primary/50 bg-primary/5" : ""}`}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${getIconColor(notification.type)}`}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h3 className="font-semibold text-foreground">{notification.title}</h3>
                          {!notification.read && (
                            <Badge variant="default" className="flex-shrink-0">
                              新
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">{notification.time}</span>
                          <div className="flex gap-2">
                            {notification.action && (
                              <Button
                                variant="link"
                                size="sm"
                                className="h-auto p-0 text-primary"
                                asChild
                                onClick={() => markAsRead(notification.id)}
                              >
                                <Link href={notification.action.href}>{notification.action.label}</Link>
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-auto p-0 text-muted-foreground hover:text-foreground"
                              onClick={() => deleteNotification(notification.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                )
              })
            )}
          </TabsContent>

          <TabsContent value="unread" className="space-y-3">
            {notifications.filter((n) => !n.read).length === 0 ? (
              <Card className="p-12 text-center">
                <CheckCheck className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">太棒了！</h3>
                <p className="text-sm text-muted-foreground">您已阅读所有通知</p>
              </Card>
            ) : (
              notifications
                .filter((n) => !n.read)
                .map((notification) => {
                  const Icon = notification.icon
                  return (
                    <Card key={notification.id} className="p-4 border-primary/50 bg-primary/5">
                      <div className="flex items-start gap-4">
                        <div
                          className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${getIconColor(notification.type)}`}
                        >
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h3 className="font-semibold text-foreground">{notification.title}</h3>
                            <Badge variant="default" className="flex-shrink-0">
                              新
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">{notification.time}</span>
                            <div className="flex gap-2">
                              {notification.action && (
                                <Button
                                  variant="link"
                                  size="sm"
                                  className="h-auto p-0 text-primary"
                                  asChild
                                  onClick={() => markAsRead(notification.id)}
                                >
                                  <Link href={notification.action.href}>{notification.action.label}</Link>
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-0 text-muted-foreground hover:text-foreground"
                                onClick={() => markAsRead(notification.id)}
                              >
                                标记已读
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  )
                })
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
