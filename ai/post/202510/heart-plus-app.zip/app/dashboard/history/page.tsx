"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Activity, Heart, TrendingUp, TrendingDown, CalendarIcon, Filter, Download, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { format } from "date-fns"
import { zhCN } from "date-fns/locale"

export default function HistoryPage() {
  const [date, setDate] = useState<Date>()
  const [filterType, setFilterType] = useState("all")
  const [sortBy, setSortBy] = useState("date")

  const measurements = [
    {
      id: "meas-001",
      date: "2024-01-15",
      time: "14:30",
      type: "ecg",
      signalValue: 92,
      heartRate: 145,
      hrv: 28,
      status: "reviewed",
      tags: ["高心率", "PAC检出"],
      trend: "up",
    },
    {
      id: "meas-002",
      date: "2024-01-15",
      time: "09:15",
      type: "ecg",
      signalValue: 65,
      heartRate: 72,
      hrv: 45,
      status: "normal",
      tags: ["窦性心律"],
      trend: "stable",
    },
    {
      id: "meas-003",
      date: "2024-01-14",
      time: "20:45",
      type: "ecg",
      signalValue: 78,
      heartRate: 88,
      hrv: 38,
      status: "normal",
      tags: ["运动后"],
      trend: "up",
    },
    {
      id: "meas-004",
      date: "2024-01-14",
      time: "08:30",
      type: "ecg",
      signalValue: 58,
      heartRate: 68,
      hrv: 52,
      status: "normal",
      tags: ["晨起"],
      trend: "stable",
    },
    {
      id: "meas-005",
      date: "2024-01-13",
      time: "15:20",
      type: "ecg",
      signalValue: 88,
      heartRate: 52,
      hrv: 65,
      status: "reviewed",
      tags: ["低心率", "深度放松"],
      trend: "down",
    },
  ]

  const biofeedback = [
    {
      id: "bio-001",
      date: "2024-01-15",
      activity: "深呼吸练习",
      preBpm: 88,
      postBpm: 72,
      improvement: -18,
      duration: 5,
    },
    {
      id: "bio-002",
      date: "2024-01-14",
      activity: "冥想",
      preBpm: 82,
      postBpm: 68,
      improvement: -17,
      duration: 10,
    },
    {
      id: "bio-003",
      date: "2024-01-13",
      activity: "瑜伽",
      preBpm: 75,
      postBpm: 65,
      improvement: -13,
      duration: 20,
    },
  ]

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">历史记录</h1>
          <p className="text-muted-foreground">查看和分析您的所有健康数据</p>
        </div>

        {/* Filters */}
        <Card className="p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input placeholder="搜索记录..." className="w-full" prefix={<Search className="w-4 h-4" />} />
            </div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="justify-start bg-transparent">
                  <CalendarIcon className="w-4 h-4 mr-2" />
                  {date ? format(date, "PPP", { locale: zhCN }) : "选择日期"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
              </PopoverContent>
            </Popover>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[150px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部类型</SelectItem>
                <SelectItem value="ecg">心电图</SelectItem>
                <SelectItem value="biofeedback">生物反馈</SelectItem>
                <SelectItem value="reviewed">已审阅</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">按日期</SelectItem>
                <SelectItem value="signalValue">按价值</SelectItem>
                <SelectItem value="heartRate">按心率</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              导出
            </Button>
          </div>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="measurements" className="space-y-6">
          <TabsList>
            <TabsTrigger value="measurements">
              <Activity className="w-4 h-4 mr-2" />
              测量记录
            </TabsTrigger>
            <TabsTrigger value="biofeedback">
              <Heart className="w-4 h-4 mr-2" />
              生物反馈
            </TabsTrigger>
            <TabsTrigger value="timeline">
              <CalendarIcon className="w-4 h-4 mr-2" />
              时间线
            </TabsTrigger>
          </TabsList>

          {/* Measurements */}
          <TabsContent value="measurements" className="space-y-4">
            {measurements.map((measurement) => (
              <Card key={measurement.id} className="p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-foreground">
                        {measurement.date} {measurement.time}
                      </h3>
                      {measurement.status === "reviewed" && (
                        <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                          已审阅
                        </Badge>
                      )}
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        SignalValue: {measurement.signalValue}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {measurement.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    {measurement.trend === "up" && <TrendingUp className="w-5 h-5 text-red-500" />}
                    {measurement.trend === "down" && <TrendingDown className="w-5 h-5 text-green-500" />}
                    {measurement.trend === "stable" && <Activity className="w-5 h-5 text-muted-foreground" />}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">心率</div>
                    <div className="text-xl font-bold text-foreground">{measurement.heartRate}</div>
                    <div className="text-xs text-muted-foreground">bpm</div>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">HRV</div>
                    <div className="text-xl font-bold text-foreground">{measurement.hrv}</div>
                    <div className="text-xs text-muted-foreground">ms</div>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">价值</div>
                    <div className="text-xl font-bold text-primary">{measurement.signalValue}</div>
                  </div>
                </div>

                <Button variant="outline" asChild className="w-full bg-transparent">
                  <Link href={`/dashboard/measurements/${measurement.id}`}>查看详情</Link>
                </Button>
              </Card>
            ))}
          </TabsContent>

          {/* Biofeedback */}
          <TabsContent value="biofeedback" className="space-y-4">
            {biofeedback.map((session) => (
              <Card key={session.id} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-1">{session.activity}</h3>
                    <p className="text-sm text-muted-foreground">{session.date}</p>
                  </div>
                  <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/20">
                    {session.improvement} bpm
                  </Badge>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">前测</div>
                    <div className="text-xl font-bold text-foreground">{session.preBpm}</div>
                    <div className="text-xs text-muted-foreground">bpm</div>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">后测</div>
                    <div className="text-xl font-bold text-foreground">{session.postBpm}</div>
                    <div className="text-xs text-muted-foreground">bpm</div>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">时长</div>
                    <div className="text-xl font-bold text-foreground">{session.duration}</div>
                    <div className="text-xs text-muted-foreground">分钟</div>
                  </div>
                </div>

                <Button variant="outline" asChild className="w-full bg-transparent">
                  <Link href={`/dashboard/biofeedback/${session.id}`}>查看详情</Link>
                </Button>
              </Card>
            ))}
          </TabsContent>

          {/* Timeline */}
          <TabsContent value="timeline">
            <Card className="p-6">
              <div className="space-y-6">
                {[...measurements, ...biofeedback.map((b) => ({ ...b, type: "biofeedback" }))]
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          {"type" in item && item.type === "biofeedback" ? (
                            <Heart className="w-5 h-5 text-primary" />
                          ) : (
                            <Activity className="w-5 h-5 text-primary" />
                          )}
                        </div>
                        {index < measurements.length + biofeedback.length - 1 && (
                          <div className="w-0.5 h-full bg-border mt-2" />
                        )}
                      </div>
                      <div className="flex-1 pb-6">
                        <div className="text-sm text-muted-foreground mb-1">
                          {item.date} {"time" in item && item.time}
                        </div>
                        <div className="font-medium text-foreground">
                          {"activity" in item ? item.activity : "心电图测量"}
                        </div>
                        {"signalValue" in item && (
                          <div className="text-sm text-muted-foreground">
                            SignalValue: {item.signalValue} · 心率: {item.heartRate} bpm
                          </div>
                        )}
                        {"improvement" in item && (
                          <div className="text-sm text-green-600">心率降低 {Math.abs(item.improvement)} bpm</div>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
