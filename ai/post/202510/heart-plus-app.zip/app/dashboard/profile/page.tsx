"use client"

import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { User, Mail, Phone, Calendar, Watch, Trophy, Settings, LogOut } from "lucide-react"
import Link from "next/link"

export default function ProfilePage() {
  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-5xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">个人资料</h1>
            <p className="text-muted-foreground">管理您的账户信息和设置</p>
          </div>

          {/* Profile Overview */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <User className="w-12 h-12 text-primary" />
                </div>

                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-2xl font-bold mb-2">张三</h2>
                  <p className="text-muted-foreground mb-3">zhangsan@example.com</p>
                  <div className="flex flex-wrap items-center gap-2 justify-center md:justify-start">
                    <Badge className="bg-primary">等级 8</Badge>
                    <Badge variant="outline">连续 28 天</Badge>
                    <Badge variant="secondary">156 次测量</Badge>
                  </div>
                </div>

                <Button variant="outline" className="bg-transparent">
                  <Settings className="w-4 h-4 mr-2" />
                  编辑资料
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Personal Information */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>个人信息</CardTitle>
              <CardDescription>您的基本账户信息</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">姓名</Label>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <Input id="name" value="张三" readOnly className="bg-muted/50" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">邮箱</Label>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <Input id="email" value="zhangsan@example.com" readOnly className="bg-muted/50" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">手机号</Label>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <Input id="phone" value="+86 138 0000 0000" readOnly className="bg-muted/50" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="joined">加入时间</Label>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <Input id="joined" value="2024-12-10" readOnly className="bg-muted/50" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Connected Devices */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>连接设备</CardTitle>
              <CardDescription>管理您的健康监测设备</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Watch className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Apple Watch Series 8</h4>
                    <p className="text-sm text-muted-foreground">最后同步: 2 分钟前</p>
                  </div>
                </div>
                <Badge variant="outline" className="border-success text-success">
                  已连接
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Stats Summary */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>使用统计</CardTitle>
              <CardDescription>您的健康监测数据概览</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="text-sm text-muted-foreground mb-1">总测量次数</div>
                  <div className="text-2xl font-bold">156</div>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="text-sm text-muted-foreground mb-1">生成报告</div>
                  <div className="text-2xl font-bold">18</div>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="text-sm text-muted-foreground mb-1">完成任务</div>
                  <div className="text-2xl font-bold">45</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Achievements Preview */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>成就展示</CardTitle>
                  <CardDescription>您最近解锁的成就</CardDescription>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/dashboard/missions">查看全部</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">数据专家</h4>
                    <p className="text-xs text-muted-foreground">完成 100 次测量</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 rounded-lg bg-chart-3/5 border border-chart-3/20">
                  <div className="w-12 h-12 rounded-full bg-chart-3/20 flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-chart-3" />
                  </div>
                  <div>
                    <h4 className="font-medium">初心者</h4>
                    <p className="text-xs text-muted-foreground">完成第一次测量</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Actions */}
          <Card>
            <CardHeader>
              <CardTitle>账户操作</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                <Settings className="w-4 h-4 mr-2" />
                账户设置
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent">
                隐私设置
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start bg-transparent text-destructive hover:text-destructive"
              >
                <LogOut className="w-4 h-4 mr-2" />
                退出登录
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
