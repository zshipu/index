"use client"

import { useState } from "react"
import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { FileText, ArrowLeft, CheckCircle2, Loader2 } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function GenerateReportPage() {
  const router = useRouter()
  const [step, setStep] = useState<"confirm" | "generating" | "complete">("confirm")
  const [progress, setProgress] = useState(0)

  const generateReport = () => {
    setStep("generating")
    setProgress(0)

    // Simulate report generation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setStep("complete")
          return 100
        }
        return prev + 5
      })
    }, 200)
  }

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-3xl">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" size="sm" className="mb-4" asChild>
              <Link href="/dashboard/reports">
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回
              </Link>
            </Button>
            <h1 className="text-3xl font-bold mb-2">生成健康报告</h1>
            <p className="text-muted-foreground">创建本周的个性化健康分析报告</p>
          </div>

          {/* Confirm Step */}
          {step === "confirm" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>报告周期</CardTitle>
                  <CardDescription>2025 年第 2 周</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <span className="text-sm text-muted-foreground">时间范围</span>
                      <span className="font-medium">2025-01-06 至 2025-01-12</span>
                    </div>
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <span className="text-sm text-muted-foreground">测量次数</span>
                      <span className="font-medium">12 次</span>
                    </div>
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <span className="text-sm text-muted-foreground">高价值测量</span>
                      <span className="font-medium">3 次</span>
                    </div>
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <span className="text-sm text-muted-foreground">数据完整度</span>
                      <span className="font-medium text-success">95%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>报告内容</CardTitle>
                  <CardDescription>本报告将包含以下分析</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="font-medium">心率趋势分析</div>
                        <div className="text-sm text-muted-foreground">包括静息心率、最高/最低心率等</div>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="font-medium">SignalValue 评分分布</div>
                        <div className="text-sm text-muted-foreground">测量价值分析和 SmartYield 效果</div>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="font-medium">微变化洞察</div>
                        <div className="text-sm text-muted-foreground">个人健康趋势和模式识别</div>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="font-medium">个性化建议</div>
                        <div className="text-sm text-muted-foreground">基于您的数据生成的健康建议</div>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    报告生成通常需要 10-15
                    秒。生成后，您可以查看、下载或分享报告。报告将永久保存在您的账户中，随时可以访问。
                  </p>
                  <Button size="lg" className="w-full" onClick={generateReport}>
                    <FileText className="w-5 h-5 mr-2" />
                    开始生成报告
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Generating Step */}
          {step === "generating" && (
            <Card className="text-center">
              <CardContent className="pt-12 pb-12">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                  <Loader2 className="w-12 h-12 text-primary animate-spin" />
                </div>
                <h2 className="text-2xl font-bold mb-2">正在生成报告...</h2>
                <p className="text-muted-foreground mb-8">AI 正在分析您的健康数据</p>

                <div className="max-w-md mx-auto space-y-3">
                  <Progress value={progress} className="h-3" />
                  <p className="text-sm text-muted-foreground">{Math.round(progress)}% 完成</p>
                </div>

                <div className="mt-8 space-y-2 text-sm text-muted-foreground">
                  {progress < 30 && <p>正在收集测量数据...</p>}
                  {progress >= 30 && progress < 60 && <p>正在分析心率趋势...</p>}
                  {progress >= 60 && progress < 90 && <p>正在生成微变化洞察...</p>}
                  {progress >= 90 && <p>正在生成个性化建议...</p>}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Complete Step */}
          {step === "complete" && (
            <div className="space-y-6">
              <Card className="text-center bg-gradient-to-br from-success/10 via-card to-card border-success/20">
                <CardContent className="pt-12 pb-12">
                  <div className="w-24 h-24 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-12 h-12 text-success" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">报告生成完成</h2>
                  <p className="text-muted-foreground">您的健康报告已准备就绪</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>2025 年第 2 周健康报告</CardTitle>
                  <CardDescription>2025-01-06 至 2025-01-12</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 mb-6">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <div className="text-sm text-muted-foreground mb-1">报告大小</div>
                      <div className="font-medium">2.4 MB</div>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <div className="text-sm text-muted-foreground mb-1">包含内容</div>
                      <div className="font-medium">12 次测量 · 3 个图表 · 8 项洞察</div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button variant="outline" className="flex-1 bg-transparent" asChild>
                      <Link href="/dashboard/reports">返回列表</Link>
                    </Button>
                    <Button className="flex-1" asChild>
                      <Link href="/dashboard/reports/1">查看报告</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
