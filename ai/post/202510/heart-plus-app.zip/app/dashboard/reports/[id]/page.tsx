import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Download,
  Share2,
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Heart,
  Activity,
  Zap,
  Calendar,
  Award,
} from "lucide-react"
import Link from "next/link"

export default function ReportDetailPage() {
  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-5xl">
          {/* Header */}
          <div className="mb-8">
            <Button variant="ghost" size="sm" className="mb-4" asChild>
              <Link href="/dashboard/reports">
                <ArrowLeft className="w-4 h-4 mr-2" />
                返回报告列表
              </Link>
            </Button>
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2">2025 年第 1 周健康报告</h1>
                <p className="text-muted-foreground">2024-12-30 至 2025-01-05</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="bg-transparent">
                  <Share2 className="w-4 h-4 mr-2" />
                  分享
                </Button>
                <Button variant="outline" size="sm" className="bg-transparent">
                  <Download className="w-4 h-4 mr-2" />
                  下载 PDF
                </Button>
              </div>
            </div>
          </div>

          {/* Executive Summary */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardHeader>
              <CardTitle>本周概览</CardTitle>
              <CardDescription>您的心脏健康总结</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 rounded-lg bg-card/50 border border-border">
                  <div className="text-sm text-muted-foreground mb-1">测量次数</div>
                  <div className="text-3xl font-bold mb-1">12</div>
                  <div className="flex items-center gap-1 text-sm text-success">
                    <TrendingUp className="w-4 h-4" />
                    <span>+3 比上周</span>
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-card/50 border border-border">
                  <div className="text-sm text-muted-foreground mb-1">平均心率</div>
                  <div className="text-3xl font-bold mb-1">72 bpm</div>
                  <div className="flex items-center gap-1 text-sm text-success">
                    <TrendingDown className="w-4 h-4" />
                    <span>-2 bpm</span>
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-card/50 border border-border">
                  <div className="text-sm text-muted-foreground mb-1">平均 SignalValue</div>
                  <div className="text-3xl font-bold mb-1">58</div>
                  <div className="flex items-center gap-1 text-sm text-primary">
                    <TrendingUp className="w-4 h-4" />
                    <span>+4 比上周</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Award className="w-5 h-5 text-primary" />
                  本周亮点
                </h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>静息心率持续下降，从 74 bpm 降至 72 bpm，表明心血管健康改善</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>完成 3 次高价值测量（SV &gt; 80），提供了重要的诊断信息</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>测量频率稳定，保持每天 1-2 次的良好习惯</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Heart Rate Trends */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>心率趋势</CardTitle>
              <CardDescription>本周心率变化分析</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-muted/30 rounded-lg flex items-center justify-center mb-4">
                {/* Simulated chart */}
                <div className="text-center text-muted-foreground">
                  <Activity className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">心率趋势图表</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">最低心率</span>
                    <Heart className="w-4 h-4 text-success" />
                  </div>
                  <div className="text-2xl font-bold">62 bpm</div>
                  <p className="text-xs text-muted-foreground mt-1">2025-01-03 早晨</p>
                </div>

                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">最高心率</span>
                    <Heart className="w-4 h-4 text-destructive" />
                  </div>
                  <div className="text-2xl font-bold">88 bpm</div>
                  <p className="text-xs text-muted-foreground mt-1">2025-01-05 下午</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* SignalValue Analysis */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>SignalValue 分析</CardTitle>
              <CardDescription>测量价值分布</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-6">
                <div>
                  <div className="flex items-center justify-between mb-2 text-sm">
                    <span className="text-muted-foreground">高价值测量（SV &gt; 80）</span>
                    <span className="font-medium">3 次 · 25%</span>
                  </div>
                  <Progress value={25} className="h-2" />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2 text-sm">
                    <span className="text-muted-foreground">中等价值测量（SV 50-80）</span>
                    <span className="font-medium">5 次 · 42%</span>
                  </div>
                  <Progress value={42} className="h-2" />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2 text-sm">
                    <span className="text-muted-foreground">常规测量（SV &lt; 50）</span>
                    <span className="font-medium">4 次 · 33%</span>
                  </div>
                  <Progress value={33} className="h-2" />
                </div>
              </div>

              <div className="p-4 rounded-lg bg-chart-3/5 border border-chart-3/20">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-chart-3" />
                  SmartYield 效果
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  本周 SmartYield 触发了 5 次测量，其中 3 次为高价值测量（60%
                  成功率）。系统准确识别了心率变异时机，帮助您捕获更多有诊断价值的数据。
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Micro-Delta Insights */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>微变化洞察</CardTitle>
              <CardDescription>个人健康趋势分析</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <TrendingDown className="w-5 h-5 text-success" />
                  静息心率改善
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                  您的静息心率从上周的 74 bpm 降至本周的 72 bpm。虽然变化幅度不大（2.7%），但这是一个积极的信号，表明：
                </p>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-success">✓</span>
                    <span>心血管效率提升</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-success">✓</span>
                    <span>运动或生活方式改变产生效果</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-success">✓</span>
                    <span>压力水平可能降低</span>
                  </li>
                </ul>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 border border-border">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-muted-foreground" />
                  HRV 稳定性
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  心率变异性（HRV）波动范围缩小了
                  15%，表明您的自主神经系统更加平衡。这通常与更好的睡眠质量和压力管理相关。
                </p>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 border border-border">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-muted-foreground" />
                  测量时间模式
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  您倾向于在早晨（40%）和晚间（35%）进行测量。早晨测量的心率通常较低（平均 68
                  bpm），而晚间测量略高（平均 76 bpm），这是正常的日间变化。
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>个性化建议</CardTitle>
              <CardDescription>基于本周数据的健康建议</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/50">
                <Award className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">保持当前测量频率</p>
                  <p className="text-xs text-muted-foreground">
                    您的测量习惯很好，每天 1-2 次的频率既能提供足够数据，又不会过度打扰日常生活。
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/50">
                <Zap className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">关注 SmartYield 提醒</p>
                  <p className="text-xs text-muted-foreground">
                    SmartYield 触发的测量有 60% 为高价值，建议继续响应这些智能提醒。
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/50">
                <Heart className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">尝试呼吸练习</p>
                  <p className="text-xs text-muted-foreground">
                    您的晚间心率偏高，睡前 5 分钟呼吸练习可能有助于改善睡眠质量。
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Report Metadata */}
          <Card>
            <CardHeader>
              <CardTitle>报告信息</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">生成时间</span>
                  <span className="font-medium">2025-01-06 10:30</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">数据来源</span>
                  <span className="font-medium">Apple Watch Series 8</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">分析引擎</span>
                  <span className="font-medium">Heart+ AI v2.1</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">报告版本</span>
                  <span className="font-medium">1.0</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
