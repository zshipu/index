import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FileText, Download, Share2, Plus, Calendar, Eye } from "lucide-react"
import Link from "next/link"

export default function ReportsPage() {
  const reports = [
    {
      id: "1",
      title: "2025 年第 1 周健康报告",
      period: "2024-12-30 至 2025-01-05",
      generated: "2025-01-06",
      measurements: 12,
      avgSignalValue: 58,
      avgHeartRate: 72,
      status: "ready",
      highlights: ["心率稳定", "HRV 改善"],
    },
    {
      id: "2",
      title: "2024 年第 52 周健康报告",
      period: "2024-12-23 至 2024-12-29",
      generated: "2024-12-30",
      measurements: 14,
      avgSignalValue: 62,
      avgHeartRate: 74,
      status: "ready",
      highlights: ["高价值测量增加"],
    },
    {
      id: "3",
      title: "2024 年第 51 周健康报告",
      period: "2024-12-16 至 2024-12-22",
      generated: "2024-12-23",
      measurements: 10,
      avgSignalValue: 55,
      avgHeartRate: 73,
      status: "ready",
      highlights: ["测量频率稳定"],
    },
  ]

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-7xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">健康报告</h1>
              <p className="text-muted-foreground">查看和生成您的周度健康分析报告</p>
            </div>
            <Button size="lg" asChild>
              <Link href="/dashboard/reports/generate">
                <Plus className="w-5 h-5 mr-2" />
                生成报告
              </Link>
            </Button>
          </div>

          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>总报告数</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">18</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>本周测量</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>平均 SignalValue</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">58</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>报告就绪</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-success">1</div>
              </CardContent>
            </Card>
          </div>

          {/* Current Week Status */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="mb-2">本周报告状态</CardTitle>
                  <CardDescription>2025 年第 2 周（2025-01-06 至 2025-01-12）</CardDescription>
                </div>
                <Badge className="bg-success">可生成</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-card/50 border border-border">
                    <div className="text-sm text-muted-foreground mb-1">测量次数</div>
                    <div className="text-2xl font-bold">12 / 7</div>
                    <div className="text-xs text-success mt-1">已达到最低要求</div>
                  </div>
                  <div className="p-4 rounded-lg bg-card/50 border border-border">
                    <div className="text-sm text-muted-foreground mb-1">高价值测量</div>
                    <div className="text-2xl font-bold">3</div>
                    <div className="text-xs text-muted-foreground mt-1">包含重要数据</div>
                  </div>
                  <div className="p-4 rounded-lg bg-card/50 border border-border">
                    <div className="text-sm text-muted-foreground mb-1">数据完整度</div>
                    <div className="text-2xl font-bold">95%</div>
                    <div className="text-xs text-success mt-1">数据质量优秀</div>
                  </div>
                </div>

                <Button className="w-full" size="lg" asChild>
                  <Link href="/dashboard/reports/generate">
                    <FileText className="w-5 h-5 mr-2" />
                    生成本周报告
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Reports List */}
          <Card>
            <CardHeader>
              <CardTitle>历史报告</CardTitle>
              <CardDescription>您的周度健康分析记录</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reports.map((report) => (
                  <Card key={report.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                        {/* Icon */}
                        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <FileText className="w-7 h-7 text-primary" />
                        </div>

                        {/* Content */}
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <h3 className="font-semibold text-lg">{report.title}</h3>
                            <Badge variant="outline" className="border-success text-success">
                              {report.status === "ready" ? "已生成" : "生成中"}
                            </Badge>
                          </div>

                          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-3">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {report.period}
                            </span>
                            <span>{report.measurements} 次测量</span>
                            <span>平均 SV: {report.avgSignalValue}</span>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {report.highlights.map((highlight, i) => (
                              <Badge key={i} variant="secondary">
                                {highlight}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 lg:flex-col">
                          <Button variant="outline" size="sm" className="bg-transparent" asChild>
                            <Link href={`/dashboard/reports/${report.id}`}>
                              <Eye className="w-4 h-4 mr-2" />
                              查看
                            </Link>
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            下载
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Share2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
