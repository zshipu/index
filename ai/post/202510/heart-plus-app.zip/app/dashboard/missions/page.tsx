import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Trophy, Target, Flame, Award, Star, CheckCircle2, Lock, ArrowRight } from "lucide-react"

export default function MissionsPage() {
  const stats = {
    level: 8,
    xp: 2450,
    xpToNext: 3000,
    streak: 28,
    totalMissions: 45,
    achievements: 12,
  }

  const activeMissions = [
    {
      id: "1",
      title: "连续测量 7 天",
      description: "保持每天至少测量一次的习惯",
      progress: 5,
      total: 7,
      reward: 150,
      category: "习惯养成",
      difficulty: "简单",
      icon: Target,
    },
    {
      id: "2",
      title: "完成 3 次呼吸练习",
      description: "使用前后对比功能测量呼吸练习效果",
      progress: 1,
      total: 3,
      reward: 200,
      category: "健康干预",
      difficulty: "中等",
      icon: Target,
    },
    {
      id: "3",
      title: "获得 5 次高价值测量",
      description: "完成 5 次 SignalValue > 80 的测量",
      progress: 3,
      total: 5,
      reward: 300,
      category: "数据质量",
      difficulty: "困难",
      icon: Star,
    },
  ]

  const availableMissions = [
    {
      id: "4",
      title: "生成本周报告",
      description: "创建并查看您的周度健康报告",
      reward: 100,
      category: "数据分析",
      difficulty: "简单",
      icon: Trophy,
    },
    {
      id: "5",
      title: "睡前放松",
      description: "连续 3 天在睡前进行测量",
      reward: 180,
      category: "习惯养成",
      difficulty: "中等",
      icon: Target,
    },
  ]

  const achievements = [
    {
      id: "1",
      title: "初心者",
      description: "完成第一次测量",
      unlocked: true,
      date: "2024-12-10",
      icon: Award,
    },
    {
      id: "2",
      title: "坚持不懈",
      description: "连续测量 30 天",
      unlocked: false,
      progress: 28,
      total: 30,
      icon: Flame,
    },
    {
      id: "3",
      title: "数据专家",
      description: "完成 100 次测量",
      unlocked: true,
      date: "2025-01-02",
      icon: Trophy,
    },
    {
      id: "4",
      title: "健康大师",
      description: "达到 10 级",
      unlocked: false,
      progress: 8,
      total: 10,
      icon: Star,
    },
  ]

  return (
    <div className="flex min-h-screen">
      <DashboardNav />

      <main className="flex-1 pb-20 lg:pb-0">
        <div className="container mx-auto p-4 lg:p-8 max-w-7xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">任务与成就</h1>
            <p className="text-muted-foreground">完成任务，解锁成就，提升等级</p>
          </div>

          {/* Player Stats */}
          <Card className="mb-6 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3">
                    <Trophy className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-3xl font-bold mb-1">{stats.level}</div>
                  <div className="text-sm text-muted-foreground">等级</div>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-chart-3/20 flex items-center justify-center mx-auto mb-3">
                    <Flame className="w-8 h-8 text-chart-3" />
                  </div>
                  <div className="text-3xl font-bold mb-1">{stats.streak}</div>
                  <div className="text-sm text-muted-foreground">连续天数</div>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-chart-2/20 flex items-center justify-center mx-auto mb-3">
                    <Target className="w-8 h-8 text-chart-2" />
                  </div>
                  <div className="text-3xl font-bold mb-1">{stats.totalMissions}</div>
                  <div className="text-sm text-muted-foreground">完成任务</div>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-chart-4/20 flex items-center justify-center mx-auto mb-3">
                    <Award className="w-8 h-8 text-chart-4" />
                  </div>
                  <div className="text-3xl font-bold mb-1">{stats.achievements}</div>
                  <div className="text-sm text-muted-foreground">解锁成就</div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-border">
                <div className="flex items-center justify-between mb-2 text-sm">
                  <span className="text-muted-foreground">升级进度</span>
                  <span className="font-medium">
                    {stats.xp} / {stats.xpToNext} XP
                  </span>
                </div>
                <Progress value={(stats.xp / stats.xpToNext) * 100} className="h-3" />
                <p className="text-xs text-muted-foreground mt-2">还需 {stats.xpToNext - stats.xp} XP 升至 9 级</p>
              </div>
            </CardContent>
          </Card>

          {/* Active Missions */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>进行中的任务</CardTitle>
                  <CardDescription>完成任务获得经验值和奖励</CardDescription>
                </div>
                <Badge variant="secondary">{activeMissions.length} 个任务</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeMissions.map((mission) => {
                  const Icon = mission.icon
                  const progressPercent = (mission.progress / mission.total) * 100
                  return (
                    <Card key={mission.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                          <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-7 h-7 text-primary" />
                          </div>

                          <div className="flex-1">
                            <div className="flex flex-wrap items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{mission.title}</h3>
                              <Badge variant="outline">{mission.category}</Badge>
                              <Badge
                                variant="secondary"
                                className={
                                  mission.difficulty === "困难"
                                    ? "bg-destructive/10 text-destructive"
                                    : mission.difficulty === "中等"
                                      ? "bg-chart-3/10 text-chart-3"
                                      : ""
                                }
                              >
                                {mission.difficulty}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">{mission.description}</p>

                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">
                                  进度: {mission.progress} / {mission.total}
                                </span>
                                <span className="font-medium text-primary">+{mission.reward} XP</span>
                              </div>
                              <Progress value={progressPercent} className="h-2" />
                            </div>
                          </div>

                          <Button variant="outline" size="sm" className="bg-transparent lg:self-start">
                            查看详情
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Available Missions */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>可接取任务</CardTitle>
                  <CardDescription>选择新任务开始挑战</CardDescription>
                </div>
                <Button variant="ghost" size="sm">
                  查看全部
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {availableMissions.map((mission) => {
                  const Icon = mission.icon
                  return (
                    <Card key={mission.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4 mb-4">
                          <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                            <Icon className="w-6 h-6 text-muted-foreground" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold mb-1">{mission.title}</h3>
                            <p className="text-sm text-muted-foreground">{mission.description}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{mission.category}</Badge>
                            <Badge variant="secondary">{mission.difficulty}</Badge>
                          </div>
                          <span className="text-sm font-medium text-primary">+{mission.reward} XP</span>
                        </div>

                        <Button className="w-full mt-4 bg-transparent" variant="outline">
                          接取任务
                        </Button>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle>成就系统</CardTitle>
              <CardDescription>解锁特殊成就展示您的健康之旅</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {achievements.map((achievement) => {
                  const Icon = achievement.icon
                  return (
                    <Card
                      key={achievement.id}
                      className={`${achievement.unlocked ? "bg-gradient-to-br from-primary/5 to-card border-primary/20" : "opacity-60"}`}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div
                            className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${
                              achievement.unlocked ? "bg-primary/20" : "bg-muted"
                            }`}
                          >
                            {achievement.unlocked ? (
                              <Icon className="w-7 h-7 text-primary" />
                            ) : (
                              <Lock className="w-7 h-7 text-muted-foreground" />
                            )}
                          </div>

                          <div className="flex-1">
                            <h3 className="font-semibold mb-1">{achievement.title}</h3>
                            <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>

                            {achievement.unlocked ? (
                              <div className="flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4 text-success" />
                                <span className="text-sm text-success">已解锁 · {achievement.date}</span>
                              </div>
                            ) : achievement.progress !== undefined ? (
                              <div className="space-y-2">
                                <div className="flex items-center justify-between text-sm">
                                  <span className="text-muted-foreground">
                                    {achievement.progress} / {achievement.total}
                                  </span>
                                  <span className="font-medium">
                                    {Math.round((achievement.progress / achievement.total) * 100)}%
                                  </span>
                                </div>
                                <Progress value={(achievement.progress / achievement.total) * 100} className="h-2" />
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <Lock className="w-4 h-4 text-muted-foreground" />
                                <span className="text-sm text-muted-foreground">未解锁</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
