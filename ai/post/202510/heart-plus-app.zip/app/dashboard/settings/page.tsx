"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, User, Shield, Smartphone, Heart, Mail, Lock } from "lucide-react"

export default function SettingsPage() {
  const [notifications, setNotifications] = useState({
    smartYield: true,
    measurements: true,
    reports: true,
    missions: false,
    clinician: true,
    marketing: false,
  })

  const [preferences, setPreferences] = useState({
    language: "zh-CN",
    theme: "system",
    measurementReminder: true,
    reminderTime: "09:00",
    weeklyReport: true,
    reportDay: "monday",
  })

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">设置</h1>
          <p className="text-muted-foreground">管理您的账户和应用偏好</p>
        </div>

        <Tabs defaultValue="account" className="space-y-6">
          <TabsList>
            <TabsTrigger value="account">
              <User className="w-4 h-4 mr-2" />
              账户
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="w-4 h-4 mr-2" />
              通知
            </TabsTrigger>
            <TabsTrigger value="preferences">
              <Heart className="w-4 h-4 mr-2" />
              偏好
            </TabsTrigger>
            <TabsTrigger value="privacy">
              <Shield className="w-4 h-4 mr-2" />
              隐私
            </TabsTrigger>
          </TabsList>

          {/* Account Settings */}
          <TabsContent value="account" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">个人信息</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">姓名</Label>
                  <Input id="name" defaultValue="张伟" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="email">邮箱</Label>
                  <Input id="email" type="email" defaultValue="zhangwei@example.com" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="phone">手机号</Label>
                  <Input id="phone" defaultValue="+86 138 0000 0000" className="mt-2" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="age">年龄</Label>
                    <Input id="age" type="number" defaultValue="45" className="mt-2" />
                  </div>
                  <div>
                    <Label htmlFor="gender">性别</Label>
                    <Select defaultValue="male">
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">男</SelectItem>
                        <SelectItem value="female">女</SelectItem>
                        <SelectItem value="other">其他</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button className="w-full">保存更改</Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">医疗信息</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="conditions">既往病史</Label>
                  <Input id="conditions" placeholder="如: 高血压、糖尿病" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="medications">当前用药</Label>
                  <Input id="medications" placeholder="如: 降压药、阿司匹林" className="mt-2" />
                </div>
                <div>
                  <Label htmlFor="allergies">药物过敏</Label>
                  <Input id="allergies" placeholder="如: 青霉素" className="mt-2" />
                </div>
                <Button className="w-full">保存医疗信息</Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">安全设置</h3>
              <div className="space-y-4">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Lock className="w-4 h-4 mr-2" />
                  修改密码
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  <Smartphone className="w-4 h-4 mr-2" />
                  双因素认证
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start text-red-600 hover:text-red-600 bg-transparent"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  注销账户
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Notification Settings */}
          <TabsContent value="notifications" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">推送通知</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">SmartYield提醒</div>
                    <div className="text-sm text-muted-foreground">当检测到高价值测量时机时通知您</div>
                  </div>
                  <Switch
                    checked={notifications.smartYield}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, smartYield: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">测量完成</div>
                    <div className="text-sm text-muted-foreground">测量分析完成后通知您</div>
                  </div>
                  <Switch
                    checked={notifications.measurements}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, measurements: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">周报生成</div>
                    <div className="text-sm text-muted-foreground">每周健康报告生成时通知您</div>
                  </div>
                  <Switch
                    checked={notifications.reports}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, reports: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">任务与成就</div>
                    <div className="text-sm text-muted-foreground">新任务和成就解锁时通知您</div>
                  </div>
                  <Switch
                    checked={notifications.missions}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, missions: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">专家审阅</div>
                    <div className="text-sm text-muted-foreground">医生审阅完成时通知您</div>
                  </div>
                  <Switch
                    checked={notifications.clinician}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, clinician: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">营销信息</div>
                    <div className="text-sm text-muted-foreground">接收产品更新和优惠信息</div>
                  </div>
                  <Switch
                    checked={notifications.marketing}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, marketing: checked })}
                  />
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Preferences */}
          <TabsContent value="preferences" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">应用偏好</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="language">语言</Label>
                  <Select
                    value={preferences.language}
                    onValueChange={(value) => setPreferences({ ...preferences, language: value })}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="zh-CN">简体中文</SelectItem>
                      <SelectItem value="zh-TW">繁體中文</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="theme">主题</Label>
                  <Select
                    value={preferences.theme}
                    onValueChange={(value) => setPreferences({ ...preferences, theme: value })}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">浅色</SelectItem>
                      <SelectItem value="dark">深色</SelectItem>
                      <SelectItem value="system">跟随系统</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">测量设置</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">每日提醒</div>
                    <div className="text-sm text-muted-foreground">设置固定时间的测量提醒</div>
                  </div>
                  <Switch
                    checked={preferences.measurementReminder}
                    onCheckedChange={(checked) => setPreferences({ ...preferences, measurementReminder: checked })}
                  />
                </div>
                {preferences.measurementReminder && (
                  <div>
                    <Label htmlFor="reminderTime">提醒时间</Label>
                    <Input
                      id="reminderTime"
                      type="time"
                      value={preferences.reminderTime}
                      onChange={(e) => setPreferences({ ...preferences, reminderTime: e.target.value })}
                      className="mt-2"
                    />
                  </div>
                )}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">报告设置</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">自动生成周报</div>
                    <div className="text-sm text-muted-foreground">每周自动生成健康报告</div>
                  </div>
                  <Switch
                    checked={preferences.weeklyReport}
                    onCheckedChange={(checked) => setPreferences({ ...preferences, weeklyReport: checked })}
                  />
                </div>
                {preferences.weeklyReport && (
                  <div>
                    <Label htmlFor="reportDay">生成日期</Label>
                    <Select
                      value={preferences.reportDay}
                      onValueChange={(value) => setPreferences({ ...preferences, reportDay: value })}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monday">每周一</SelectItem>
                        <SelectItem value="sunday">每周日</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </Card>
          </TabsContent>

          {/* Privacy Settings */}
          <TabsContent value="privacy" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">数据隐私</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">匿名数据分享</div>
                    <div className="text-sm text-muted-foreground">帮助改进AI算法（数据完全匿名）</div>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-foreground">参与研究项目</div>
                    <div className="text-sm text-muted-foreground">参与医学研究并获得奖励</div>
                  </div>
                  <Switch />
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">数据管理</h3>
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  导出我的数据
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start text-red-600 hover:text-red-600 bg-transparent"
                >
                  删除所有数据
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">法律文件</h3>
              <div className="space-y-3">
                <Button variant="ghost" className="w-full justify-start">
                  隐私政策
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  服务条款
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  医疗免责声明
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
