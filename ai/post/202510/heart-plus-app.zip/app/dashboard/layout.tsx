import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "控制台 - 心脏+",
  description: "心脏健康监测控制台",
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
