"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Heart,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Zap,
  Moon,
  Target,
} from "lucide-react"
import Link from "next/link"

export default function InsightsPage() {
  const insights = {
    weekly: [
      {
        id: 1,
        type: "positive",
        title: "心率变异性提升",
        description: "本周您的HRV平均值提升了15%，说明自主神经系统功能改善",
        metric: "+15%",
        icon: TrendingUp,
        color: "text-green-600",
        bgColor: "bg-green-500/10",
        borderColor: "border-green-500/20",
        recommendation: "继续保持良好的睡眠和放松练习",
      },
      {
        id: 2,
        type: "warning",
        title: "夜间心率偏高",
        description: "过去3天夜间静息心率比平时高8 bpm，可能与睡眠质量有关",
        metric: "+8 bpm",
        icon: Moon,
        color: "text-orange-600",
        bgColor: "bg-orange-500/10",
        borderColor: "border-orange-500/20",
        recommendation: "建议改善睡眠环境，避免睡前使用电子设备",
      },
      {
        id: 3,
        type: "positive",
        title: "生物反馈效果显著",
        description: "深呼吸练习平均降低心率18 bpm，效果优于85%的用户",
        metric: "-18 bpm",
        icon: Heart,
        color: "text-green-600",
        bgColor: "bg-green-500/10",
        borderColor: "border-green-500/20",
        recommendation: "建议每天进行2-3次深呼吸练习",
      },
      {
        id: 4,
        type: "info",
        title: "测量时机优化",
        description: "AI发现您在运动后30分钟测量的SignalValue最高",
        metric: "SignalValue +25",
        icon: Zap,
        color: "text-primary",
        bgColor: "bg-primary/10",
        borderColor: "border-primary/20",
        recommendation: "SmartYield将在此时段优先提醒您测量",
      },
    ],
    patterns: [
      {
        id: 1,
        title: "周末心率模式",
        description: "周末早晨心率比工作日低12 bpm，说明周末放松效果好",
        timeframe: "过去4周",
        confidence: 92,
      },
      {
        id: 2,
        title: "咖啡因影响",
        description: "饮用咖啡后1小时心率平均升高15 bpm，持续约3小时",
        timeframe: "过去2周",
        confidence: 88,
      },
      {
        id: 3,
        title: "运动恢复能力",
        description: "运动后心率恢复速度提升，第一分钟下降35 bpm（优秀水平）",
        timeframe: "过去1个月",
        confidence: 95,
      },
    ],
    predictions: [
      {
        id: 1,
        title: "本周健康趋势",
        prediction: "基于当前数据，预计本周整体心率将保持稳定，HRV可能继续提升",
        confidence: 85,
        icon: TrendingUp,
      },
      {
        id: 2,
        title: "压力预警",
        prediction: "明天下午3-5点压力水平可能较高（基于历史模式），建议提前安排放松时间",
        confidence: 78,
        icon: AlertCircle,
      },
    ],
    comparisons: {
      ageGroup: {
        label: "同龄人对比",
        metrics: [
          { name: "静息心率", value: 68, average: 72, percentile: 65 },
          { name: "HRV", value: 45, average: 38, percentile: 78 },
          { name: "测量频率", value: 12, average: 8, percentile: 85 },
        ],
      },
      personal: {
        label: "个人历史对比",
        metrics: [
          { name: "本周 vs 上周", change: -3, metric: "平均心率", trend: "down" },
          { name: "本月 vs 上月", change: +12, metric: "HRV", trend: "up" },
          { name: "本周 vs 上周", change: +5, metric: "SignalValue", trend: "up" },
        ],
      },
    },
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-2">健康洞察</h1>
          <p className="text-muted-foreground">AI驱动的个性化健康分析与建议</p>
        </div>

        <Tabs defaultValue="insights" className="space-y-6">
          <TabsList>
            <TabsTrigger value="insights">
              <Zap className="w-4 h-4 mr-2" />
              本周洞察
            </TabsTrigger>
            <TabsTrigger value="patterns">
              <Activity className="w-4 h-4 mr-2" />
              行为模式
            </TabsTrigger>
            <TabsTrigger value="predictions">
              <TrendingUp className="w-4 h-4 mr-2" />
              预测分析
            </TabsTrigger>
            <TabsTrigger value="compare">
              <Target className="w-4 h-4 mr-2" />
              对比分析
            </TabsTrigger>
          </TabsList>

          {/* Weekly Insights */}
          <TabsContent value="insights" className="space-y-4">
            {insights.weekly.map((insight) => {
              const Icon = insight.icon
              return (
                <Card key={insight.id} className={`p-6 border-2 ${insight.borderColor}`}>
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-12 h-12 rounded-xl ${insight.bgColor} flex items-center justify-center flex-shrink-0`}
                    >
                      <Icon className={`w-6 h-6 ${insight.color}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-lg font-semibold text-foreground">{insight.title}</h3>
                        <Badge variant="outline" className={`${insight.bgColor} ${insight.color} border-0`}>
                          {insight.metric}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground mb-3">{insight.description}</p>
                      <div className={`p-3 ${insight.bgColor} rounded-lg`}>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className={`w-4 h-4 ${insight.color} mt-0.5 flex-shrink-0`} />
                          <span className="text-sm text-foreground">{insight.recommendation}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </TabsContent>

          {/* Behavior Patterns */}
          <TabsContent value="patterns" className="space-y-4">
            {insights.patterns.map((pattern) => (
              <Card key={pattern.id} className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg font-semibold text-foreground">{pattern.title}</h3>
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                    置信度 {pattern.confidence}%
                  </Badge>
                </div>
                <p className="text-muted-foreground mb-3">{pattern.description}</p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>分析周期: {pattern.timeframe}</span>
                </div>
              </Card>
            ))}

            <Card className="p-6 bg-muted/30">
              <div className="flex items-start gap-3">
                <Activity className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <h4 className="font-semibold text-foreground mb-1">持续学习中</h4>
                  <p className="text-sm text-muted-foreground">
                    AI正在分析您的更多行为模式，随着数据积累，洞察将更加精准
                  </p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Predictions */}
          <TabsContent value="predictions" className="space-y-4">
            {insights.predictions.map((prediction) => {
              const Icon = prediction.icon
              return (
                <Card key={prediction.id} className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-lg font-semibold text-foreground">{prediction.title}</h3>
                        <Badge variant="outline">准确率 {prediction.confidence}%</Badge>
                      </div>
                      <p className="text-muted-foreground">{prediction.prediction}</p>
                    </div>
                  </div>
                </Card>
              )
            })}

            <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <div className="flex items-start gap-3">
                <Zap className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <h4 className="font-semibold text-foreground mb-1">预测模型说明</h4>
                  <p className="text-sm text-muted-foreground">
                    预测基于您的历史数据、行为模式和机器学习算法。准确率会随着数据积累而提升。
                  </p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Comparisons */}
          <TabsContent value="compare" className="space-y-6">
            {/* Age Group Comparison */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">{insights.comparisons.ageGroup.label}</h3>
              <div className="space-y-4">
                {insights.comparisons.ageGroup.metrics.map((metric, index) => (
                  <div key={index}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">{metric.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">您: {metric.value}</span>
                        <span className="text-sm text-muted-foreground">平均: {metric.average}</span>
                      </div>
                    </div>
                    <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="absolute left-0 top-0 h-full bg-primary/30 rounded-full"
                        style={{ width: "100%" }}
                      />
                      <div
                        className="absolute left-0 top-0 h-full bg-primary rounded-full"
                        style={{ width: `${metric.percentile}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-muted-foreground">超过 {metric.percentile}% 的用户</span>
                      <Badge variant="secondary" className="text-xs">
                        {metric.percentile >= 75 ? "优秀" : metric.percentile >= 50 ? "良好" : "一般"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Personal History Comparison */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">{insights.comparisons.personal.label}</h3>
              <div className="space-y-4">
                {insights.comparisons.personal.metrics.map((metric, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                    <div>
                      <div className="font-medium text-foreground">{metric.name}</div>
                      <div className="text-sm text-muted-foreground">{metric.metric}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      {metric.trend === "up" ? (
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      ) : (
                        <TrendingDown className="w-5 h-5 text-green-600" />
                      )}
                      <span
                        className={`text-lg font-bold ${metric.trend === "up" ? "text-green-600" : "text-green-600"}`}
                      >
                        {metric.change > 0 ? "+" : ""}
                        {metric.change}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 bg-muted/30">
              <div className="flex items-start gap-3">
                <Target className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <h4 className="font-semibold text-foreground mb-1">对比数据说明</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    同龄人数据来自匿名化的用户群体统计，个人历史对比帮助您追踪进步
                  </p>
                  <Button variant="link" className="h-auto p-0 text-primary" asChild>
                    <Link href="/dashboard/settings">管理数据分享设置</Link>
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
