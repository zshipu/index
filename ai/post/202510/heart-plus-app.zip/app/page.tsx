import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Activity, Heart, TrendingUp, Award, FileText, Zap } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Heart className="w-6 h-6 text-primary-foreground" fill="currentColor" />
            </div>
            <span className="text-xl font-semibold">心脏+</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              功能
            </Link>
            <Link
              href="#how-it-works"
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              工作原理
            </Link>
            <Link href="#pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              定价
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/login">登录</Link>
            </Button>
            <Button asChild>
              <Link href="/signup">开始使用</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-primary/5 to-transparent" />

        <div className="container mx-auto px-4 py-20 md:py-32 relative">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              AI 驱动的心脏健康监测
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
              让每次心电测量
              <span className="text-primary">更有价值</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 text-pretty leading-relaxed">
              从频率驱动到价值驱动，智能识别最佳测量时机， 让微小变化可见，让健康管理更有意义
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="w-full sm:w-auto" asChild>
                <Link href="/signup">免费开始</Link>
              </Button>
              <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent" asChild>
                <Link href="/demo">查看演示</Link>
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mt-6">支持 Apple Watch ECG · 无需每日测量 · AI 智能分析</p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">核心功能</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              基于产品策略的创新功能，解决测量疲劳，提升用户粘性
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* SmartYield */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">SmartYield 智能触发</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                基于 PPG 和 HRV 被动信号，在最佳时机提醒测量， 而非每日重复提醒
              </p>
            </Card>

            {/* SignalValue Score */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-chart-2" />
              </div>
              <h3 className="text-xl font-semibold mb-2">SignalValue 评分</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                为每次测量评分（0-100），量化诊断价值， 让用户知道哪些数据真正重要
              </p>
            </Card>

            {/* Micro-Delta Insights */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center mb-4">
                <Activity className="w-6 h-6 text-chart-3" />
              </div>
              <h3 className="text-xl font-semibold mb-2">微变化洞察</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                可视化临床阈值以下的微小变化， 让"正常"结果也能提供有价值的信息
              </p>
            </Card>

            {/* Pre/Post Biofeedback */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center mb-4">
                <Activity className="w-6 h-6 text-chart-4" />
              </div>
              <h3 className="text-xl font-semibold mb-2">前后对比反馈</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                测量干预前后的心率变化， 直观展示呼吸练习、冥想等活动的即时效果
              </p>
            </Card>

            {/* Weekly Reports */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-chart-5/10 flex items-center justify-center mb-4">
                <FileText className="w-6 h-6 text-chart-5" />
              </div>
              <h3 className="text-xl font-semibold mb-2">周报告系统</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                自动生成可分享的 PDF 健康报告， 方便与医生沟通，提升专业性
              </p>
            </Card>

            {/* Gamification */}
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">游戏化任务</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                完成健康挑战获得徽章和奖励， 稀有心跳侦探功能让监测更有趣
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 md:py-32 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">工作原理</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              从频率驱动到价值驱动的测量模式转变
            </p>
          </div>

          <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                1
              </div>
              <h3 className="text-lg font-semibold mb-2">被动监测</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Apple Watch 持续收集 PPG 和 HRV 数据， 无需用户主动操作
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                2
              </div>
              <h3 className="text-lg font-semibold mb-2">智能触发</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                AI 识别异常信号或最佳测量时机， 发送个性化提醒
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                3
              </div>
              <h3 className="text-lg font-semibold mb-2">价值分析</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                每次测量获得 SignalValue 评分， 微变化可视化，专家按需审阅
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">开始您的智能心脏健康之旅</h2>
            <p className="text-lg text-muted-foreground mb-8 text-pretty">加入数千名用户，体验更有价值的心脏健康监测</p>
            <Button size="lg" asChild>
              <Link href="/signup">免费注册</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                  <Heart className="w-5 h-5 text-primary-foreground" fill="currentColor" />
                </div>
                <span className="font-semibold">心脏+</span>
              </div>
              <p className="text-sm text-muted-foreground">AI 驱动的心脏健康监测平台</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">产品</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="#features" className="hover:text-foreground transition-colors">
                    功能
                  </Link>
                </li>
                <li>
                  <Link href="#pricing" className="hover:text-foreground transition-colors">
                    定价
                  </Link>
                </li>
                <li>
                  <Link href="/demo" className="hover:text-foreground transition-colors">
                    演示
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">支持</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/help" className="hover:text-foreground transition-colors">
                    帮助中心
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-foreground transition-colors">
                    联系我们
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-foreground transition-colors">
                    隐私政策
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">公司</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/about" className="hover:text-foreground transition-colors">
                    关于我们
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-foreground transition-colors">
                    博客
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-foreground transition-colors">
                    招聘
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-12 pt-8 text-center text-sm text-muted-foreground">
            <p>© 2025 心脏+. 保留所有权利.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
