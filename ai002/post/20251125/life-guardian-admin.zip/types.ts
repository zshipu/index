import { LucideIcon } from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  icon?: LucideIcon;
  children?: NavItem[];
}

export interface User {
  id: string;
  sortId?: number; // Sorting number 999999
  name: string;
  nickname: string;
  gender: '男' | '女';
  age: number;
  phone: string;
  device: string; // Bound device name
  deviceId?: string; // Device SN/ID
  riskLevel: '高' | '中' | '低' | '无';
  riskTags?: string[]; // e.g. ["Blood Pressure Normal", "Obese"]
  source: string;
  registerTime: string;
  lastLogin: string;
  status: '正常' | '停用';
  avatar?: string;
  email?: string;
  doctor?: string;
  department?: string;
}

export interface StatCardProps {
  title: string;
  value: string | number;
  trend?: string;
  trendUp?: boolean;
  icon: LucideIcon;
  color: string;
}

export interface TabItem {
  id: string;
  label: string;
  closable: boolean;
  data?: any; // To pass user object or ID
}