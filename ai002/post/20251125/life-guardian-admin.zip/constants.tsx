import { 
  LayoutDashboard, 
  Settings, 
  Watch, 
  Users, 
  Activity, 
  Stethoscope, 
  MessageSquare, 
  UserCircle 
} from 'lucide-react';
import { NavItem, User } from './types';

export const MENU_ITEMS: NavItem[] = [
  {
    id: 'dashboard',
    label: '首页',
    icon: LayoutDashboard,
  },
  {
    id: 'system',
    label: '系统管理',
    icon: Settings,
    children: [
      { id: 'sys_admin', label: '管理员管理' },
      { id: 'sys_role', label: '角色管理' },
      { id: 'sys_dept', label: '部门管理' },
    ]
  },
  {
    id: 'device',
    label: '设备管理',
    icon: Watch,
    children: [
      { id: 'dev_watch', label: '手表设备列表' },
      { id: 'dev_instrument', label: '仪器设备列表' },
    ]
  },
  {
    id: 'user',
    label: '用户管理',
    icon: Users,
    children: [
      { id: 'user_list', label: '设备用户列表' },
      { id: 'user_map', label: '用户地图' },
    ]
  },
  {
    id: 'monitor',
    label: '监控管理',
    icon: Activity,
    children: [
      { id: 'mon_map', label: '设备地图' },
      { id: 'mon_fence', label: '智能围栏' },
      { id: 'mon_alert', label: '手表报警信息' },
      { id: 'mon_health', label: '异常健康' },
    ]
  },
  {
    id: 'medical',
    label: '医疗健康管理',
    icon: Stethoscope,
    children: [
      { id: 'med_report', label: '医疗报告专家解读' },
      { id: 'med_monthly', label: '健康月报专家解读' },
    ]
  },
  {
    id: 'cs',
    label: '智能客服',
    icon: MessageSquare,
    children: [
      { id: 'cs_chat', label: '用户沟通' },
    ]
  },
  {
    id: 'profile',
    label: '个人中心',
    icon: UserCircle,
  }
];

export const MOCK_USERS: User[] = [
  {
    id: '1',
    name: '张伟',
    nickname: '大张',
    gender: '男',
    age: 65,
    phone: '13800138000',
    device: 'HELOWIN WATCH H1',
    riskLevel: '中',
    source: 'APP注册',
    registerTime: '2023-10-12 10:30',
    lastLogin: '2023-10-25 09:15',
    status: '正常'
  },
  {
    id: '2',
    name: '李秀英',
    nickname: '秀英阿姨',
    gender: '女',
    age: 72,
    phone: '13912345678',
    device: 'TE5100Y-C',
    riskLevel: '高',
    source: '医院推广',
    registerTime: '2023-09-05 14:20',
    lastLogin: '2023-10-24 18:40',
    status: '正常'
  },
  {
    id: '3',
    name: '王强',
    nickname: '强哥',
    gender: '男',
    age: 58,
    phone: '13787654321',
    device: 'M101 Air',
    riskLevel: '低',
    source: '亲友邀请',
    registerTime: '2023-10-20 11:00',
    lastLogin: '2023-10-25 08:00',
    status: '正常'
  },
  {
    id: '4',
    name: '刘芳',
    nickname: '芳芳',
    gender: '女',
    age: 45,
    phone: '13611223344',
    device: '未绑定',
    riskLevel: '无',
    source: 'APP注册',
    registerTime: '2023-10-24 16:45',
    lastLogin: '2023-10-24 17:00',
    status: '停用'
  },
  {
    id: '5',
    name: '赵本山',
    nickname: '老赵',
    gender: '男',
    age: 68,
    phone: '13555555555',
    device: 'TE-7000Y-C',
    riskLevel: '中',
    source: '社区活动',
    registerTime: '2023-08-15 09:00',
    lastLogin: '2023-10-25 07:30',
    status: '正常'
  }
];