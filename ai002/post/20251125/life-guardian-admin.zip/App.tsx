import React, { useState } from 'react';
import { 
  Bell, 
  Maximize2, 
  Type, 
  User, 
  ChevronDown, 
  Menu, 
  ChevronRight,
  ChevronLeft,
  X,
  Search,
  LayoutDashboard
} from 'lucide-react';
import { MENU_ITEMS } from './constants';
import { NavItem, TabItem, User as UserType } from './types';
import Dashboard from './components/Dashboard';
import UserList from './components/UserList';

// Import new components
import { SystemAdmin, SystemRole, SystemDept } from './components/SystemPages';
import { DeviceWatch, DeviceInstrument } from './components/DevicePages';
import { MonitorMap, MonitorFence, MonitorAlert, MonitorHealth, UserMap } from './components/MonitorPages';
import { MedicalReport, MedicalMonthly } from './components/MedicalPages';
import { CSChat } from './components/ServicePages';
import { ProfilePage } from './components/ProfilePage';
import { UserDetails } from './components/UserDetails';

const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeMenuId, setActiveMenuId] = useState<string>('dashboard');
  const [openSubMenus, setOpenSubMenus] = useState<string[]>(['system', 'device', 'user', 'monitor']); // Expanded defaults
  const [activeTabId, setActiveTabId] = useState<string>('dashboard');
  
  // Tab Management
  const [tabs, setTabs] = useState<TabItem[]>([
    { id: 'dashboard', label: '首页', closable: false },
    { id: 'user_list', label: '设备用户列表', closable: true },
  ]);

  const toggleSubMenu = (id: string) => {
    setOpenSubMenus(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleMenuClick = (item: NavItem) => {
    if (item.children) {
      toggleSubMenu(item.id);
    } else {
      setActiveMenuId(item.id);
      // Add to tabs if not exists
      if (!tabs.find(t => t.id === item.id)) {
        setTabs([...tabs, { id: item.id, label: item.label, closable: true }]);
      }
      setActiveTabId(item.id);
    }
  };

  const closeTab = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    if (activeTabId === id && newTabs.length > 0) {
      setActiveTabId(newTabs[newTabs.length - 1].id);
      setActiveMenuId(newTabs[newTabs.length - 1].id);
    }
  };
  
  const handleViewUser = (user: UserType) => {
     const tabId = `user_detail_${user.id}`;
     if (!tabs.find(t => t.id === tabId)) {
        setTabs([...tabs, { id: tabId, label: `用户详情-${user.name}`, closable: true, data: user }]);
     }
     setActiveTabId(tabId);
  };

  const renderMenuItem = (item: NavItem, depth: number = 0) => {
    const isActive = activeMenuId === item.id;
    const hasChildren = item.children && item.children.length > 0;
    const isOpen = openSubMenus.includes(item.id);
    const Icon = item.icon;

    return (
      <div key={item.id} className="select-none">
        <div 
          className={`
            flex items-center justify-between px-4 py-3 cursor-pointer transition-colors
            ${isActive && !hasChildren ? 'text-blue-400 bg-slate-800' : 'text-slate-400 hover:text-white hover:bg-slate-800'}
            ${depth > 0 ? 'pl-12 text-sm' : ''}
          `}
          onClick={() => handleMenuClick(item)}
        >
          <div className="flex items-center space-x-3">
            {Icon && <Icon size={18} />}
            <span className={`${!sidebarOpen && depth === 0 ? 'hidden' : 'block'}`}>{item.label}</span>
          </div>
          {hasChildren && sidebarOpen && (
            <ChevronDown size={14} className={`transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          )}
        </div>
        {hasChildren && isOpen && sidebarOpen && (
          <div className="bg-slate-900/50">
            {item.children!.map(child => renderMenuItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const renderContent = () => {
    // Check if it's a user detail tab
    if (activeTabId.startsWith('user_detail_')) {
       const tab = tabs.find(t => t.id === activeTabId);
       return <UserDetails user={tab?.data} />;
    }

    switch (activeTabId) {
      case 'dashboard': return <Dashboard />;
      
      // System
      case 'sys_admin': return <SystemAdmin />;
      case 'sys_role': return <SystemRole />;
      case 'sys_dept': return <SystemDept />;
      
      // Device
      case 'dev_watch': return <DeviceWatch />;
      case 'dev_instrument': return <DeviceInstrument />;
      
      // User
      case 'user_list': return <UserList onViewUser={handleViewUser} />;
      case 'user_map': return <UserMap />;
      
      // Monitor
      case 'mon_map': return <MonitorMap />;
      case 'mon_fence': return <MonitorFence />;
      case 'mon_alert': return <MonitorAlert />;
      case 'mon_health': return <MonitorHealth />;
      
      // Medical
      case 'med_report': return <MedicalReport />;
      case 'med_monthly': return <MedicalMonthly />;
      
      // Service
      case 'cs_chat': return <CSChat />;
      
      // Profile
      case 'profile': return <ProfilePage />;

      default:
        return (
          <div className="flex flex-col items-center justify-center h-full text-slate-400">
             <div className="bg-slate-100 p-8 rounded-full mb-4">
               <LayoutDashboard size={48} className="text-slate-300"/>
             </div>
             <h2 className="text-xl font-medium text-slate-600 mb-2">正在开发中</h2>
             <p>该模块功能 "{tabs.find(t => t.id === activeTabId)?.label}" 即将上线</p>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 w-full overflow-hidden">
      {/* Sidebar */}
      <aside 
        className={`bg-[#001529] text-white flex-shrink-0 transition-all duration-300 ease-in-out flex flex-col
        ${sidebarOpen ? 'w-64' : 'w-16'}
      `}
      >
        <div className="h-16 flex items-center justify-center border-b border-slate-700">
           <div className="flex items-center space-x-2">
             <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
               <span className="font-bold text-lg">L</span>
             </div>
             {sidebarOpen && <span className="font-bold text-lg tracking-wide">生命卫士</span>}
           </div>
        </div>

        <div className="flex-1 overflow-y-auto py-2 custom-scrollbar">
          {MENU_ITEMS.map(item => renderMenuItem(item))}
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-14 bg-white shadow-sm border-b border-slate-200 flex items-center justify-between px-4 shrink-0 z-10">
          <div className="flex items-center">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition"
            >
              <Menu size={20} />
            </button>
            <div className="ml-4 flex items-center text-sm text-slate-500">
              <span className="hover:text-blue-500 cursor-pointer">首页</span>
              <span className="mx-2">/</span>
              <span className="hover:text-blue-500 cursor-pointer">{tabs.find(t => t.id === activeTabId)?.label || 'Dashboard'}</span>
              {activeTabId === 'user_list' && (
                <>
                   <span className="mx-2">/</span>
                   <span className="text-slate-800 font-medium">设备用户列表</span>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-4">
             <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
               <Search size={18} />
             </button>
             <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
               <Maximize2 size={18} />
             </button>
             <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
               <Type size={18} />
             </button>
             <div className="relative">
               <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 relative">
                 <Bell size={18} />
                 <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
               </button>
             </div>
             
             <div className="flex items-center space-x-2 pl-4 border-l border-slate-200 cursor-pointer" onClick={() => {
                setActiveTabId('profile');
                setActiveMenuId('profile');
                if (!tabs.find(t => t.id === 'profile')) {
                  setTabs([...tabs, { id: 'profile', label: '个人中心', closable: true }]);
                }
             }}>
                <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                   <User size={16} />
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-slate-700">超级管理员</p>
                </div>
                <ChevronDown size={14} className="text-slate-400" />
             </div>
          </div>
        </header>

        {/* Tab Bar - Similar to screenshot */}
        <div className="bg-white border-b border-slate-200 px-2 flex items-center space-x-1 overflow-x-auto shrink-0 h-10 shadow-sm z-0">
          {tabs.map(tab => (
            <div 
              key={tab.id}
              onClick={() => {
                setActiveTabId(tab.id);
                // Try to find if this tab corresponds to a menu item to highlight it
                let foundInMenu = MENU_ITEMS.find(m => m.id === tab.id || m.children?.find(c => c.id === tab.id));
                if (tab.id.startsWith('user_detail')) {
                    // Force highlight user management for details view
                    foundInMenu = MENU_ITEMS.find(m => m.id === 'user');
                }
                if(foundInMenu) setActiveMenuId(foundInMenu.id);
              }}
              className={`
                group flex items-center space-x-2 px-4 py-2 text-sm cursor-pointer border-t-2 transition-all select-none whitespace-nowrap
                ${activeTabId === tab.id 
                  ? 'border-blue-500 bg-blue-50 text-blue-600 font-medium' 
                  : 'border-transparent text-slate-600 hover:text-slate-800 hover:bg-slate-50'}
              `}
            >
              <span>{tab.label}</span>
              {tab.closable && (
                <button 
                  onClick={(e) => closeTab(e, tab.id)}
                  className={`opacity-0 group-hover:opacity-100 p-0.5 rounded-full hover:bg-slate-200 ${activeTabId === tab.id ? 'opacity-100' : ''}`}
                >
                  <X size={12} />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Viewport */}
        <main className="flex-1 overflow-y-auto bg-slate-50 custom-scrollbar relative">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;