import React from 'react';
import { Eye, FileText, Layers, Bell } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, CartesianGrid } from 'recharts';

// --- Constants & Styles ---
const THEME = {
  bg: '#081319', // Deep teal/black
  cyan: '#22d3ee', // Cyan-400
  cyanGlow: 'rgba(34, 211, 238, 0.6)',
  green: '#4ade80', // Green-400
  greenGlow: 'rgba(74, 222, 128, 0.6)',
  red: '#f87171', // Red-400
  textWhite: '#f1f5f9',
  textSub: '#94a3b8',
  panelBorder: 'rgba(34, 211, 238, 0.15)',
  panelBg: 'rgba(15, 23, 42, 0.4)',
};

const styles = `
  @keyframes scan-vertical {
    0% { top: 0%; opacity: 0; }
    10% { opacity: 1; }
    90% { opacity: 1; }
    100% { top: 100%; opacity: 0; }
  }
  @keyframes pulse-ring {
    0% { transform: scale(0.8); opacity: 0.8; }
    100% { transform: scale(1.5); opacity: 0; }
  }
  @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-5px); }
  }
  .bg-grid-pattern {
    background-image: 
      linear-gradient(rgba(34, 211, 238, 0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(34, 211, 238, 0.03) 1px, transparent 1px);
    background-size: 40px 40px;
  }
  .panel-title-deco {
    border-left: 3px solid #22d3ee;
    padding-left: 8px;
    font-size: 14px;
    font-weight: 700;
    color: #fff;
    display: flex;
    align-items: center;
    background: linear-gradient(90deg, rgba(34, 211, 238, 0.1) 0%, transparent 100%);
    padding-top: 4px;
    padding-bottom: 4px;
    margin-bottom: 12px;
  }
  .holo-text {
    text-shadow: 0 0 5px rgba(34, 211, 238, 0.5);
  }
`;

// --- Mock Data ---
const ecgData = Array.from({ length: 80 }, (_, i) => ({
  time: i,
  value: 50 + Math.random() * 2 + (i % 20 === 10 ? 30 : 0) - (i % 20 === 12 ? 10 : 0)
}));
const hrData = [
  { time: '20:30', value: 75 }, { time: '20:50', value: 78 }, { time: '21:10', value: 112 },
  { time: '21:30', value: 85 }, { time: '21:50', value: 80 }, { time: '22:10', value: 76 }, { time: '22:30', value: 75 }
];
const spo2Data = Array.from({ length: 20 }, (_, i) => ({ time: i, value: 99 }));


// --- High Fidelity Meridian Man ---
const MeridianMan: React.FC = () => {
  return (
    <div className="relative w-full h-full flex items-center justify-center perspective-[1000px]">
      
      {/* 1. Floor Platform (Perspective Rings) */}
      <div className="absolute bottom-[5%] w-[300px] h-[100px] flex items-center justify-center">
         {/* Concentric Rings */}
         <div className="absolute w-full h-full rounded-[100%] border border-emerald-500/30 shadow-[0_0_20px_rgba(16,185,129,0.2)] transform rotate-x-[60deg]"></div>
         <div className="absolute w-[80%] h-[80%] rounded-[100%] border border-emerald-400/40 transform rotate-x-[60deg]"></div>
         <div className="absolute w-[60%] h-[60%] rounded-[100%] border border-emerald-300/50 transform rotate-x-[60deg]"></div>
         <div className="absolute w-[40%] h-[40%] rounded-[100%] bg-emerald-400/20 blur-md transform rotate-x-[60deg] animate-pulse"></div>
         {/* Rising Light Column */}
         <div className="absolute bottom-0 w-[120px] h-[100px] bg-gradient-to-t from-emerald-500/20 to-transparent blur-xl"></div>
      </div>

      <svg viewBox="0 0 400 700" className="h-[95%] w-auto z-10 overflow-visible" style={{ filter: 'drop-shadow(0 0 10px rgba(34, 211, 238, 0.3))' }}>
        <defs>
          <radialGradient id="gradBody" cx="50%" cy="40%" r="50%">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.4" />
            <stop offset="70%" stopColor="#0891b2" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#081319" stopOpacity="0.0" />
          </radialGradient>
          <linearGradient id="gradNerve" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ccfbf1" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#2dd4bf" stopOpacity="0.5" />
          </linearGradient>
          <filter id="glow-strong">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* --- BODY SHELL (Translucent) --- */}
        <g transform="translate(200, 350)">
           {/* Head */}
           <path d="M-28,-290 C-38,-290 -45,-275 -40,-250 C-40,-250 -35,-230 -25,-220 L-25,-210 L25,-210 L25,-220 C35,-230 40,-250 40,-250 C45,-275 38,-290 28,-290 Z" 
                 fill="url(#gradBody)" stroke="#22d3ee" strokeWidth="1" strokeOpacity="0.4" />
           
           {/* Body Silhouette */}
           <path d="
             M-25,-210 
             C-50,-205 -75,-195 -90,-180  
             C-95,-175 -100,-150 -90,-80  
             L-85,0 L-95,20 L-45,120  
             L-40,240 L-50,310 L-20,320 L-10,150 
             L10,150 
             L20,320 L50,310 L40,240 
             L45,120 L95,20 L85,0 
             L90,-80 C100,-150 95,-175 90,-180 
             C75,-195 50,-205 25,-210 
             Z
           " fill="url(#gradBody)" stroke="#22d3ee" strokeWidth="0.8" strokeOpacity="0.3" />
           
           {/* Inner Volume Glow (Chest) */}
           <ellipse cx="0" cy="-140" rx="30" ry="40" fill="#22d3ee" fillOpacity="0.15" filter="url(#glow-strong)" />
        </g>

        {/* --- NERVOUS SYSTEM (Glowing Skeleton) --- */}
        <g transform="translate(200, 350)" stroke="url(#gradNerve)" fill="none" strokeLinecap="round">
           {/* Spine */}
           <path d="M0,-210 L0,0" strokeWidth="3" strokeOpacity="0.8" strokeDasharray="1 3" />
           <path d="M0,0 L0,120" strokeWidth="3" strokeOpacity="0.6" strokeDasharray="1 3" />

           {/* Ribs (Left) */}
           <path d="M0,-190 C-15,-185 -35,-170 -25,-150" strokeWidth="1.5" strokeOpacity="0.6" />
           <path d="M0,-170 C-20,-165 -40,-150 -30,-130" strokeWidth="1.5" strokeOpacity="0.6" />
           <path d="M0,-150 C-25,-145 -45,-130 -35,-110" strokeWidth="1.5" strokeOpacity="0.6" />
           {/* Ribs (Right) */}
           <path d="M0,-190 C15,-185 35,-170 25,-150" strokeWidth="1.5" strokeOpacity="0.6" />
           <path d="M0,-170 C20,-165 40,-150 30,-130" strokeWidth="1.5" strokeOpacity="0.6" />
           <path d="M0,-150 C25,-145 45,-130 35,-110" strokeWidth="1.5" strokeOpacity="0.6" />

           {/* Arms (Left) - Nerves */}
           <path d="M0,-200 C-30,-200 -50,-195 -70,-170 L-80,-80 L-85,0 L-95,20" strokeWidth="1.5" />
           <path d="M-70,-170 L-60,-90" strokeWidth="0.8" opacity="0.5"/>
           <path d="M-80,-80 L-70,10" strokeWidth="0.8" opacity="0.5"/>
           {/* Arms (Right) - Nerves */}
           <path d="M0,-200 C30,-200 50,-195 70,-170 L80,-80 L85,0 L95,20" strokeWidth="1.5" />
           <path d="M70,-170 L60,-90" strokeWidth="0.8" opacity="0.5"/>
           <path d="M80,-80 L70,10" strokeWidth="0.8" opacity="0.5"/>

           {/* Legs (Left) - Nerves */}
           <path d="M0,120 C-15,130 -30,140 -30,170 L-35,240 L-45,310" strokeWidth="2" opacity="0.8" />
           <path d="M-30,170 L-20,230" strokeWidth="1" opacity="0.5"/>
           {/* Legs (Right) - Nerves */}
           <path d="M0,120 C15,130 30,140 30,170 L35,240 L45,310" strokeWidth="2" opacity="0.8" />
           <path d="M30,170 L20,230" strokeWidth="1" opacity="0.5"/>
           
           {/* Brain */}
           <path d="M-12,-260 C-20,-265 -5,-275 0,-260 C5,-275 20,-265 12,-260 C15,-250 0,-240 -12,-260" 
                 fill="#22d3ee" fillOpacity="0.3" stroke="none" filter="url(#glow-strong)" />
        </g>

        {/* --- Scanning Line Effect --- */}
        <line x1="100" y1="0" x2="300" y2="0" stroke="#4ade80" strokeWidth="2" strokeOpacity="0.5" className="animate-[scan-vertical_4s_linear_infinite]" style={{ filter: 'drop-shadow(0 0 5px #4ade80)' }} />

        {/* --- Callout Markers & Lines --- */}
        
        {/* Heart Warning (Red) */}
        <g>
           <circle cx="215" cy="190" r="15" fill="none" stroke="#ef4444" strokeWidth="2" className="animate-pulse" />
           <line x1="215" y1="190" x2="140" y2="190" stroke="#ef4444" strokeWidth="1" />
           <foreignObject x="0" y="160" width="140" height="60">
              <div className="bg-red-900/30 border-l-2 border-red-500 pl-2 pr-1 py-1 text-right backdrop-blur-sm">
                 <div className="text-red-400 font-bold text-sm">心动过速</div>
                 <div className="text-white text-xs">心率 111次/分</div>
              </div>
           </foreignObject>
        </g>

        {/* Sleep Apnea (Green) - Head */}
        <g>
           <circle cx="200" cy="90" r="3" fill="#4ade80" />
           <line x1="200" y1="90" x2="260" y2="90" stroke="#4ade80" strokeWidth="1" />
           <foreignObject x="260" y="60" width="140" height="80">
              <div className="bg-emerald-900/30 border-l-2 border-emerald-400 pl-2 py-1 backdrop-blur-sm">
                 <div className="text-emerald-400 font-bold text-sm">睡眠呼吸暂停</div>
                 <div className="text-white text-xs mt-0.5">睡眠时长 7h 48m</div>
                 <div className="text-slate-400 text-[10px]">05-27 23:44 ~ 07:33</div>
              </div>
           </foreignObject>
        </g>
        
        {/* Blood Pressure (Green) - Arm */}
        <g>
           <circle cx="280" cy="280" r="3" fill="#4ade80" />
           <line x1="280" y1="280" x2="290" y2="280" stroke="#4ade80" strokeWidth="1" />
           <foreignObject x="290" y="255" width="110" height="50">
              <div className="bg-emerald-900/30 border-l-2 border-emerald-400 pl-2 py-1 backdrop-blur-sm">
                 <div className="text-emerald-400 font-bold text-sm">血压正常</div>
                 <div className="text-white text-xs">114/81mmHg</div>
              </div>
           </foreignObject>
        </g>

        {/* SpO2 (Green) - Left Hand */}
        <g>
           <circle cx="110" cy="360" r="3" fill="#4ade80" />
           <line x1="110" y1="360" x2="100" y2="360" stroke="#4ade80" strokeWidth="1" />
           <line x1="100" y1="360" x2="140" y2="330" stroke="#4ade80" strokeWidth="1" opacity="0.5"/> {/* Angled Connector */}
           
           <foreignObject x="0" y="330" width="110" height="60">
              <div className="bg-emerald-900/30 border-l-2 border-emerald-400 pl-2 py-1 text-right backdrop-blur-sm">
                 <div className="text-emerald-400 font-bold text-sm">血氧良好</div>
                 <div className="text-white text-xs">饱和度 99%</div>
              </div>
           </foreignObject>
        </g>

        {/* Glucose (Green) - Leg */}
        <g>
           <circle cx="230" cy="500" r="3" fill="#4ade80" />
           <line x1="230" y1="500" x2="270" y2="500" stroke="#4ade80" strokeWidth="1" />
           <foreignObject x="270" y="475" width="120" height="50">
              <div className="bg-emerald-900/30 border-l-2 border-emerald-400 pl-2 py-1 backdrop-blur-sm">
                 <div className="text-emerald-400 font-bold text-sm">血糖正常</div>
                 <div className="text-white text-xs">餐后 5.5mmol/L</div>
              </div>
           </foreignObject>
        </g>

      </svg>
    </div>
  );
};


// --- Main Component ---
export const UserHealthPortrait: React.FC = () => {
  return (
    <>
      <style>{styles}</style>
      <div className="flex flex-col h-full bg-[#081319] text-slate-100 font-sans overflow-hidden relative selection:bg-cyan-500/30">
        
        {/* --- Header --- */}
        <header className="h-14 flex items-center justify-between px-6 bg-[#0f172a]/80 backdrop-blur-md border-b border-cyan-500/20 shrink-0 z-20 relative shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
           <div className="flex items-center gap-8">
              <div className="flex items-center gap-3">
                 <div className="p-1.5 bg-cyan-500/10 rounded border border-cyan-500/50 shadow-[0_0_10px_rgba(34,211,238,0.3)]">
                    <Layers size={20} className="text-cyan-400" />
                 </div>
                 <h1 className="text-2xl font-bold tracking-tight text-white holo-text">健康数字可视化</h1>
              </div>
              
              {/* Tab Shape */}
              <div className="relative h-full flex items-center">
                 <div className="absolute inset-0 bg-cyan-950/50 transform -skew-x-12 border-t-2 border-cyan-400"></div>
                 <span className="relative z-10 px-8 font-medium text-cyan-50 text-sm">健康画像</span>
              </div>
           </div>
           
           <div className="text-cyan-100/70 font-mono text-sm tracking-wide flex items-center gap-4">
              <span className="flex items-center gap-2"><span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> 实时监控中</span>
              <span>2025/12/16 11:30 星期二</span>
           </div>
        </header>

        {/* --- Content --- */}
        <main className="flex-1 p-5 grid grid-cols-12 gap-5 relative z-10 overflow-hidden">
           
           {/* Background Grid */}
           <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none z-0"></div>
           <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#081319]/50 to-[#081319] z-0 pointer-events-none"></div>

           {/* === LEFT COLUMN (20%) === */}
           <div className="col-span-3 flex flex-col gap-4 z-10 animate-[float_6s_ease-in-out_infinite]">
              
              {/* Basic Info */}
              <div className="bg-[#0f172a]/60 backdrop-blur border border-cyan-500/20 p-4 rounded shadow-lg">
                 <div className="panel-title-deco">基本信息</div>
                 
                 <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-full border-2 border-cyan-400 p-0.5 relative shadow-[0_0_15px_rgba(34,211,238,0.4)]">
                       <div className="w-full h-full rounded-full bg-slate-800 overflow-hidden">
                          <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="avatar" className="w-full h-full object-cover opacity-90" />
                       </div>
                       <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-[#0f172a] rounded-full"></div>
                    </div>
                    <div>
                       <div className="flex items-center text-white font-bold text-lg">
                          姓名：*** <Eye size={14} className="ml-2 text-cyan-500 cursor-pointer hover:text-cyan-300"/>
                       </div>
                       <div className="text-xs text-slate-400 mt-1">ID: 8839201</div>
                    </div>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-y-3 text-xs text-slate-300">
                    <div className="col-span-2">注册地点：浙江省杭州市</div>
                    <div className="col-span-2 text-cyan-200">设备：腕式专业健康预警管家</div>
                    <div>性别：女</div>
                    <div>年龄：37岁</div>
                    <div>体重：50kg</div>
                    <div>身高：165cm</div>
                 </div>
              </div>

              {/* Stats Panel */}
              <div className="bg-[#0f172a]/60 backdrop-blur border border-cyan-500/20 p-4 rounded shadow-lg flex-1">
                 <div className="panel-title-deco">监测情况</div>
                 <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="flex flex-col items-center bg-cyan-950/30 p-2 rounded border border-cyan-500/10">
                        <div className="text-cyan-400 font-bold text-2xl">60<span className="text-xs text-slate-400 ml-1">天</span></div>
                        <div className="text-[10px] text-slate-500">监测时长</div>
                    </div>
                    <div className="flex flex-col items-center bg-red-950/20 p-2 rounded border border-red-500/10">
                        <div className="text-red-400 font-bold text-2xl">18<span className="text-xs text-slate-400 ml-1">次</span></div>
                        <div className="text-[10px] text-slate-500">健康预警</div>
                    </div>
                 </div>

                 <div className="panel-title-deco">控制目标</div>
                 <div className="space-y-3">
                    <div className="bg-[#1e293b]/50 p-3 rounded border-l-2 border-green-500">
                       <div className="text-xs text-slate-400 mb-1">血压目标</div>
                       <div className="text-green-400 font-mono text-lg font-bold">110/80 <span className="text-xs">mmHg</span></div>
                    </div>
                    <div className="bg-[#1e293b]/50 p-3 rounded border-l-2 border-slate-500">
                       <div className="text-xs text-slate-400 mb-1">体重目标</div>
                       <div className="text-slate-200 font-mono text-lg font-bold">-- <span className="text-xs">kg</span></div>
                    </div>
                 </div>
              </div>
           </div>

           {/* === CENTER COLUMN (55%) === */}
           <div className="col-span-6 relative z-10 flex flex-col items-center justify-center">
               <MeridianMan />
           </div>

           {/* === RIGHT COLUMN (25%) === */}
           <div className="col-span-3 flex flex-col gap-3 z-10 bg-[#0f172a]/40 backdrop-blur border-l border-cyan-500/20 p-4">
              <div className="panel-title-deco">►► 健康监测趋势</div>

              {/* Chart 1: ECG */}
              <div className="flex-1 border-b border-slate-800 pb-2 flex flex-col">
                 <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-cyan-400 font-bold border-l-2 border-cyan-500 pl-2">心电图 (ECG)</span>
                    <span className="text-slate-500 font-mono">16:36:42</span>
                 </div>
                 <div className="flex items-end gap-2 mb-1">
                     <span className="text-2xl font-bold text-red-400 font-mono">71</span>
                     <span className="text-xs text-slate-400 mb-1">BPM (窦性)</span>
                 </div>
                 <div className="flex-1 bg-black/40 border border-slate-800 rounded relative overflow-hidden">
                    <div className="absolute inset-0 bg-[linear-gradient(transparent_19px,#1e293b_20px),linear-gradient(90deg,transparent_19px,#1e293b_20px)] bg-[size:20px_20px] opacity-20"></div>
                    <ResponsiveContainer width="100%" height="100%">
                       <LineChart data={ecgData}>
                          <Line type="monotone" dataKey="value" stroke="#ef4444" strokeWidth={2} dot={false} isAnimationActive={false} />
                       </LineChart>
                    </ResponsiveContainer>
                 </div>
              </div>

              {/* Chart 2: HR */}
              <div className="flex-1 border-b border-slate-800 pb-2 flex flex-col">
                 <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-cyan-400 font-bold border-l-2 border-cyan-500 pl-2">心率监测</span>
                    <span className="text-slate-500">2025-05-29</span>
                 </div>
                 <div className="flex items-end gap-2 mb-1">
                     <span className="text-2xl font-bold text-red-500 font-mono">112</span>
                     <span className="text-xs text-red-400/70 mb-1">Max BPM (High)</span>
                 </div>
                 <div className="flex-1 bg-black/40 border border-slate-800 rounded">
                    <ResponsiveContainer width="100%" height="100%">
                       <LineChart data={hrData}>
                          <CartesianGrid stroke="#334155" strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="time" hide />
                          <Line type="step" dataKey="value" stroke="#22d3ee" strokeWidth={2} dot={false} />
                       </LineChart>
                    </ResponsiveContainer>
                 </div>
              </div>

              {/* Chart 3: SpO2 */}
              <div className="flex-1 flex flex-col">
                 <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-cyan-400 font-bold border-l-2 border-cyan-500 pl-2">血氧监测</span>
                    <span className="text-slate-500">2025-05-29</span>
                 </div>
                 <div className="flex items-end gap-2 mb-1">
                     <span className="text-2xl font-bold text-green-400 font-mono">99</span>
                     <span className="text-xs text-slate-400 mb-1">%</span>
                 </div>
                 <div className="flex-1 bg-black/40 border border-slate-800 rounded">
                    <ResponsiveContainer width="100%" height="100%">
                       <LineChart data={spo2Data}>
                          <CartesianGrid stroke="#334155" strokeDasharray="3 3" vertical={false} />
                          <Line type="monotone" dataKey="value" stroke="#4ade80" strokeWidth={2} dot={false} />
                       </LineChart>
                    </ResponsiveContainer>
                 </div>
              </div>

           </div>
        </main>
      </div>
    </>
  );
};