import React from 'react';
import { Search, RotateCcw, Eye, Edit } from 'lucide-react';
import { User } from '../types';

// Enhanced Mock Data to match screenshots
const MOCK_USERS_EXTENDED: User[] = [
  {
    id: '1', sortId: 999999, name: '用户620990', nickname: '用户620990', gender: '女', age: 65, 
    phone: '186****3007', device: '864688050198...', riskLevel: '低', riskTags: ['血糖正常'], 
    source: '浙江好络维医疗...', registerTime: '2025-12-13 13:29', lastLogin: '--', status: '正常'
  },
  {
    id: '2', sortId: 999999, name: '用户066610', nickname: '用户066610', gender: '男', age: 72, 
    phone: '139****5258', device: 'HLW-5100Y-C-...', riskLevel: '高', riskTags: ['高血脂中危', '肥胖'], 
    source: '浙江好络维医疗...', registerTime: '2025-12-05 16:48', lastLogin: '--', status: '正常'
  },
  {
    id: '3', sortId: 999999, name: '用户386183', nickname: '用户386183', gender: '男', age: 58, 
    phone: '173****9319', device: '864688050206...', riskLevel: '无', riskTags: [], 
    source: '浙江好络维医疗...', registerTime: '2025-12-04 07:47', lastLogin: '--', status: '正常'
  },
  {
    id: '4', sortId: 999999, name: '用户111015', nickname: '用户111015', gender: '男', age: 45, 
    phone: '133****7038', device: 'HLW-5100Y-C-...', riskLevel: '无', riskTags: [], 
    source: '浙江好络维医疗...', registerTime: '2025-12-03 10:13', lastLogin: '--', status: '正常'
  },
  {
    id: '5', sortId: 999999, name: 'Elaina', nickname: 'Elaina', gender: '女', age: 32, 
    phone: '186****1599', device: '864688050168...', riskLevel: '低', riskTags: ['体重正常'], 
    source: '浙江好络维医疗...', registerTime: '2025-12-01 17:07', lastLogin: '--', status: '正常'
  },
];

interface UserListProps {
  onViewUser?: (user: User) => void;
}

const UserList: React.FC<UserListProps> = ({ onViewUser }) => {
  return (
    <div className="p-6 h-full flex flex-col bg-slate-50">
      {/* Search Filter Area */}
      <div className="bg-white p-5 rounded-lg shadow-sm mb-4 border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="flex flex-col space-y-1">
            <label className="text-sm font-medium text-slate-600">注册时间</label>
            <div className="flex items-center space-x-2">
              <input 
                type="text"
                placeholder="开始日期" 
                className="flex-1 border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500 transition" 
                onFocus={(e) => e.target.type = 'date'}
                onBlur={(e) => e.target.type = 'text'}
              />
              <span className="text-slate-400">-</span>
              <input 
                type="text"
                placeholder="结束日期"
                className="flex-1 border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500 transition" 
                onFocus={(e) => e.target.type = 'date'}
                onBlur={(e) => e.target.type = 'text'}
              />
            </div>
          </div>
          
          <div className="flex flex-col space-y-1">
             <label className="text-sm font-medium text-slate-600">用户名</label>
             <input 
              type="text" 
              placeholder="请输入用户名" 
              className="border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500 transition w-full"
            />
          </div>

          <div className="flex flex-col space-y-1">
             <label className="text-sm font-medium text-slate-600">手机号码</label>
             <input 
              type="text" 
              placeholder="请输入手机号码" 
              className="border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500 transition w-full"
            />
          </div>

          <div className="flex flex-col space-y-1">
             <label className="text-sm font-medium text-slate-600">MAC/IMEI</label>
             <input 
              type="text" 
              placeholder="请输入设备MAC/IMEI号" 
              className="border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500 transition w-full"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-4 mt-4">
          <div className="flex flex-col space-y-1 w-64">
              <label className="text-sm font-medium text-slate-600">排序方式</label>
              <select className="border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-blue-500 transition w-full bg-white">
                <option>创建时间</option>
                <option>最近登录</option>
                <option>风险等级</option>
              </select>
          </div>
          <div className="flex items-end flex-1 space-x-2 pb-0.5">
              <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded text-sm flex items-center transition">
                <Search className="w-4 h-4 mr-1" /> 搜索
              </button>
              <button className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-600 px-4 py-2 rounded text-sm flex items-center transition">
                <RotateCcw className="w-4 h-4 mr-1" /> 重置
              </button>
          </div>
        </div>
      </div>

      {/* Table Area */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-100 flex-1 flex flex-col">
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="p-4 font-semibold text-slate-600 text-sm w-16">序号</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">排序编号</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">姓名</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">昵称</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">性别</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">年龄</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">手机号</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">绑定设备</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">风险分级</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">用户来源</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">注册时间</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">最近登录时间</th>
                <th className="p-4 font-semibold text-slate-600 text-sm">状态</th>
                <th className="p-4 font-semibold text-slate-600 text-sm text-center">操作</th>
              </tr>
            </thead>
            <tbody>
              {MOCK_USERS_EXTENDED.map((user, index) => (
                <tr key={user.id} className="border-b border-slate-100 hover:bg-slate-50 transition">
                  <td className="p-4 text-slate-600 text-sm">{index + 1}</td>
                  <td className="p-4 text-slate-600 text-sm">{user.sortId}</td>
                  <td className="p-4 text-slate-800 text-sm font-medium">{user.name}</td>
                  <td className="p-4 text-slate-500 text-sm">{user.nickname}</td>
                  <td className="p-4 text-slate-600 text-sm">{user.gender}</td>
                  <td className="p-4 text-slate-600 text-sm">{user.age || '--'}</td>
                  <td className="p-4 text-slate-600 text-sm">{user.phone}</td>
                  <td className="p-4 text-slate-600 text-sm max-w-[150px] truncate" title={user.device}>
                    {user.device || '--'}
                  </td>
                  <td className="p-4 text-sm">
                    <div className="flex flex-wrap gap-1">
                      {user.riskTags && user.riskTags.length > 0 ? (
                        user.riskTags.map((tag, i) => (
                          <span key={i} className={`px-2 py-0.5 rounded text-xs ${
                            tag.includes('高') || tag.includes('肥胖') ? 'bg-red-100 text-red-600' :
                            tag.includes('中') ? 'bg-orange-100 text-orange-600' :
                            'bg-green-100 text-green-600'
                          }`}>
                            {tag}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-300 text-xs">--</span>
                      )}
                    </div>
                  </td>
                  <td className="p-4 text-slate-600 text-sm max-w-[120px] truncate">{user.source}</td>
                  <td className="p-4 text-slate-500 text-sm">{user.registerTime}</td>
                  <td className="p-4 text-slate-500 text-sm">{user.lastLogin}</td>
                  <td className="p-4 text-sm">
                     {/* Toggle Switch */}
                     <div className={`w-10 h-5 rounded-full relative cursor-pointer transition-colors ${user.status === '正常' ? 'bg-blue-500' : 'bg-slate-300'}`}>
                        <div className={`w-4 h-4 bg-white rounded-full absolute top-0.5 transition-transform ${user.status === '正常' ? 'left-[22px]' : 'left-0.5'}`}></div>
                     </div>
                  </td>
                  <td className="p-4 text-center">
                    <div className="flex items-center justify-center space-x-3">
                       <button 
                          className="text-blue-500 hover:text-blue-700 flex items-center text-xs"
                          onClick={() => onViewUser && onViewUser(user)}
                        >
                         <Eye className="w-3 h-3 mr-1" /> 详情
                       </button>
                       <button className="text-blue-500 hover:text-blue-700 flex items-center text-xs">
                         <Edit className="w-3 h-3 mr-1" /> 更新编号
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="p-4 border-t border-slate-200 flex items-center justify-end space-x-4 bg-white rounded-b-lg">
           <div className="text-sm text-slate-500">
             共 85 条
           </div>
           <select className="border border-slate-300 rounded px-2 py-1 text-sm bg-white focus:outline-none">
             <option>10条/页</option>
             <option>20条/页</option>
             <option>50条/页</option>
           </select>
           <div className="flex space-x-1">
             <button className="px-2 py-1 border border-slate-200 rounded text-slate-400 hover:bg-slate-50 disabled:opacity-50 text-sm">&lt;</button>
             <button className="px-3 py-1 bg-blue-500 text-white rounded text-sm">1</button>
             <button className="px-3 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">2</button>
             <button className="px-3 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">3</button>
             <button className="px-3 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">4</button>
             <button className="px-3 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">5</button>
             <button className="px-2 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">...</button>
             <button className="px-3 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">9</button>
             <button className="px-2 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">&gt;</button>
           </div>
           <div className="flex items-center space-x-2 text-sm text-slate-500">
             <span>前往</span>
             <input type="text" className="w-10 border border-slate-300 rounded px-1 py-0.5 text-center focus:outline-none" defaultValue="1" />
             <span>页</span>
           </div>
        </div>
      </div>
    </div>
  );
};

export default UserList;