import React from 'react';
import { AreaChart, Area, ResponsiveContainer, LineChart, Line } from 'recharts';
import { ExternalLink, Smartphone } from 'lucide-react';

const Card: React.FC<{ 
  title: string; 
  value: string | number; 
  unit?: string; 
  date: string; 
  chartColor: string;
  data: any[];
  bgColor?: string;
}> = ({ title, value, unit, date, chartColor, data, bgColor = "bg-white" }) => (
  <div className={`${bgColor} rounded-xl p-5 shadow-sm border border-slate-100 flex flex-col justify-between h-48 relative overflow-hidden group hover:shadow-md transition`}>
    <div className="flex justify-between items-start z-10">
      <div>
        <h4 className="text-slate-600 font-medium text-sm">{title}</h4>
        <div className="mt-2 flex items-baseline">
          <span className="text-3xl font-bold text-slate-800">{value}</span>
          {unit && <span className="text-sm text-slate-500 ml-1">{unit}</span>}
        </div>
      </div>
      <span className="text-xs text-slate-400">{date}</span>
    </div>
    
    <div className="absolute bottom-0 left-0 right-0 h-24 z-0 opacity-50">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id={`color${title}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={chartColor} stopOpacity={0.3}/>
              <stop offset="95%" stopColor={chartColor} stopOpacity={0}/>
            </linearGradient>
          </defs>
          <Area type="monotone" dataKey="value" stroke={chartColor} fillOpacity={1} fill={`url(#color${title})`} strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  </div>
);

// Specific card for Sleep (Range bar)
const SleepCard: React.FC = () => (
  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 flex flex-col justify-between h-48 hover:shadow-md transition">
    <div className="flex justify-between items-start">
      <div>
        <h4 className="text-slate-600 font-medium text-sm">睡眠</h4>
        <div className="mt-2 flex items-baseline">
          <span className="text-3xl font-bold text-slate-800">3</span>
          <span className="text-sm text-slate-500 ml-1">小时</span>
          <span className="text-3xl font-bold text-slate-800 ml-2">0</span>
          <span className="text-sm text-slate-500 ml-1">分钟</span>
        </div>
      </div>
      <span className="text-xs text-slate-400">12/07</span>
    </div>
    <div className="mt-4">
      <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden flex">
        <div className="h-full bg-purple-500 w-[70%]"></div>
        <div className="h-full bg-yellow-400 w-[30%]"></div>
      </div>
      <div className="flex justify-between mt-1 text-xs text-slate-400">
        <span>深睡</span>
        <span>浅睡</span>
      </div>
    </div>
  </div>
);

// Specific card for BP (Range bar)
const BPCard: React.FC = () => (
   <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 flex flex-col justify-between h-48 hover:shadow-md transition">
    <div className="flex justify-between items-start">
      <div>
        <h4 className="text-slate-600 font-medium text-sm">血压</h4>
        <div className="mt-2 flex items-baseline">
          <span className="text-3xl font-bold text-slate-800">126/90</span>
          <span className="text-sm text-slate-500 ml-1">mmHg</span>
        </div>
      </div>
      <span className="text-xs text-slate-400">12/10</span>
    </div>
    <div className="mt-4">
      <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden flex relative">
        <div className="h-full bg-blue-400 w-[20%]"></div>
        <div className="h-full bg-green-500 w-[20%]"></div>
        <div className="h-full bg-yellow-400 w-[20%]"></div>
        <div className="h-full bg-orange-500 w-[20%]"></div>
        <div className="h-full bg-red-500 w-[20%]"></div>
        {/* Pointer */}
        <div className="absolute top-0 bottom-0 w-0.5 bg-black left-[45%]"></div> 
        <div className="absolute -top-1 left-[43.5%] w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-t-[6px] border-t-black"></div>
      </div>
      <div className="flex justify-between mt-1 text-xs text-slate-400">
        <span>低</span>
        <span>正常</span>
        <span>偏高</span>
        <span>高</span>
      </div>
    </div>
  </div>
);


const mockChartData = [
  { value: 60 }, { value: 75 }, { value: 68 }, { value: 90 }, { value: 85 }, { value: 72 }, { value: 98 }
];

export const UserHealthMonitor: React.FC = () => {
  return (
    <div className="space-y-4">
      {/* Tool bar */}
      <div className="flex justify-between items-center bg-white p-3 rounded-lg border border-slate-100 mb-2">
         <h3 className="font-bold text-slate-700">健康监测数据</h3>
         <div className="flex items-center space-x-2 text-sm">
            <Smartphone className="w-4 h-4 text-purple-500" />
            <span className="text-slate-600">当前设备: 腕式专业健康预警管家</span>
            <button className="text-blue-500 bg-blue-50 px-2 py-0.5 rounded text-xs">切换</button>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card 
          title="心脏健康" 
          value={98} 
          unit="次/分" 
          date="12/16" 
          chartColor="#ef4444" 
          data={mockChartData} 
        />
        
        {/* Heart Rhythm - Custom Background */}
        <div className="bg-pink-50 rounded-xl p-5 shadow-sm border border-pink-100 flex flex-col justify-between h-48 relative overflow-hidden">
           <div>
             <h4 className="text-slate-700 font-medium text-sm">心律失常</h4>
             <p className="text-xs text-slate-500 mt-1">脉搏跳动节律分析</p>
           </div>
           <div className="absolute right-0 bottom-0 w-32 h-32 opacity-20 bg-red-500 rounded-full blur-2xl"></div>
           <div className="absolute right-4 bottom-4">
              {/* Icon placeholder */}
              <div className="w-12 h-12 bg-red-400/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                 <Activity className="text-red-500" />
              </div>
           </div>
           {/* Abstract waves */}
           <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-pink-200/50 to-transparent"></div>
        </div>

        <SleepCard />
        
        <Card 
          title="血氧饱和度" 
          value={97} 
          unit="%" 
          date="12/16" 
          chartColor="#22c55e" 
          data={[{value:95}, {value:96}, {value:97}, {value:97}, {value:96}, {value:98}, {value:97}]} 
        />
        
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 flex flex-col justify-between h-48">
            <div className="flex justify-between items-start">
               <div>
                  <h4 className="text-slate-600 font-medium text-sm">运动记录</h4>
                  <div className="mt-2 flex items-baseline">
                    <span className="text-3xl font-bold text-slate-800">754</span>
                    <span className="text-sm text-slate-500 ml-1">/6000步</span>
                  </div>
               </div>
               <span className="text-xs text-slate-400">12/16</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-4">
               <div className="bg-green-500 h-full w-[12%] rounded-full"></div>
            </div>
        </div>

        {/* Emotional Health */}
        <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-xl p-5 shadow-sm border border-cyan-100 h-48 relative overflow-hidden">
           <h4 className="text-slate-700 font-medium text-sm">情绪健康</h4>
           <p className="text-xs text-slate-500 mt-1">压力检测 减压放松</p>
           <div className="absolute -right-4 -bottom-4 w-32 h-32 rounded-full bg-cyan-200/50 blur-xl"></div>
           <div className="absolute right-8 bottom-8 w-16 h-16 rounded-full bg-blue-300/50 blur-lg"></div>
        </div>

        <BPCard />

        <div className="bg-[#effcf0] rounded-xl p-5 shadow-sm border border-green-100 h-48 relative overflow-hidden flex flex-col justify-between">
            <div>
               <h4 className="text-slate-700 font-medium text-sm">体温</h4>
               <p className="text-xs text-slate-500 mt-1">体温记录</p>
            </div>
            {/* Abstract thermometer visual */}
             <div className="absolute right-0 bottom-0 opacity-20">
                <svg width="120" height="120" viewBox="0 0 100 100">
                   <path d="M50 0 L100 50 L50 100 L0 50 Z" fill="#4ade80" />
                </svg>
             </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 h-48 flex flex-col justify-between">
            <h4 className="text-slate-600 font-medium text-sm">血糖</h4>
            <div className="grid grid-cols-2 gap-4">
               <div>
                  <p className="text-xs text-slate-400 mb-1">12/07 空腹</p>
                  <div className="flex items-baseline">
                     <span className="text-2xl font-bold text-slate-800">5.6</span>
                     <span className="text-xs text-slate-500 ml-1">mmol/L</span>
                  </div>
               </div>
               <div>
                   <p className="text-xs text-slate-400 mb-1">12/07 血酮</p>
                   <span className="text-xl font-bold text-slate-800">-</span>
                   <span className="text-xs text-slate-500 ml-1">mmol/L</span>
               </div>
               <div>
                   <p className="text-xs text-slate-400 mb-1">尿酸</p>
                   <div className="flex items-baseline">
                     <span className="text-2xl font-bold text-slate-800">600</span>
                     <span className="text-xs text-slate-500 ml-1">mmol/L</span>
                  </div>
               </div>
               <div>
                   <p className="text-xs text-slate-400 mb-1">12/07 糖化血红蛋白</p>
                   <span className="text-xl font-bold text-slate-800">-</span>
                   <span className="text-xs text-slate-500 ml-1">mmol/L</span>
               </div>
            </div>
        </div>
        
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 h-48 flex flex-col justify-between">
           <div className="flex justify-between items-start">
              <div>
                <h4 className="text-slate-600 font-medium text-sm">血脂</h4>
                <div className="mt-2 grid grid-cols-2 gap-x-8 gap-y-2">
                   <div>
                      <p className="text-xs text-slate-400">总胆固醇</p>
                      <span className="text-lg font-bold text-slate-800">5.7</span> <span className="text-xs">mmol/L</span>
                   </div>
                    <div>
                      <p className="text-xs text-slate-400">低密度脂蛋白</p>
                      <span className="text-lg font-bold text-slate-800">3</span> <span className="text-xs">mmol/L</span>
                   </div>
                    <div>
                      <p className="text-xs text-slate-400">高密度脂蛋白</p>
                      <span className="text-lg font-bold text-slate-800">1.2</span> <span className="text-xs">mmol/L</span>
                   </div>
                    <div>
                      <p className="text-xs text-slate-400">甘油三酯</p>
                      <span className="text-lg font-bold text-slate-800">0.6</span> <span className="text-xs">mmol/L</span>
                   </div>
                </div>
              </div>
              <span className="text-xs text-slate-400">12/07</span>
           </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 flex flex-col justify-between h-48">
            <div className="flex justify-between items-start">
               <div>
                  <h4 className="text-slate-600 font-medium text-sm">体重</h4>
                  <div className="mt-2 flex items-baseline">
                    <span className="text-3xl font-bold text-slate-800">98</span>
                    <span className="text-sm text-slate-500 ml-1">kg</span>
                  </div>
               </div>
               <span className="text-xs text-slate-400">12/05</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-4 flex">
               <div className="bg-blue-500 h-full w-[25%]"></div>
               <div className="bg-green-500 h-full w-[25%]"></div>
               <div className="bg-yellow-500 h-full w-[25%]"></div>
               <div className="bg-orange-500 h-full w-[25%]"></div>
               <div className="relative">
                  <div className="absolute -top-3 left-0 -ml-1 text-black text-xs">▼</div>
               </div>
            </div>
        </div>

        <div className="bg-pink-50 rounded-xl p-5 shadow-sm border border-pink-100 h-48 relative overflow-hidden">
           <h4 className="text-slate-700 font-medium text-sm">心电图</h4>
           <p className="text-xs text-slate-500 mt-1">单导联心电分析</p>
           {/* ECG Line visual */}
           <div className="absolute bottom-4 left-0 right-0 h-12 flex items-end opacity-50 px-4">
              <svg viewBox="0 0 300 50" className="w-full h-full stroke-red-500 fill-none" preserveAspectRatio="none">
                 <path d="M0 25 L20 25 L30 10 L40 40 L50 25 L80 25 L90 5 L100 45 L110 25 L150 25" strokeWidth="2" />
                 <path d="M150 25 L170 25 L180 10 L190 40 L200 25 L230 25 L240 5 L250 45 L260 25 L300 25" strokeWidth="2" />
              </svg>
           </div>
           <div className="absolute right-4 bottom-4 w-16 h-16 bg-red-400 rounded-full blur-xl opacity-20"></div>
        </div>

      </div>
    </div>
  );
};

// Import necessary icon
import { Activity } from 'lucide-react';