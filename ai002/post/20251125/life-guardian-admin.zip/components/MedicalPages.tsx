import React from 'react';
import { FileText, CheckCircle, Clock } from 'lucide-react';
import { DataTable, StatusBadge, Column } from './Shared';

const MedicalTable: React.FC<{ title: string }> = ({ title }) => {
  const data = [
    { id: 1, user: '张伟', gender: '男', age: 65, type: '24小时动态心电报告', time: '2023-10-24', status: '待解读' },
    { id: 2, user: '李秀英', gender: '女', age: 72, type: '睡眠质量监测报告', time: '2023-10-23', status: '已解读' },
    { id: 3, user: '王强', gender: '男', age: 58, type: '血压周期性评估', time: '2023-10-22', status: '已解读' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: '用户姓名', accessor: 'user' },
    { header: '性别', accessor: 'gender' },
    { header: '年龄', accessor: 'age' },
    { header: '报告类型', accessor: 'type', className: 'font-medium' },
    { header: '提交时间', accessor: 'time' },
    { header: '状态', accessor: (item) => <StatusBadge status={item.status} /> },
    { header: '操作', accessor: (item) => (
      item.status === '待解读' ? 
      <button className="bg-blue-500 text-white px-3 py-1 rounded text-xs hover:bg-blue-600">开始解读</button> :
      <button className="text-blue-500 hover:underline text-sm">查看报告</button>
    )},
  ];

  return <DataTable columns={columns} data={data} title={title} onSearch={() => {}} />;
};

export const MedicalReport = () => <MedicalTable title="医疗报告专家解读" />;
export const MedicalMonthly = () => <MedicalTable title="健康月报专家解读" />;