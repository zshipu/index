import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Users, AlertTriangle, Activity, Watch } from 'lucide-react';
import { StatCardProps } from '../types';

const dataGrowth = [
  { name: '周一', newUsers: 40, activeUsers: 240 },
  { name: '周二', newUsers: 30, activeUsers: 139 },
  { name: '周三', newUsers: 20, activeUsers: 980 },
  { name: '周四', newUsers: 27, activeUsers: 390 },
  { name: '周五', newUsers: 18, activeUsers: 480 },
  { name: '周六', newUsers: 23, activeUsers: 380 },
  { name: '周日', newUsers: 34, activeUsers: 430 },
];

const dataDevice = [
  { name: '智能手表', value: 400 },
  { name: '心电贴', value: 300 },
  { name: '血压计', value: 300 },
  { name: '血糖仪', value: 200 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, color, trend, trendUp }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-100 flex items-center justify-between">
    <div>
      <p className="text-slate-500 text-sm font-medium">{title}</p>
      <h3 className="text-2xl font-bold text-slate-800 mt-1">{value}</h3>
      {trend && (
        <p className={`text-xs mt-2 flex items-center ${trendUp ? 'text-green-500' : 'text-red-500'}`}>
          {trendUp ? '↑' : '↓'} {trend} 较上周
        </p>
      )}
    </div>
    <div className={`p-4 rounded-full ${color} bg-opacity-10`}>
      <Icon className={`w-6 h-6 ${color.replace('bg-', 'text-')}`} />
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6 animate-fade-in p-6">
      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="总用户数" 
          value="12,345" 
          trend="12%" 
          trendUp={true} 
          icon={Users} 
          color="text-blue-500 bg-blue-500" 
        />
        <StatCard 
          title="在线设备" 
          value="8,234" 
          trend="5%" 
          trendUp={true} 
          icon={Watch} 
          color="text-green-500 bg-green-500" 
        />
        <StatCard 
          title="今日警报" 
          value="45" 
          trend="2%" 
          trendUp={false} 
          icon={AlertTriangle} 
          color="text-red-500 bg-red-500" 
        />
        <StatCard 
          title="专家解读待办" 
          value="18" 
          icon={Activity} 
          color="text-purple-500 bg-purple-500" 
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">用户增长趋势</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dataGrowth}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #f0f0f0' }}
                />
                <Legend />
                <Line type="monotone" dataKey="newUsers" name="新增用户" stroke="#1890ff" strokeWidth={2} />
                <Line type="monotone" dataKey="activeUsers" name="活跃用户" stroke="#82ca9d" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Device Distribution */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">智能设备分布</h3>
          <div className="h-80 flex items-center justify-center">
             <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={dataDevice}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  label
                >
                  {dataDevice.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
       <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">健康警报类型排名</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { name: '心率过高', count: 120 },
                  { name: '血压异常', count: 98 },
                  { name: '血氧过低', count: 86 },
                  { name: '跌倒检测', count: 45 },
                  { name: '久坐提醒', count: 30 },
                ]}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" />
                <XAxis type="number" stroke="#94a3b8"/>
                <YAxis dataKey="name" type="category" width={100} stroke="#64748b" />
                <Tooltip cursor={{fill: '#f8fafc'}} />
                <Bar dataKey="count" fill="#1890ff" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
    </div>
  );
};

export default Dashboard;