import React from 'react';
import { Edit, Trash2, Shield, MoreHorizontal } from 'lucide-react';
import { DataTable, StatusBadge, StandardActions, Column } from './Shared';

// --- Admin Management ---
export const SystemAdmin: React.FC = () => {
  const data = [
    { id: 1, name: '管理员01', account: 'admin01', phone: '13800138000', role: '超级管理员', dept: '技术部', status: '启用', created: '2023-01-01' },
    { id: 2, name: '张医生', account: 'doc_zhang', phone: '13900139000', role: '医生', dept: '医疗部', status: '启用', created: '2023-02-15' },
    { id: 3, name: '李客服', account: 'cs_li', phone: '13700137000', role: '客服专员', dept: '客服部', status: '停用', created: '2023-03-10' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: 'ID', accessor: 'id', className: 'w-16' },
    { header: '姓名', accessor: 'name' },
    { header: '账号', accessor: 'account' },
    { header: '手机号', accessor: 'phone' },
    { header: '角色', accessor: (item) => <span className="flex items-center"><Shield className="w-3 h-3 mr-1 text-blue-500"/>{item.role}</span> },
    { header: '部门', accessor: 'dept' },
    { header: '状态', accessor: (item) => <StatusBadge status={item.status} /> },
    { header: '创建时间', accessor: 'created' },
    { header: '操作', accessor: () => (
      <div className="flex space-x-2">
        <button className="text-blue-500 hover:text-blue-700"><Edit size={16} /></button>
        <button className="text-red-500 hover:text-red-700"><Trash2 size={16} /></button>
      </div>
    )}
  ];

  return <DataTable columns={columns} data={data} title="管理员管理" actions={<StandardActions />} onSearch={() => {}} />;
};

// --- Role Management ---
export const SystemRole: React.FC = () => {
  const data = [
    { id: 1, name: '超级管理员', desc: '拥有系统所有权限', count: 3, created: '2023-01-01' },
    { id: 2, name: '医生', desc: '查看用户健康数据、报告解读', count: 12, created: '2023-01-05' },
    { id: 3, name: '客服专员', desc: '用户沟通、问题反馈处理', count: 8, created: '2023-01-05' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: 'ID', accessor: 'id', className: 'w-16' },
    { header: '角色名称', accessor: 'name', className: 'font-medium' },
    { header: '描述', accessor: 'desc', className: 'text-slate-500' },
    { header: '用户数', accessor: 'count' },
    { header: '创建时间', accessor: 'created' },
    { header: '操作', accessor: () => (
      <div className="flex space-x-2">
        <button className="text-blue-500 hover:text-blue-700 text-sm">权限配置</button>
        <button className="text-slate-500 hover:text-slate-700"><Edit size={16} /></button>
        <button className="text-red-500 hover:text-red-700"><Trash2 size={16} /></button>
      </div>
    )}
  ];

  return <DataTable columns={columns} data={data} title="角色管理" actions={<StandardActions />} />;
};

// --- Dept Management ---
export const SystemDept: React.FC = () => {
  const data = [
    { id: 1, name: '总经办', parent: '-', manager: '王总', phone: '010-88888888', sort: 1 },
    { id: 2, name: '技术部', parent: '总经办', manager: '张CTO', phone: '010-88888881', sort: 2 },
    { id: 3, name: '医疗服务部', parent: '总经办', manager: '李主任', phone: '010-88888882', sort: 3 },
    { id: 4, name: '客户服务部', parent: '总经办', manager: '赵经理', phone: '010-88888883', sort: 4 },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: 'ID', accessor: 'id', className: 'w-16' },
    { header: '部门名称', accessor: 'name', className: 'font-medium' },
    { header: '上级部门', accessor: 'parent' },
    { header: '负责人', accessor: 'manager' },
    { header: '联系电话', accessor: 'phone' },
    { header: '排序', accessor: 'sort' },
    { header: '操作', accessor: () => (
      <div className="flex space-x-2">
        <button className="text-blue-500 hover:text-blue-700"><Edit size={16} /></button>
        <button className="text-red-500 hover:text-red-700"><Trash2 size={16} /></button>
      </div>
    )}
  ];

  return <DataTable columns={columns} data={data} title="部门管理" actions={<StandardActions />} />;
};