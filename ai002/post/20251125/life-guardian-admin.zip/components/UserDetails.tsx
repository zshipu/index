import React, { useState } from 'react';
import { User } from '../types';
import { 
  User as UserIcon, MessageSquare, MoreHorizontal, ExternalLink, 
  ChevronDown, LayoutGrid, AlertTriangle, FileText, Activity, 
  Clipboard, History
} from 'lucide-react';
import { UserHealthMonitor } from './UserHealthMonitor';
import { UserAlertInfo } from './UserAlertInfo';
import { UserHealthPortrait } from './UserHealthPortrait';

interface UserDetailsProps {
  user?: User; // Although we might fetch by ID in real app
}

export const UserDetails: React.FC<UserDetailsProps> = ({ user }) => {
  const [activeSubTab, setActiveSubTab] = useState('monitor');

  // Fallback if no user passed
  const displayUser = user || {
    id: '2', name: '用户066610', nickname: '用户066610', gender: '男', age: 72, 
    phone: '13905435258', device: '动态心电记录仪(24小时) ;血糖尿酸血脂仪', riskLevel: '高',
    doctor: '-', dept: '【厂商】好络维', lastLogin: '--'
  };

  const renderContent = () => {
    switch (activeSubTab) {
      case 'monitor': return <UserHealthMonitor />;
      case 'alert': return <UserAlertInfo />;
      case 'portrait': return <UserHealthPortrait />;
      default: return <div className="p-8 text-center text-slate-400">模块开发中</div>;
    }
  };

  // If portrait mode, we want full screen dark mode look, removing standard padding potentially
  if (activeSubTab === 'portrait') {
    return (
      <div className="flex flex-col h-full">
         {/* Simple Back Nav for Portrait Mode */}
         <div className="bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between shrink-0">
             <div className="flex items-center space-x-2 text-sm">
                 <span className="text-slate-500">首页</span>
                 <span className="text-slate-300">/</span>
                 <span className="text-slate-500">用户管理</span>
                 <span className="text-slate-300">/</span>
                 <span className="text-blue-500 font-medium">健康画像</span>
             </div>
             <button onClick={() => setActiveSubTab('monitor')} className="text-sm text-blue-500 hover:underline">返回详情页</button>
         </div>
         <div className="flex-1 overflow-hidden">
             <UserHealthPortrait />
         </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      {/* Header Info Card */}
      <div className="bg-white p-6 m-4 mb-0 rounded-lg shadow-sm border border-slate-100 shrink-0">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-slate-400">
               <UserIcon size={32} />
            </div>
            <div>
               <div className="flex items-center space-x-2">
                 <h2 className="text-lg font-bold text-slate-800">{displayUser.name}</h2>
                 <span className="text-sm text-slate-600">{displayUser.gender}</span>
                 <span className="text-sm text-slate-600">{displayUser.age ? displayUser.age + '岁' : '--岁'}</span>
                 <span className="text-sm text-slate-400 ml-2">手机: {displayUser.phone}</span>
                 <span className="text-sm text-slate-400 ml-2">邮箱: --</span>
               </div>
               <div className="mt-2 text-sm text-slate-500 flex flex-wrap gap-x-6 gap-y-1">
                 <span>绑定设备: <span className="text-slate-700">{displayUser.device}</span> <ChevronDown size={14} className="inline cursor-pointer"/></span>
                 <span>绑定医生: {displayUser.doctor}</span>
               </div>
               <div className="mt-1 text-sm text-slate-500 flex flex-wrap gap-x-6 gap-y-1">
                 <span>所属部门: {displayUser.department || displayUser.dept}</span>
                 <span>最近登录时间: {displayUser.lastLogin}</span>
               </div>
               <div className="mt-1 text-sm text-slate-500">
                 用户标签: 
               </div>
            </div>
          </div>
          <div className="flex space-x-2">
             <button className="p-2 bg-slate-100 rounded-full text-slate-600 hover:bg-slate-200"><UserIcon size={16} /></button>
             <button className="p-2 bg-slate-100 rounded-full text-slate-600 hover:bg-slate-200"><MessageSquare size={16} /></button>
             <button className="p-2 bg-slate-100 rounded-full text-slate-600 hover:bg-slate-200"><MoreHorizontal size={16} /></button>
          </div>
        </div>
        
        <div className="mt-6 flex items-center">
           <span className="text-sm font-bold text-slate-700 mr-2">风险分级:</span>
           <div className="flex flex-wrap gap-2">
              <span className="px-2 py-0.5 bg-white border border-slate-200 rounded text-xs text-slate-600">心律正常</span>
              <span className="px-2 py-0.5 bg-white border border-slate-200 rounded text-xs text-slate-600">血氧饱和度正常</span>
              <span className="px-2 py-0.5 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-700">尿酸偏高</span>
              <span className="px-2 py-0.5 bg-red-50 border border-red-200 rounded text-xs text-red-600">高血脂中危</span>
              <span className="px-2 py-0.5 bg-red-50 border border-red-200 rounded text-xs text-red-600">肥胖</span>
              <span className="px-2 py-0.5 bg-white border border-slate-200 rounded text-xs text-slate-600">血糖正常</span>
              <span className="px-2 py-0.5 bg-white border border-slate-200 rounded text-xs text-slate-600">舒症正常</span>
           </div>
           <div className="ml-auto flex items-center text-sm text-slate-400 cursor-pointer hover:text-blue-500">
              展开 <ChevronDown size={14} className="ml-1" />
           </div>
        </div>
      </div>

      {/* Content Area with Sidebar */}
      <div className="flex flex-1 overflow-hidden m-4 mt-4 gap-4">
        {/* Sidebar Navigation */}
        <div className="w-48 bg-white rounded-lg shadow-sm border border-slate-100 flex flex-col shrink-0 overflow-y-auto">
           <div className="p-4 flex justify-between items-center border-b border-slate-100">
              <span className="font-bold text-slate-800">健康中心</span>
              <ExternalLink size={14} className="text-slate-400" />
           </div>
           <nav className="flex-1 py-2">
              {[
                { id: 'monitor', label: '健康监测数据', active: true },
                { id: 'alert', label: '警报信息' },
                { id: 'tags', label: '用户标签' },
                { id: 'portrait', label: '用户画像' },
                { id: 'archive', label: '健康档案' },
                { id: 'periodic', label: '周期报告' },
                { id: 'custom', label: '定制报告' },
                { id: 'ai', label: 'AI报告识别' },
                { id: 'footprint', label: '足迹' },
                { id: 'survey', label: '量表问卷' },
                { id: 'history', label: '病历历程' },
              ].map(item => (
                <div 
                  key={item.id}
                  onClick={() => setActiveSubTab(item.id)}
                  className={`px-4 py-3 text-sm cursor-pointer border-l-2 transition-colors flex items-center
                    ${activeSubTab === item.id ? 'border-blue-500 text-blue-500 bg-blue-50' : 'border-transparent text-slate-600 hover:bg-slate-50'}
                  `}
                >
                  {item.label}
                </div>
              ))}
           </nav>
        </div>

        {/* Dynamic Content */}
        <div className="flex-1 bg-white rounded-lg shadow-sm border border-slate-100 overflow-y-auto p-6 relative">
             {activeSubTab === 'monitor' && (
                 <div className="absolute top-6 right-6 z-10">
                     <button onClick={() => setActiveSubTab('portrait')} className="bg-blue-600 text-white px-3 py-1.5 rounded text-xs shadow-md hover:bg-blue-700 transition">
                        查看健康画像(3D)
                     </button>
                 </div>
             )}
            {renderContent()}
        </div>
      </div>
    </div>
  );
};