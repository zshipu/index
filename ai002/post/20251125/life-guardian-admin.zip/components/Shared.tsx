import React from 'react';
import { Search, RotateCcw, Plus, Download, Upload, Filter, ChevronLeft, ChevronRight } from 'lucide-react';

export interface Column<T> {
  header: string;
  accessor: keyof T | ((item: T) => React.ReactNode);
  className?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  title?: string;
  actions?: React.ReactNode;
  onSearch?: (term: string) => void;
  loading?: boolean;
}

export const StatusBadge: React.FC<{ status: string; type?: 'success' | 'warning' | 'error' | 'neutral' }> = ({ status, type = 'neutral' }) => {
  const styles = {
    success: 'bg-green-100 text-green-600',
    warning: 'bg-orange-100 text-orange-600',
    error: 'bg-red-100 text-red-600',
    neutral: 'bg-slate-100 text-slate-600',
    blue: 'bg-blue-100 text-blue-600'
  };
  
  // Auto-detect if type not provided based on common keywords
  let finalType = type;
  if (type === 'neutral') {
    if (['正常', '启用', '在线', '已处理', '已解读'].includes(status)) finalType = 'success';
    else if (['停用', '离线', '异常', '待处理', '未解读'].includes(status)) finalType = 'warning';
    else if (['报警', '高风险', '严重'].includes(status)) finalType = 'error';
    else if (['低风险', '普通'].includes(status)) finalType = 'blue';
  }

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[finalType as keyof typeof styles] || styles.neutral}`}>
      {status}
    </span>
  );
};

export function DataTable<T extends { id: string | number }>({ columns, data, title, actions, onSearch }: DataTableProps<T>) {
  return (
    <div className="flex flex-col h-full bg-slate-50 p-6">
      <div className="bg-white rounded-lg shadow-sm border border-slate-100 flex-1 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          {title && <h2 className="text-lg font-bold text-slate-800">{title}</h2>}
          <div className="flex flex-wrap items-center gap-2">
            {onSearch && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input 
                  type="text" 
                  placeholder="搜索..." 
                  className="pl-9 pr-4 py-2 border border-slate-200 rounded text-sm focus:outline-none focus:border-blue-500 w-64"
                />
              </div>
            )}
            {actions}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                {columns.map((col, idx) => (
                  <th key={idx} className={`p-4 font-semibold text-slate-600 text-sm ${col.className || ''}`}>
                    {col.header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((item, idx) => (
                <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50 transition">
                  {columns.map((col, cIdx) => (
                    <td key={cIdx} className="p-4 text-slate-700 text-sm">
                      {typeof col.accessor === 'function' ? col.accessor(item) : (item[col.accessor] as React.ReactNode)}
                    </td>
                  ))}
                </tr>
              ))}
              {data.length === 0 && (
                <tr>
                  <td colSpan={columns.length} className="p-8 text-center text-slate-400">暂无数据</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-4 border-t border-slate-200 flex items-center justify-between bg-white rounded-b-lg">
          <div className="text-sm text-slate-500">
            显示 1 到 {Math.min(10, data.length)} 条，共 {data.length} 条
          </div>
          <div className="flex space-x-1">
            <button className="p-1 border border-slate-200 rounded hover:bg-slate-50 disabled:opacity-50">
              <ChevronLeft className="w-4 h-4 text-slate-600" />
            </button>
            <button className="px-3 py-1 bg-blue-500 text-white rounded text-sm font-medium">1</button>
            <button className="px-3 py-1 border border-slate-200 rounded text-sm text-slate-600 hover:bg-slate-50">2</button>
            <button className="p-1 border border-slate-200 rounded hover:bg-slate-50">
              <ChevronRight className="w-4 h-4 text-slate-600" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export const StandardActions = () => (
  <>
    <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm flex items-center transition">
      <Plus className="w-4 h-4 mr-1" /> 新增
    </button>
    <button className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 px-3 py-2 rounded text-sm flex items-center transition">
      <Upload className="w-4 h-4 mr-1" /> 导入
    </button>
    <button className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 px-3 py-2 rounded text-sm flex items-center transition">
      <Download className="w-4 h-4 mr-1" /> 导出
    </button>
  </>
);