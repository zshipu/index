import React from 'react';
import { MapPin, Navigation, AlertTriangle, Activity, User, Phone } from 'lucide-react';
import { DataTable, StatusBadge, Column } from './Shared';

// --- Shared Map Component Placeholder ---
const MapPlaceholder: React.FC<{ type: 'device' | 'user' }> = ({ type }) => (
  <div className="flex flex-col h-full p-6 space-y-4">
    <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-100 flex justify-between items-center">
      <h2 className="text-lg font-bold text-slate-800">{type === 'device' ? '设备分布地图' : '用户分布地图'}</h2>
      <div className="flex space-x-4 text-sm">
        <div className="flex items-center"><span className="w-3 h-3 rounded-full bg-blue-500 mr-2"></span>正常: 850</div>
        <div className="flex items-center"><span className="w-3 h-3 rounded-full bg-red-500 mr-2"></span>报警: 12</div>
        <div className="flex items-center"><span className="w-3 h-3 rounded-full bg-gray-300 mr-2"></span>离线: 120</div>
      </div>
    </div>
    <div className="flex-1 bg-slate-200 rounded-lg relative overflow-hidden border border-slate-300 group">
      {/* Mock Map Background */}
      <div className="absolute inset-0 bg-slate-100 opacity-50" style={{ 
        backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', 
        backgroundSize: '20px 20px' 
      }}></div>
      
      {/* Mock Pins */}
      <div className="absolute top-1/4 left-1/4 text-blue-500 animate-bounce"><MapPin size={32} fill="currentColor" /></div>
      <div className="absolute top-1/2 left-1/3 text-green-500"><MapPin size={32} fill="currentColor" /></div>
      <div className="absolute top-1/3 right-1/4 text-red-500 animate-pulse"><MapPin size={32} fill="currentColor" /></div>
      <div className="absolute bottom-1/4 right-1/3 text-blue-500"><MapPin size={32} fill="currentColor" /></div>
      
      {/* Overlay Info Card */}
      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur p-4 rounded shadow-lg w-64">
        <h3 className="font-bold text-slate-800 mb-2">区域统计 (北京)</h3>
        <div className="space-y-2 text-sm text-slate-600">
           <div className="flex justify-between"><span>设备总数:</span> <span>1,240</span></div>
           <div className="flex justify-between"><span>今日活跃:</span> <span>982</span></div>
           <div className="flex justify-between text-red-500"><span>异常警报:</span> <span>3</span></div>
        </div>
      </div>
      
      <div className="absolute bottom-4 left-4 bg-white px-3 py-1 rounded text-xs text-slate-500 shadow">
        Map Data © Life Guardian Map Service
      </div>
    </div>
  </div>
);

export const MonitorMap = () => <MapPlaceholder type="device" />;
export const UserMap = () => <MapPlaceholder type="user" />;

// --- Fence Management ---
export const MonitorFence: React.FC = () => {
  const data = [
    { id: 1, name: '朝阳公园活动区', address: '北京市朝阳区朝阳公园南路1号', radius: '500m', users: 5, devices: 5, type: '圆形' },
    { id: 2, name: '养老院安全区', address: '北京市海淀区香山路88号', radius: '1000m', users: 120, devices: 120, type: '多边形' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: '围栏名称', accessor: 'name', className: 'font-medium' },
    { header: '中心地址', accessor: 'address' },
    { header: '范围/半径', accessor: 'radius' },
    { header: '监控人数', accessor: 'users' },
    { header: '围栏类型', accessor: 'type' },
    { header: '操作', accessor: () => <button className="text-blue-500 hover:underline">编辑围栏</button> }
  ];

  return <DataTable columns={columns} data={data} title="智能围栏管理" actions={<button className="btn-primary flex items-center bg-blue-500 text-white px-3 py-2 rounded"><Navigation className="w-4 h-4 mr-2"/>新建围栏</button>} />;
};

// --- Alert Info ---
export const MonitorAlert: React.FC = () => {
  const data = [
    { id: 1, type: 'SOS呼叫', user: '李秀英', phone: '13912345678', content: '用户长按SOS键触发求救', time: '2023-10-25 10:45:00', status: '待处理' },
    { id: 2, type: '心率过高', user: '张伟', phone: '13800138000', content: '心率持续超过120bpm (125bpm)', time: '2023-10-25 09:30:00', status: '已通知' },
    { id: 3, type: '跌倒报警', user: '赵本山', phone: '13555555555', content: '检测到跌倒撞击', time: '2023-10-25 08:15:00', status: '已处理' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: '报警类型', accessor: (item) => (
      <span className={`flex items-center font-medium ${item.type === 'SOS呼叫' ? 'text-red-600' : 'text-orange-600'}`}>
        <AlertTriangle className="w-4 h-4 mr-2" /> {item.type}
      </span>
    )},
    { header: '用户姓名', accessor: 'user' },
    { header: '联系电话', accessor: 'phone' },
    { header: '报警内容', accessor: 'content', className: 'max-w-xs truncate' },
    { header: '报警时间', accessor: 'time' },
    { header: '状态', accessor: (item) => <StatusBadge status={item.status} /> },
    { header: '操作', accessor: () => <button className="text-blue-500 hover:underline">详情</button> }
  ];

  return <DataTable columns={columns} data={data} title="手表报警信息" onSearch={() => {}} />;
};

// --- Abnormal Health ---
export const MonitorHealth: React.FC = () => {
  const data = [
    { id: 1, user: '李秀英', age: 72, risk: '高风险', reason: '连续3天血压偏高, 心律失常频发', updated: '2023-10-25' },
    { id: 2, user: '张伟', age: 65, risk: '中风险', reason: '夜间血氧平均值低于92%', updated: '2023-10-24' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: '用户姓名', accessor: 'user' },
    { header: '年龄', accessor: 'age' },
    { header: '健康风险等级', accessor: (item) => (
      <span className={`px-2 py-1 rounded text-xs font-bold ${item.risk === '高风险' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'}`}>
        {item.risk}
      </span>
    )},
    { header: '异常原因', accessor: 'reason' },
    { header: '更新日期', accessor: 'updated' },
    { header: '操作', accessor: () => <button className="text-blue-500 hover:underline">查看健康档案</button> }
  ];

  return <DataTable columns={columns} data={data} title="异常健康监控" />;
};