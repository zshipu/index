import React, { useState } from 'react';
import { Search, Send, User, Clock, CheckDouble, MoreVertical } from 'lucide-react';

interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'agent' | 'system';
  time: string;
  type?: 'text' | 'image' | 'system';
}

interface ChatSession {
  id: number;
  user: string;
  avatar: string;
  lastMsg: string;
  time: string;
  unread: number;
  category: string;
  status: 'active' | 'closed';
}

export const CSChat: React.FC = () => {
  const [activeSession, setActiveSession] = useState<number>(1);
  const [inputText, setInputText] = useState('');

  const sessions: ChatSession[] = [
    { id: 1, user: '张伟', avatar: '', lastMsg: '我的手表怎么连不上了？', time: '10:30', unread: 2, category: '设备问题', status: 'active' },
    { id: 2, user: '李秀英', avatar: '', lastMsg: '谢谢医生，我明白了。', time: '昨天', unread: 0, category: '健康咨询', status: 'closed' },
    { id: 3, user: '王强', avatar: '', lastMsg: '我想咨询一下VIP服务的价格', time: '昨天', unread: 0, category: '服务咨询', status: 'active' },
  ];

  const messages: ChatMessage[] = [
    { id: 1, sender: 'system', text: '会话已开始', time: '10:25', type: 'system' },
    { id: 2, sender: 'user', text: '你好，在吗？', time: '10:26' },
    { id: 3, sender: 'agent', text: '您好，生命卫士客服为您服务，请问有什么可以帮您？', time: '10:26' },
    { id: 4, sender: 'user', text: '我的手表怎么连不上了？蓝牙一直转圈。', time: '10:28' },
    { id: 5, sender: 'user', text: '[图片]', time: '10:28' },
  ];

  return (
    <div className="flex h-full p-4 gap-4 bg-slate-50">
      {/* Session List */}
      <div className="w-80 bg-white rounded-lg shadow-sm border border-slate-100 flex flex-col">
        <div className="p-4 border-b border-slate-100">
           <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
             <input type="text" placeholder="搜索用户..." className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded text-sm focus:outline-none" />
           </div>
           <div className="flex mt-3 space-x-2 overflow-x-auto pb-1 no-scrollbar">
             <button className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-medium whitespace-nowrap">全部</button>
             <button className="px-3 py-1 bg-slate-100 text-slate-500 rounded-full text-xs whitespace-nowrap">心脏类</button>
             <button className="px-3 py-1 bg-slate-100 text-slate-500 rounded-full text-xs whitespace-nowrap">设备类</button>
           </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {sessions.map(session => (
            <div 
              key={session.id} 
              onClick={() => setActiveSession(session.id)}
              className={`p-4 border-b border-slate-50 cursor-pointer hover:bg-slate-50 transition ${activeSession === session.id ? 'bg-blue-50/50 border-l-4 border-l-blue-500' : 'border-l-4 border-l-transparent'}`}
            >
              <div className="flex justify-between items-start mb-1">
                <div className="flex items-center">
                   <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 mr-3">
                     <User size={20} />
                   </div>
                   <div>
                     <h4 className="font-bold text-slate-800 text-sm">{session.user}</h4>
                     <span className="text-xs text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">{session.category}</span>
                   </div>
                </div>
                <span className="text-xs text-slate-400">{session.time}</span>
              </div>
              <div className="flex justify-between items-center mt-2 pl-12">
                 <p className="text-sm text-slate-500 truncate w-40">{session.lastMsg}</p>
                 {session.unread > 0 && (
                   <span className="w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">{session.unread}</span>
                 )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Window */}
      <div className="flex-1 bg-white rounded-lg shadow-sm border border-slate-100 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex justify-between items-center">
          <div className="flex items-center">
            <h3 className="font-bold text-slate-800 mr-4">张伟</h3>
            <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full flex items-center">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span> 在线
            </span>
          </div>
          <div className="flex space-x-2">
            <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500"><Clock size={18} /></button>
            <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500"><MoreVertical size={18} /></button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 bg-slate-50 p-4 overflow-y-auto space-y-4">
          {messages.map((msg) => (
             msg.type === 'system' ? (
                <div key={msg.id} className="text-center text-xs text-slate-400 my-4">----- {msg.text} -----</div>
             ) : (
                <div key={msg.id} className={`flex ${msg.sender === 'agent' ? 'justify-end' : 'justify-start'}`}>
                  {msg.sender === 'user' && <div className="w-8 h-8 rounded-full bg-slate-300 flex-shrink-0 mr-2 flex items-center justify-center"><User size={14}/></div>}
                  <div className={`max-w-[70%] p-3 rounded-lg text-sm shadow-sm ${msg.sender === 'agent' ? 'bg-blue-500 text-white rounded-br-none' : 'bg-white text-slate-700 rounded-bl-none'}`}>
                    {msg.text}
                  </div>
                  {msg.sender === 'agent' && <div className="w-8 h-8 rounded-full bg-blue-600 flex-shrink-0 ml-2 flex items-center justify-center text-white"><User size={14}/></div>}
                </div>
             )
          ))}
        </div>

        {/* Input */}
        <div className="p-4 bg-white border-t border-slate-100">
           <div className="flex items-center gap-2">
             <input 
               type="text" 
               className="flex-1 border border-slate-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-blue-500 bg-slate-50"
               placeholder="请输入回复内容..."
               value={inputText}
               onChange={(e) => setInputText(e.target.value)}
             />
             <button className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-lg transition shadow-sm">
               <Send size={18} />
             </button>
           </div>
           <div className="flex justify-between items-center mt-2 text-xs text-slate-400 px-1">
             <span>Shift + Enter 换行</span>
             <div className="flex space-x-3">
               <span className="cursor-pointer hover:text-blue-500">发送图片</span>
               <span className="cursor-pointer hover:text-blue-500">快捷回复</span>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};