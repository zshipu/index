import React from 'react';
import { User, Mail, Phone, Lock, Save, Camera } from 'lucide-react';

export const ProfilePage: React.FC = () => {
  return (
    <div className="p-6 h-full bg-slate-50 overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header Card */}
        <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-100 flex items-center gap-8">
           <div className="relative group cursor-pointer">
              <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 text-3xl font-bold border-4 border-white shadow-md">
                 L
              </div>
              <div className="absolute inset-0 bg-black/30 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                 <Camera className="text-white" />
              </div>
           </div>
           <div>
             <h2 className="text-2xl font-bold text-slate-800">超级管理员</h2>
             <p className="text-slate-500 mt-1">技术部 · 系统负责人</p>
             <div className="flex gap-2 mt-4">
                <span className="px-3 py-1 bg-green-100 text-green-600 rounded-full text-xs font-bold">状态正常</span>
                <span className="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-bold">超级权限</span>
             </div>
           </div>
        </div>

        {/* Form Card */}
        <div className="bg-white p-8 rounded-lg shadow-sm border border-slate-100">
           <h3 className="text-lg font-bold text-slate-800 mb-6 border-b border-slate-100 pb-4">基本资料设置</h3>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                 <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-slate-600">用户昵称</label>
                    <div className="relative">
                       <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                       <input type="text" defaultValue="Admin" className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded focus:outline-none focus:border-blue-500 transition" />
                    </div>
                 </div>
                 
                 <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-slate-600">手机号码</label>
                    <div className="relative">
                       <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                       <input type="text" defaultValue="13800138000" className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded focus:outline-none focus:border-blue-500 transition" />
                    </div>
                 </div>

                 <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-slate-600">电子邮箱</label>
                    <div className="relative">
                       <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                       <input type="email" defaultValue="admin@lifeguardian.com" className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded focus:outline-none focus:border-blue-500 transition" />
                    </div>
                 </div>
              </div>

              <div className="space-y-4">
                 <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-slate-600">新密码</label>
                    <div className="relative">
                       <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                       <input type="password" placeholder="如果不修改请留空" className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded focus:outline-none focus:border-blue-500 transition" />
                    </div>
                 </div>

                 <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-slate-600">确认密码</label>
                    <div className="relative">
                       <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                       <input type="password" placeholder="再次输入新密码" className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded focus:outline-none focus:border-blue-500 transition" />
                    </div>
                 </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-slate-600">性别</label>
                    <select className="w-full px-4 py-2 border border-slate-300 rounded focus:outline-none focus:border-blue-500 transition bg-white">
                       <option>男</option>
                       <option>女</option>
                    </select>
                 </div>
              </div>
           </div>

           <div className="mt-8 flex justify-end">
              <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded flex items-center shadow-sm transition">
                 <Save className="w-4 h-4 mr-2" /> 保存修改
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};