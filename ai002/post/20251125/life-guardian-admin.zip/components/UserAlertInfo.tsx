import React from 'react';
import { Search, ChevronLeft, ChevronRight, Edit2 } from 'lucide-react';
import { StatusBadge } from './Shared';

export const UserAlertInfo: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-100 min-h-[500px] flex flex-col">
      <div className="p-4 border-b border-slate-100 flex items-center space-x-2">
         <h3 className="font-bold text-slate-800 text-sm">警报信息</h3>
      </div>
      
      {/* Filters */}
      <div className="p-4 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
         <div className="md:col-span-3 flex items-center">
            <label className="text-sm text-slate-600 mr-2 w-20">报警类型</label>
            <select className="flex-1 border border-slate-300 rounded px-3 py-1.5 text-sm focus:outline-none focus:border-blue-500">
               <option>请选择</option>
               <option>心率报警</option>
               <option>血氧报警</option>
            </select>
         </div>
         <div className="md:col-span-5 flex items-center">
            <label className="text-sm text-slate-600 mr-2 w-20">报警时间</label>
            <div className="flex-1 flex items-center space-x-2">
               <input type="date" className="border border-slate-300 rounded px-2 py-1.5 text-sm flex-1" />
               <span className="text-slate-400">-</span>
               <input type="date" className="border border-slate-300 rounded px-2 py-1.5 text-sm flex-1" />
            </div>
         </div>
         <div className="md:col-span-2">
             <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1.5 rounded text-sm flex items-center justify-center w-full transition">
                <Search className="w-3 h-3 mr-1" /> 搜索
             </button>
         </div>
      </div>
      
      {/* Add to Clipboard Toast/Modal Visualization (Floating) */}
      <div className="relative">
         {/* Table */}
         <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
               <thead>
                  <tr className="bg-slate-50 text-slate-600 text-xs uppercase border-y border-slate-100">
                     <th className="p-4 font-semibold w-16">序号</th>
                     <th className="p-4 font-semibold">姓名</th>
                     <th className="p-4 font-semibold">手机号</th>
                     <th className="p-4 font-semibold">报警类型</th>
                     <th className="p-4 font-semibold w-64">报警内容</th>
                     <th className="p-4 font-semibold">报警时间</th>
                     <th className="p-4 font-semibold">报警地点</th>
                     <th className="p-4 font-semibold">备注</th>
                     <th className="p-4 font-semibold">是否确定警报</th>
                     <th className="p-4 font-semibold text-center">操作</th>
                  </tr>
               </thead>
               <tbody className="text-sm text-slate-700">
                  <tr className="border-b border-slate-50 hover:bg-slate-50 transition">
                     <td className="p-4">1</td>
                     <td className="p-4">--</td>
                     <td className="p-4">13905435258</td>
                     <td className="p-4">心率警报</td>
                     <td className="p-4 text-xs text-slate-500">当前心率121，高于阈值120...</td>
                     <td className="p-4">2025-12-05 23:02</td>
                     <td className="p-4">--</td>
                     <td className="p-4"><Edit2 className="w-3 h-3 text-slate-400 cursor-pointer" /></td>
                     <td className="p-4">
                        <div className="w-8 h-4 bg-slate-300 rounded-full relative cursor-pointer">
                           <div className="w-4 h-4 bg-white rounded-full absolute left-0 shadow-sm border border-slate-200"></div>
                        </div>
                     </td>
                     <td className="p-4 text-center">--</td>
                  </tr>
               </tbody>
            </table>
         </div>

         {/* Floating Notification Example */}
         <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-700/80 backdrop-blur text-white px-6 py-3 rounded-lg shadow-lg flex flex-col items-center">
             <div className="mb-1 text-2xl">✓</div>
             <div className="text-sm">已添加到剪贴板</div>
         </div>
      </div>

       {/* Pagination */}
        <div className="p-4 mt-auto border-t border-slate-100 flex items-center justify-end space-x-4 bg-white">
           <div className="text-sm text-slate-500">
             共 1 条
           </div>
           <select className="border border-slate-300 rounded px-2 py-1 text-sm bg-white focus:outline-none">
             <option>10条/页</option>
           </select>
           <div className="flex space-x-1">
             <button className="px-2 py-1 border border-slate-200 rounded text-slate-400 hover:bg-slate-50 disabled:opacity-50 text-sm"><ChevronLeft className="w-3 h-3" /></button>
             <button className="px-3 py-1 bg-blue-500 text-white rounded text-sm">1</button>
             <button className="px-2 py-1 border border-slate-200 rounded text-slate-600 hover:bg-slate-50"><ChevronRight className="w-3 h-3" /></button>
           </div>
           <div className="flex items-center space-x-2 text-sm text-slate-500">
             <span>前往</span>
             <input type="text" className="w-10 border border-slate-300 rounded px-1 py-0.5 text-center focus:outline-none" defaultValue="1" />
             <span>页</span>
           </div>
        </div>
    </div>
  );
};