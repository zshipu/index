import React from 'react';
import { Settings, Eye, Battery, Signal, Edit } from 'lucide-react';
import { DataTable, StatusBadge, StandardActions, Column } from './Shared';

// --- Watch Management ---
export const DeviceWatch: React.FC = () => {
  const data = [
    { id: 'W001', sn: 'HW-20231001-001', model: 'HELOWIN WATCH H1', user: '张伟', status: '在线', battery: 85, signal: '强', updated: '2023-10-25 10:30' },
    { id: 'W002', sn: 'HW-20231001-005', model: 'HELOWIN WATCH H1', user: '李秀英', status: '在线', battery: 42, signal: '中', updated: '2023-10-25 10:29' },
    { id: 'W003', sn: 'TE-20230912-088', model: 'TE5100Y-C', user: '未绑定', status: '离线', battery: 0, signal: '-', updated: '2023-10-20 18:00' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: '设备编号', accessor: 'id' },
    { header: '序列号(SN)', accessor: 'sn' },
    { header: '型号', accessor: 'model' },
    { header: '绑定用户', accessor: 'user' },
    { header: '状态', accessor: (item) => <StatusBadge status={item.status} /> },
    { header: '电量', accessor: (item) => (
      <div className="flex items-center space-x-1">
        <Battery size={16} className={item.battery < 20 ? 'text-red-500' : 'text-green-500'} />
        <span>{item.battery}%</span>
      </div>
    )},
    { header: '最后通信', accessor: 'updated' },
    { header: '操作', accessor: () => (
      <div className="flex space-x-2">
        <button className="text-slate-500 hover:text-slate-700" title="详情"><Eye size={16} /></button>
        <button className="text-blue-500 hover:text-blue-700" title="设置"><Settings size={16} /></button>
      </div>
    )}
  ];

  return <DataTable columns={columns} data={data} title="手表设备列表" actions={<StandardActions />} onSearch={() => {}} />;
};

// --- Instrument Management ---
export const DeviceInstrument: React.FC = () => {
  const data = [
    { id: 'I001', model: 'TE-7000Y-C', type: '血压计', user: '赵本山', lastSync: '2023-10-25 08:00', status: '正常' },
    { id: 'I002', model: 'M101 Air', type: '血糖仪', user: '王强', lastSync: '2023-10-24 20:30', status: '正常' },
    { id: 'I003', model: 'TE-7000Y-C', type: '血压计', user: '库存', lastSync: '-', status: '未激活' },
  ];

  const columns: Column<typeof data[0]>[] = [
    { header: '设备ID', accessor: 'id' },
    { header: '设备型号', accessor: 'model' },
    { header: '类型', accessor: 'type' },
    { header: '绑定用户', accessor: 'user' },
    { header: '最近同步', accessor: 'lastSync' },
    { header: '状态', accessor: (item) => <StatusBadge status={item.status} /> },
    { header: '操作', accessor: () => (
      <div className="flex space-x-2">
        <button className="text-slate-500 hover:text-slate-700"><Eye size={16} /></button>
        <button className="text-blue-500 hover:text-blue-700"><Edit size={16} /></button>
      </div>
    )}
  ];

  return <DataTable columns={columns} data={data} title="仪器设备列表" actions={<StandardActions />} onSearch={() => {}} />;
};