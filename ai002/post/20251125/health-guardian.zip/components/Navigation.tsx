import React from 'react';
import { LayoutDashboard, Users, Activity, MessageSquareHeart, UserCircle } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const navItems = [
    { id: 'dashboard', label: '首页', icon: LayoutDashboard },
    { id: 'family', label: '家庭', icon: Users },
    { id: 'devices', label: '设备', icon: Activity },
    { id: 'ai-assistant', label: 'AI 顾问', icon: MessageSquareHeart },
    { id: 'profile', label: '我的', icon: UserCircle },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <nav className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 h-screen fixed left-0 top-0 z-20">
        <div className="p-6 flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
            <Activity className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
            Health Guardian
          </span>
        </div>
        
        <div className="flex-1 px-4 py-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium ${
                  isActive
                    ? 'bg-primary/10 text-primary shadow-sm'
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-primary' : 'text-slate-400'}`} />
                {item.label}
              </button>
            );
          })}
        </div>
        
        <div className="p-4 border-t border-slate-100">
           <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
             <p className="text-xs text-slate-500 mb-1">当前方案</p>
             <p className="text-sm font-bold text-slate-800">家庭尊享版 (Pro)</p>
             <p className="text-xs text-secondary mt-1">生效中</p>
           </div>
        </div>
      </nav>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 pb-safe z-50">
        <div className="flex justify-around items-center h-16">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className="flex flex-col items-center justify-center w-full h-full space-y-1"
              >
                <Icon
                  className={`w-6 h-6 transition-colors ${
                    isActive ? 'text-primary' : 'text-slate-400'
                  }`}
                />
                <span
                  className={`text-[10px] font-medium ${
                    isActive ? 'text-primary' : 'text-slate-400'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};

export default Navigation;