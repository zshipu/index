export enum RiskLevel {
  LOW = '低风险',
  MODERATE = '中风险',
  HIGH = '高风险',
  CRITICAL = '危急'
}

export enum DeviceType {
  WATCH = '智能手表',
  BP_MONITOR = '智能血压计',
  ECG_PATCH = '心电贴',
  SCALE = '体脂秤'
}

export enum DeviceStatus {
  CONNECTED = '已连接',
  DISCONNECTED = '未连接',
  LOW_BATTERY = '电量低',
  ERROR = '异常'
}

export interface HealthMetric {
  label: string;
  value: string | number;
  unit: string;
  status: 'normal' | 'warning' | 'danger';
  trend: 'up' | 'down' | 'stable';
  lastUpdated: string;
}

export interface TrendDataPoint {
  day: string;
  value: number;
}

export interface RiskPrediction {
  condition: string;
  level: RiskLevel;
  probability: number;
  description: string;
  intervention: string;
}

export interface Device {
  id: string;
  name: string;
  type: DeviceType;
  status: DeviceStatus;
  batteryLevel: number;
  lastSync: string;
}

export interface HealthPlan {
  id: string;
  category: string;
  name: string;
  triggers: string[];
  dietPlan: string[];
  exercisePlan: string[];
  dailyTasks: string[];
  logic: string;
}

export interface User {
  id: string;
  name: string;
  avatar: string; // URL
  age: number;
  role: '本人' | '长辈' | '孩子' | '伴侣';
  healthScore: number;
  activePlanId?: string; // Link to HealthPlan
  metrics: {
    heartRate: HealthMetric;
    bloodPressure: HealthMetric;
    spO2: HealthMetric;
    sleep: HealthMetric;
  };
  risks: RiskPrediction[];
  trends: {
    heartRate: TrendDataPoint[];
    bloodPressure: TrendDataPoint[];
  };
}