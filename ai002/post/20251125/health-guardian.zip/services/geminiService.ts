import { GoogleGenAI } from "@google/genai";
import { User } from '../types';

// Initialize the Gemini AI client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
你是一位名为“健康卫士”的AI助手，充满关怀且知识渊博。
你的目标是根据用户的健康数据提供有帮助的、非诊断性的健康建议。
请始终说明你是一个AI，不是医生。
如果用户的生命体征处于危急状态，请建议他们立即寻求医疗救助。
回答要简洁、积极并具有可操作性。
请全程使用中文回答用户的问题。
`;

export const getHealthAdvice = async (
  userMessage: string, 
  currentUserData: User,
  history: { role: string; parts: { text: string }[] }[] = []
) => {
  try {
    const userContext = `
      当前用户背景:
      姓名: ${currentUserData.name}
      年龄: ${currentUserData.age}
      最近生命体征: 
      - 心率: ${currentUserData.metrics.heartRate.value}
      - 血压: ${currentUserData.metrics.bloodPressure.value}
      - 睡眠: ${currentUserData.metrics.sleep.value}
      风险提示: ${currentUserData.risks.map(r => r.condition).join(', ')}
    `;

    const model = 'gemini-2.5-flash';

    // Construct the conversation history including the system context injected into the first user message
    // or utilizing systemInstruction if we were using the chat object directly. 
    // Here we use generateContent for a single turn response based on history + new message.
    
    // Using simple generateContent for this demo to be stateless, but injecting context.
    const prompt = `
      ${SYSTEM_INSTRUCTION}
      
      ${userContext}

      用户问题: ${userMessage}
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Error fetching AI advice:", error);
    return "我现在连接健康数据库时遇到了一些问题，请稍后再试。";
  }
};