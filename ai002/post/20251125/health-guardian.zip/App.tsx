import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import { MOCK_USERS, MOCK_DEVICES, HEALTH_PLANS } from './constants';
import { User, HealthMetric, DeviceStatus, DeviceType } from './types';
import { Bell, Search, Menu, MessageSquareHeart, Watch, Scale, Activity as ActivityIcon, Battery, Wifi, WifiOff, Heart, ClipboardCheck, Utensils, Dumbbell, ArrowLeft, CheckCircle, ListTodo, Plus, X } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { getHealthAdvice } from './services/geminiService';

// --- Sub-components for specific pages to keep file count compliant ---

// 1. HeartRateDetails Component
const HeartRateDetails: React.FC<{ user: User; onBack: () => void }> = ({ user, onBack }) => {
  const { heartRate } = user.metrics;
  const trendData = user.trends.heartRate;

  // Calculate simple stats
  const values = trendData.map(d => d.value);
  const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  const max = Math.max(...values);
  const min = Math.min(...values);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header with Back Button */}
      <div className="flex items-center gap-4 mb-2">
        <button 
          onClick={onBack}
          className="p-2 bg-white border border-slate-200 hover:bg-slate-50 rounded-full transition-colors shadow-sm"
        >
          <ArrowLeft className="w-5 h-5 text-slate-600" />
        </button>
        <div>
          <h2 className="text-lg font-bold text-slate-800">心率详细分析</h2>
          <p className="text-xs text-slate-500">过去7天监测数据</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
           <p className="text-xs text-slate-400 mb-1">当前心率</p>
           <p className="text-2xl font-bold text-slate-800">{heartRate.value} <span className="text-xs font-normal text-slate-400">bpm</span></p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
           <p className="text-xs text-slate-400 mb-1">7日平均</p>
           <p className="text-2xl font-bold text-slate-800">{avg} <span className="text-xs font-normal text-slate-400">bpm</span></p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
           <p className="text-xs text-slate-400 mb-1">最高记录</p>
           <p className="text-2xl font-bold text-rose-500">{max} <span className="text-xs font-normal text-slate-400">bpm</span></p>
        </div>
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
           <p className="text-xs text-slate-400 mb-1">最低记录</p>
           <p className="text-2xl font-bold text-emerald-500">{min} <span className="text-xs font-normal text-slate-400">bpm</span></p>
        </div>
      </div>

      {/* Main Chart */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-6">心率走势图 (Heart Rate Trend)</h3>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorHrDetail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} dy={10} />
              <YAxis domain={['dataMin - 10', 'dataMax + 10']} axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} />
              <Tooltip 
                contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
              />
              <Area type="monotone" dataKey="value" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill="url(#colorHrDetail)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Analysis Card */}
      <div className="bg-gradient-to-br from-rose-50 to-orange-50 p-6 rounded-2xl border border-rose-100">
        <div className="flex gap-4 items-start">
           <div className="bg-white p-3 rounded-full h-fit shadow-sm text-rose-500 shrink-0">
             <MessageSquareHeart className="w-6 h-6" />
           </div>
           <div>
             <h3 className="font-bold text-rose-900 mb-2">AI 智能分析</h3>
             <p className="text-rose-800 text-sm leading-relaxed">
               根据过去7天的数据分析，{user.name}的心率总体保持在正常范围内（60-100bpm）。
               平均静息心率为 {avg} bpm，波动稳定性良好。
               {max > 100 ? '检测到有一次较高心率记录，可能与运动或情绪波动有关，建议结合当时活动情况确认。' : '未检测到明显的心率异常波动。'}
               建议继续保持当前的运动频率，并注意夜间休息质量。
             </p>
           </div>
        </div>
      </div>

      {/* History List */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-50 flex justify-between items-center">
          <h3 className="font-bold text-slate-800">历史记录</h3>
          <button className="text-primary text-xs font-medium">查看全部</button>
        </div>
        <div className="divide-y divide-slate-50">
          {trendData.slice().reverse().map((item, idx) => (
            <div key={idx} className="p-4 flex justify-between items-center hover:bg-slate-50 transition-colors">
              <span className="text-slate-600 text-sm font-medium">{item.day}</span>
              <div className="flex items-center gap-4">
                <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                  item.value > 100 || item.value < 60 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {item.value > 100 || item.value < 60 ? '异常' : '正常'}
                </span>
                <span className="text-slate-900 font-bold w-16 text-right">{item.value} bpm</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 2. Dashboard Component
const Dashboard: React.FC<{ user: User; onNavigateToHeartRate: () => void }> = ({ user, onNavigateToHeartRate }) => {
  const heartRate = user.metrics.heartRate;
  // Filter out heartRate from the general grid to avoid duplication
  const gridMetrics = (Object.entries(user.metrics) as [string, HealthMetric][])
    .filter(([key]) => key !== 'heartRate');
  
  // Find active plan
  const activePlan = HEALTH_PLANS.find(p => p.id === user.activePlanId);

  // Local state for checking off tasks
  const [checkedTasks, setCheckedTasks] = useState<Record<string, boolean>>({});

  const toggleTask = (taskIndex: number) => {
    setCheckedTasks(prev => ({
      ...prev,
      [`${user.id}-${activePlan?.id}-${taskIndex}`]: !prev[`${user.id}-${activePlan?.id}-${taskIndex}`]
    }));
  };

  // State for dynamic exercises
  const [customExercises, setCustomExercises] = useState<string[]>([]);
  const [isAddingExercise, setIsAddingExercise] = useState(false);
  const [newExerciseInput, setNewExerciseInput] = useState('');

  // Reset custom exercises when user changes
  useEffect(() => {
    setCustomExercises([]);
  }, [user.id]);

  const handleAddExercise = () => {
    if (newExerciseInput.trim()) {
      setCustomExercises([...customExercises, newExerciseInput.trim()]);
      setNewExerciseInput('');
      setIsAddingExercise(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Prominent Heart Rate Card - Interactive */}
      <div 
        onClick={onNavigateToHeartRate}
        className="w-full bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex items-center gap-6 relative overflow-hidden group hover:shadow-md transition-all cursor-pointer"
      >
        <div className="absolute right-0 top-0 w-32 h-32 bg-rose-50 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-110 transition-transform"></div>
        
        <div className="p-5 bg-rose-50 rounded-2xl z-10 transition-colors group-hover:bg-rose-100">
           <Heart className="w-10 h-10 text-rose-500 animate-pulse fill-rose-500/20" />
        </div>
        
        <div className="z-10">
          <div className="flex items-center gap-2 mb-1">
             <p className="text-slate-500 font-medium text-lg">{heartRate.label}</p>
             <span className="text-xs bg-slate-100 text-slate-400 px-2 py-0.5 rounded-full group-hover:bg-white transition-colors">点击查看详情</span>
          </div>
          <div className="flex items-baseline gap-3">
             <span className="text-6xl font-bold text-slate-900 tracking-tighter">{heartRate.value}</span>
             <span className="text-2xl text-slate-400 font-medium">{heartRate.unit}</span>
          </div>
        </div>

        <div className="ml-auto text-right hidden sm:block z-10">
           <div className={`text-sm font-bold px-4 py-1.5 rounded-full inline-block mb-2 ${
               heartRate.status === 'normal' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
           }`}>
               {heartRate.status === 'normal' ? '● 状态良好' : '● 需关注'}
           </div>
           <p className="text-sm text-slate-400 font-medium">{heartRate.lastUpdated} 更新</p>
        </div>
      </div>

      {/* Active Health Plan Card */}
      {activePlan && (
        <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-2xl p-6 border border-primary/10">
          <div className="flex items-center gap-2 mb-4">
            <ClipboardCheck className="w-5 h-5 text-primary" />
            <h3 className="font-bold text-slate-800 text-lg">当前专属方案：{activePlan.name}</h3>
            <span className="text-xs bg-white text-primary px-2 py-1 rounded-full font-medium border border-primary/20">
              {activePlan.category}
            </span>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
              <div className="flex items-center gap-2 mb-2 text-secondary">
                <Utensils className="w-4 h-4" />
                <span className="font-bold text-sm">饮食方案</span>
              </div>
              <ul className="text-sm text-slate-600 space-y-1 list-disc list-inside">
                {activePlan.dietPlan.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
            
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-primary">
                  <Dumbbell className="w-4 h-4" />
                  <span className="font-bold text-sm">运动方案</span>
                </div>
                {!isAddingExercise && (
                  <button 
                    onClick={() => setIsAddingExercise(true)}
                    className="p-1 rounded-md hover:bg-primary/10 text-primary transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                )}
              </div>
              <ul className="text-sm text-slate-600 space-y-1 list-disc list-inside mb-2">
                {activePlan.exercisePlan.concat(customExercises).map((item, idx) => (
                  <li key={idx} className="animate-fade-in">{item}</li>
                ))}
              </ul>
              
              {isAddingExercise && (
                <div className="flex gap-2 animate-fade-in mt-2 border-t border-slate-100 pt-2">
                  <input 
                    type="text" 
                    value={newExerciseInput}
                    onChange={(e) => setNewExerciseInput(e.target.value)}
                    placeholder="输入新运动..."
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
                    onKeyDown={(e) => e.key === 'Enter' && handleAddExercise()}
                    autoFocus
                  />
                  <button 
                    onClick={handleAddExercise} 
                    className="text-xs bg-primary text-white px-3 py-1 rounded-lg hover:bg-sky-600"
                  >
                    添加
                  </button>
                  <button 
                    onClick={() => setIsAddingExercise(false)}
                    className="p-1 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* New Daily Action Guide Section */}
          <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-sm">
             <div className="flex items-center gap-2 mb-3 text-slate-700">
               <ListTodo className="w-5 h-5 text-emerald-500" />
               <h4 className="font-bold text-sm">今日行动指南 (Daily Actions)</h4>
             </div>
             <div className="space-y-2">
               {activePlan.dailyTasks?.map((task, idx) => {
                 const isChecked = checkedTasks[`${user.id}-${activePlan.id}-${idx}`] || false;
                 return (
                   <div 
                     key={idx} 
                     onClick={() => toggleTask(idx)}
                     className={`flex items-center gap-3 p-3 rounded-xl transition-all cursor-pointer border ${
                       isChecked ? 'bg-emerald-50 border-emerald-100' : 'bg-slate-50 border-slate-100 hover:bg-slate-100'
                     }`}
                   >
                     <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
                       isChecked ? 'bg-emerald-500 text-white' : 'bg-white border-2 border-slate-300'
                     }`}>
                       {isChecked && <CheckCircle className="w-4 h-4" />}
                     </div>
                     <span className={`text-sm ${isChecked ? 'text-emerald-700 line-through decoration-emerald-500/50' : 'text-slate-700'}`}>
                       {task}
                     </span>
                   </div>
                 );
               })}
             </div>
          </div>
        </div>
      )}

      {/* Header Stats Grid (Excluding Heart Rate) */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {gridMetrics.map(([key, metric]) => (
          <div key={key} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-2">
              <span className="text-sm text-slate-500 font-medium">{metric.label}</span>
              <span className={`w-2 h-2 rounded-full ${
                metric.status === 'normal' ? 'bg-emerald-500' : 
                metric.status === 'warning' ? 'bg-amber-500' : 'bg-red-500'
              }`} />
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold text-slate-800">{metric.value}</span>
              <span className="text-xs text-slate-400">{metric.unit}</span>
            </div>
            <div className="mt-2 text-xs text-slate-400 flex items-center justify-between">
              <span>{metric.lastUpdated}</span>
              <span className={`${metric.trend === 'up' ? 'text-red-500' : 'text-emerald-500'} font-medium`}>
                {metric.trend === 'up' ? '↑' : metric.trend === 'down' ? '↓' : '→'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Risks Section */}
      {user.risks.length > 0 && (
        <div className="bg-red-50 border border-red-100 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="bg-red-100 p-2 rounded-lg">
              <Bell className="w-5 h-5 text-red-600" />
            </div>
            <h3 className="font-bold text-red-900">健康风险预警 (Health Alert)</h3>
          </div>
          {user.risks.map((risk, idx) => (
             <div key={idx} className="mb-3 last:mb-0">
               <div className="flex justify-between items-center mb-1">
                 <span className="font-semibold text-red-800">{risk.condition}</span>
                 <span className="text-xs font-bold px-2 py-1 bg-red-200 text-red-800 rounded-full">{risk.level}</span>
               </div>
               <p className="text-sm text-red-700 mb-2">{risk.description}</p>
               <div className="bg-white/50 p-3 rounded-lg">
                 <p className="text-sm font-medium text-red-800">建议干预措施:</p>
                 <p className="text-sm text-red-700">{risk.intervention}</p>
               </div>
             </div>
          ))}
        </div>
      )}

      {/* Trends Chart */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-6">心率趋势 (近7天)</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={user.trends.heartRate}>
              <defs>
                <linearGradient id="colorHr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
              <Tooltip 
                contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
              />
              <Area type="monotone" dataKey="value" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill="url(#colorHr)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

// 3. Devices Component
const DevicesList: React.FC = () => {
  const getIcon = (type: DeviceType) => {
    switch (type) {
      case DeviceType.WATCH: return <Watch className="w-6 h-6" />;
      case DeviceType.SCALE: return <Scale className="w-6 h-6" />;
      default: return <ActivityIcon className="w-6 h-6" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-slate-800">已连接设备 (Connected Devices)</h2>
        <button className="text-sm text-primary font-medium hover:underline">+ 添加新设备</button>
      </div>
      {MOCK_DEVICES.map((device) => (
        <div key={device.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${device.status === DeviceStatus.CONNECTED ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-400'}`}>
              {getIcon(device.type)}
            </div>
            <div>
              <h3 className="font-semibold text-slate-800">{device.name}</h3>
              <p className="text-xs text-slate-500 flex items-center gap-1">
                上次同步: {device.lastSync}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex items-center gap-1 text-xs font-medium text-slate-500">
                <Battery className={`w-4 h-4 ${device.batteryLevel < 20 ? 'text-red-500' : 'text-slate-400'}`} />
                {device.batteryLevel}%
             </div>
             {device.status === DeviceStatus.CONNECTED ? (
               <div className="flex items-center gap-1">
                 <Wifi className="w-4 h-4 text-emerald-500" />
                 <span className="text-[10px] text-emerald-600 font-medium">{device.status}</span>
               </div>
             ) : (
               <div className="flex items-center gap-1">
                 <WifiOff className="w-4 h-4 text-slate-300" />
                 <span className="text-[10px] text-slate-400 font-medium">{device.status}</span>
               </div>
             )}
          </div>
        </div>
      ))}
    </div>
  );
};

// 4. AI Assistant Component
const AIAssistant: React.FC<{ user: User }> = ({ user }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([
    { role: 'ai', text: `您好，${user.name}！我是您的健康卫士AI。我可以分析您的最新生命体征、为您推荐健康食谱，或解释体检报告。今天有什么可以帮您？` }
  ]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    const aiResponse = await getHealthAdvice(userMsg, user);
    
    setLoading(false);
    setMessages(prev => [...prev, { role: 'ai', text: aiResponse }]);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] md:h-[calc(100vh-100px)] bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-4 border-b border-slate-100 bg-slate-50">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
          <MessageSquareHeart className="w-5 h-5 text-primary" />
          AI 健康顾问 (AI Coach)
        </h3>
        <p className="text-xs text-slate-500">由 Gemini 2.5 驱动 • 仅供参考，非医疗建议</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
              msg.role === 'user' 
                ? 'bg-primary text-white rounded-tr-none' 
                : 'bg-slate-100 text-slate-800 rounded-tl-none'
            }`}>
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
             <div className="bg-slate-100 p-3 rounded-2xl rounded-tl-none flex gap-2 items-center">
               <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" />
               <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-75" />
               <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-150" />
             </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-100 bg-white">
        <div className="flex gap-2">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="询问关于血压、饮食的问题..."
            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary text-sm"
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="bg-primary hover:bg-sky-600 text-white rounded-xl px-6 font-medium transition-colors disabled:opacity-50"
          >
            发送
          </button>
        </div>
      </div>
    </div>
  );
};

// 5. Family Component
const FamilyList: React.FC<{ activeUserId: string; onSelectUser: (id: string) => void }> = ({ activeUserId, onSelectUser }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {MOCK_USERS.map((u) => (
        <div 
          key={u.id}
          onClick={() => onSelectUser(u.id)}
          className={`cursor-pointer p-5 rounded-2xl border transition-all ${
            activeUserId === u.id 
              ? 'bg-primary/5 border-primary shadow-sm ring-1 ring-primary' 
              : 'bg-white border-slate-100 hover:border-slate-300 hover:shadow-sm'
          }`}
        >
          <div className="flex items-center gap-4 mb-4">
            <img src={u.avatar} alt={u.name} className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-sm" />
            <div>
              <h3 className="font-bold text-slate-800">{u.name}</h3>
              <p className="text-xs text-slate-500">{u.role} • {u.age} 岁</p>
            </div>
            <div className={`ml-auto px-2 py-1 rounded-lg text-xs font-bold ${
              u.healthScore >= 80 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
            }`}>
              {u.healthScore} 分
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-white p-2 rounded border border-slate-50">
              <span className="text-slate-400 block mb-1">心率</span>
              <span className="font-semibold text-slate-700">{u.metrics.heartRate.value} bpm</span>
            </div>
            <div className="bg-white p-2 rounded border border-slate-50">
              <span className="text-slate-400 block mb-1">血压</span>
              <span className="font-semibold text-slate-700">{u.metrics.bloodPressure.value}</span>
            </div>
          </div>
        </div>
      ))}
      {/* Add member button */}
      <div className="border-2 border-dashed border-slate-200 rounded-2xl p-5 flex flex-col items-center justify-center text-slate-400 hover:border-slate-300 hover:text-slate-500 cursor-pointer transition-colors min-h-[160px]">
        <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center mb-2">
          <span className="text-xl">+</span>
        </div>
        <span className="text-sm font-medium">添加家庭成员</span>
      </div>
    </div>
  );
};


// --- Main App ---

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedUserId, setSelectedUserId] = useState<string>(MOCK_USERS[0].id);
  const [dashboardView, setDashboardView] = useState<'overview' | 'heart-rate'>('overview');

  const currentUser = MOCK_USERS.find(u => u.id === selectedUserId) || MOCK_USERS[0];

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setDashboardView('overview');
  };

  const getPageTitle = (tab: string) => {
    if (tab === 'dashboard' && dashboardView === 'heart-rate') {
      return '心率详情';
    }
    switch(tab) {
      case 'dashboard': return '健康概览';
      case 'family': return '家庭成员';
      case 'devices': return '智能设备';
      case 'ai-assistant': return '健康顾问';
      case 'profile': return '个人中心';
      default: return '首页';
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        if (dashboardView === 'heart-rate') {
          return <HeartRateDetails user={currentUser} onBack={() => setDashboardView('overview')} />;
        }
        return <Dashboard user={currentUser} onNavigateToHeartRate={() => setDashboardView('heart-rate')} />;
      case 'family':
        return <FamilyList activeUserId={selectedUserId} onSelectUser={(id) => { setSelectedUserId(id); handleTabChange('dashboard'); }} />;
      case 'devices':
        return <DevicesList />;
      case 'ai-assistant':
        return <AIAssistant user={currentUser} />;
      case 'profile':
        return (
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 text-center">
            <img src={currentUser.avatar} className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-slate-50" alt="Profile" />
            <h2 className="text-2xl font-bold text-slate-800">{currentUser.name}</h2>
            <p className="text-slate-500 mb-6">{currentUser.role} 账户</p>
            
            <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto mb-8">
              <div className="bg-slate-50 p-4 rounded-xl">
                <p className="text-xs text-slate-400">健康积分</p>
                <p className="text-xl font-bold text-primary">2,450</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl">
                <p className="text-xs text-slate-400">连续打卡</p>
                <p className="text-xl font-bold text-orange-500">12 天</p>
              </div>
            </div>
            
            <button className="w-full max-w-sm bg-slate-900 text-white py-3 rounded-xl font-medium hover:bg-slate-800 transition-colors">
              管理订阅
            </button>
          </div>
        );
      default:
        return <Dashboard user={currentUser} onNavigateToHeartRate={() => setDashboardView('heart-rate')} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 pb-20 md:pb-0">
      <Navigation activeTab={activeTab} onTabChange={handleTabChange} />
      
      <main className="md:pl-64 min-h-screen transition-all duration-300">
        {/* Top Header */}
        <header className="sticky top-0 z-10 bg-slate-50/80 backdrop-blur-md border-b border-slate-200/50 px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-slate-800 capitalize">
              {getPageTitle(activeTab)}
            </h1>
            <p className="text-xs text-slate-500 hidden md:block">
              当前监测对象: <span className="font-semibold text-slate-700">{currentUser.name}</span>
            </p>
          </div>

          <div className="flex items-center gap-4">
            {/* User Selector for Mobile/Quick Access */}
            <select 
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="bg-white border border-slate-200 text-sm rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              {MOCK_USERS.map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
            </select>
            
            <button className="relative p-2 text-slate-400 hover:text-primary transition-colors">
              <Bell className="w-6 h-6" />
              {currentUser.risks.length > 0 && (
                <span className="absolute top-1 right-2 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
              )}
            </button>
            <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden md:hidden">
              <img src={currentUser.avatar} alt="User" className="w-full h-full object-cover" />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;