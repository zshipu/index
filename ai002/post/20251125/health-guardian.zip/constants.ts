import { User, RiskLevel, DeviceType, DeviceStatus, Device, HealthPlan } from './types';

export const HEALTH_PLANS: HealthPlan[] = [
  // 1. 慢病干预类
  {
    id: 'plan-sugar',
    category: '慢病干预类',
    name: '稳糖控糖配方',
    triggers: ['生化数据：血糖、糖化血红蛋白数值异常', '问卷评估：高血糖健康风险'],
    dietPlan: ['低GI/GL饮食策略：推荐全谷物、叶菜等低升糖指数食物', '严格控制精制碳水摄入'],
    exercisePlan: ['餐后微动计划：推荐低强度步行或抗阻训练，餐后30-60分钟内执行'],
    dailyTasks: ['晨起空腹测量血糖', '早餐摄入一份全谷物（如燕麦）', '午餐后散步15分钟', '记录晚餐内容', '睡前测量血糖'],
    logic: '根据血糖及糖化血红蛋白数据自动推荐此方案；监测血糖变化动态调整餐后运动'
  },
  {
    id: 'plan-bp',
    category: '慢病干预类',
    name: '降压护航配方',
    triggers: ['血压数据：收缩压/舒张压偏高', '问卷评估：高血压、心脑血管风险'],
    dietPlan: ['DASH饮食改良版：推荐高钾、高镁、高钙、高纤维食物（如深色蔬菜、坚果）', '强制限盐提醒（每日<5g）'],
    exercisePlan: [
      '等长收缩训练：如靠墙静蹲、握力器训练等有助于降压的运动',
      '太极拳或八段锦：每日清晨练习20分钟，帮助调节自主神经'
    ],
    dailyTasks: ['晨起静坐5分钟后测量血压', '按时服用降压药（遵医嘱）', '午餐食用一份深色蔬菜', '下午进行10分钟握力训练', '全天盐摄入控制在5g以内'],
    logic: '基于血压数据自动推荐此方案；随着血压变化，调整运动强度和饮食策略'
  },
  {
    id: 'plan-lipid',
    category: '慢病干预类',
    name: '降脂护心配方',
    triggers: ['生化数据：血脂（总胆固醇、LDL、甘油三酯）超标', '问卷评估：心脏病家族史、肥胖风险'],
    dietPlan: ['富含Omega-3脂肪酸：推荐鱼类（如三文鱼、沙丁鱼）', '控制反式脂肪和饱和脂肪摄入'],
    exercisePlan: ['有氧运动：如快走、游泳、骑车等，至少30分钟/天'],
    dailyTasks: ['早餐加入核桃或亚麻籽', '午餐选择鱼类作为主菜', '下午进行30分钟快走', '晚餐后不吃零食', '全天避免油炸食物'],
    logic: '根据血脂数据及个人风险评估推荐此方案；根据血脂变化和运动量，调整饮食和运动推荐'
  },
  {
    id: 'plan-liver',
    category: '慢病干预类',
    name: '肝脏修复配方',
    triggers: ['生化数据：肝功能指标（ALT、AST、总胆红素）异常', '问卷评估：饮酒习惯、肝炎病史'],
    dietPlan: ['低脂、高纤维饮食：推荐富含膳食纤维的食物，如绿叶蔬菜、燕麦', '增加抗氧化食物，如蓝莓、葡萄'],
    exercisePlan: ['低强度有氧运动：如快步走、瑜伽等促进肝脏健康，避免过度剧烈运动'],
    dailyTasks: ['全天饮水至少2000ml', '晚餐控制在七分饱', '23:00前上床睡觉', '今日不饮酒', '食用一份十字花科蔬菜（如西兰花）'],
    logic: '结合肝功能数据和个人习惯推荐此方案；根据肝功能指标变化，灵活调整运动和饮食策略'
  },

  // 2. 身心调节类
  {
    id: 'plan-sleep',
    category: '身心调节类',
    name: '助眠舒压配方',
    triggers: ['睡眠数据：深睡比例低、清醒次数多', 'HRV数据：持续偏低', '问卷评估：幸福指数低或睡眠障碍评估异常'],
    dietPlan: ['色氨酸与镁强化：推荐富含色氨酸（如牛奶、小米）和镁（如香蕉、菠菜）的食物', '剔除含咖啡因食物'],
    exercisePlan: ['晚间舒缓瑜伽/冥想：低强度拉伸或呼吸训练，减少皮质醇水平'],
    dailyTasks: ['下午3点后不喝咖啡或茶', '晚餐食用助眠食物（如小米粥/香蕉）', '睡前1小时远离手机屏幕', '睡前进行10分钟腹式呼吸', '22:30 准备入睡'],
    logic: '智能匹配：自动识别睡眠质量差和压力高的用户，推荐此方案；动态调整：通过AI助手根据用户反馈调整晚间放松策略'
  },
  {
    id: 'plan-anxiety',
    category: '身心调节类',
    name: '焦虑情绪调节配方',
    triggers: ['情绪数据：焦虑、烦躁、压力评分高', 'HRV数据：持续偏低', '问卷评估：高焦虑或情绪波动大'],
    dietPlan: ['高Omega-3饮食：增加鱼类、坚果、亚麻籽等食品，调节情绪波动'],
    exercisePlan: ['放松训练：如冥想、深呼吸练习、渐进式肌肉放松（PMR）'],
    dailyTasks: ['进行5分钟正念冥想', '记录今天发生的一件开心事', '食用一份深海鱼或补充Omega-3', '户外阳光下散步20分钟', '深呼吸练习3组'],
    logic: '智能匹配：根据情绪评分和HRV自动推荐此方案；动态调整：根据用户反馈调整冥想或放松练习时间'
  },
  {
    id: 'plan-mood',
    category: '身心调节类',
    name: '情绪平衡配方',
    triggers: ['HRV：持续偏低，情绪波动大', '问卷评估：高抑郁、焦虑评分'],
    dietPlan: ['富含色氨酸和维生素B的饮食：如火鸡、坚果、香蕉、牛奶等'],
    exercisePlan: ['轻度有氧运动：如散步、游泳、慢跑等促进情绪平衡'],
    dailyTasks: ['摄入富含B族维生素的早餐', '午间小憩20分钟', '进行一次中等强度运动（如慢跑）', '与朋友或家人通话一次', '睡前写感恩日记'],
    logic: '智能匹配：根据HRV和情绪评分数据自动推荐此方案；动态调整：根据心情波动和HRV数据调整饮食和运动方案'
  },

  // 3. 风险防御类
  {
    id: 'plan-heart-protect',
    category: '风险防御类',
    name: '强心护脉配方',
    triggers: ['心电图：异常波形、房颤概率偏高', '问卷评估：心脑血管风险极高'],
    dietPlan: ['饮食：低脂、富含抗氧化物的食物（如西兰花、胡萝卜、鱼类）'],
    exercisePlan: ['限制性运动：只推荐温和运动，如太极、慢走', '实时心率超限预警'],
    dailyTasks: ['早晚监测静息心率', '避免剧烈情绪波动', '午餐清淡低脂', '进行20分钟太极或慢走', '按时服用心脏保护药物'],
    logic: '智能匹配：根据心电图和HRV数据，推荐此配方；紧急反馈：一旦检测到异常心电图，系统直接推荐高端增值服务'
  },
  {
    id: 'plan-chd',
    category: '风险防御类',
    name: '冠心病护理配方',
    triggers: ['心电图：ST段抬高或改变', '血脂数据：LDL胆固醇过高', '心脏病家族史'],
    dietPlan: ['低胆固醇饮食：推荐低胆固醇、高纤维食物（如燕麦、豆类、坚果）', '控制钠和饱和脂肪的摄入'],
    exercisePlan: ['低强度有氧：如散步、太极、游泳等，避免剧烈运动'],
    dailyTasks: ['监测血压与心率', '严格控制饱和脂肪摄入', '分次少量饮水', '避免用力屏气动作', '午后休息30分钟'],
    logic: '智能匹配：根据心电图、血脂及家族史数据自动推荐此配方；动态调整：基于心率、血压等指标调整运动和饮食方案'
  },

  // 4. 代谢矫正类
  {
    id: 'plan-gout',
    category: '代谢矫正类',
    name: '痛风与高尿酸干预配方',
    triggers: ['生化数据：尿酸值超标（男性 > 420μmol/L，女性 > 360μmol/L）', '关联数据：饮酒习惯、BMI超标'],
    dietPlan: ['低嘌呤饮食：红黄绿灯食谱，严格控制高嘌呤食物（如动物内脏、海鲜浓汤）', '强制推送“每小时饮水提醒”，目标尿量 > 2000ml'],
    exercisePlan: ['无酸运动：屏蔽快跑、举重等无氧运动，推荐有氧运动如慢走、太极'],
    dailyTasks: ['全天饮水总量达2500ml', '午餐避免肉汤和海鲜', '下午食用一份低糖水果（如樱桃）', '避免剧烈无氧运动', '晚餐保持清淡素食'],
    logic: '智能匹配：基于尿酸值和生活习惯自动推荐此配方；动态调整：根据尿酸水平和运动量，调整饮食和运动推荐'
  },
  {
    id: 'plan-diabetes-prev',
    category: '代谢矫正类',
    name: '糖尿病防控配方',
    triggers: ['生化数据：空腹血糖和糖化血红蛋白升高', '问卷评估：糖尿病家族史', '生活习惯：饮食不规律、久坐等'],
    dietPlan: ['低GI饮食：推荐低升糖指数食物（如豆类、全谷物、蔬菜）', '增加膳食纤维摄入'],
    exercisePlan: ['间歇性运动：如间歇跑步、散步等，每次不超过30分钟'],
    dailyTasks: ['晨起记录体重', '每坐1小时起身活动5分钟', '将含糖饮料替换为茶或水', '晚餐后散步20分钟', '记录今日糖分摄入'],
    logic: '智能匹配：根据生化数据和生活习惯自动推荐此配方；动态调整：根据餐后血糖变化调整运动和饮食策略'
  },

  // 5. 呼吸守护类
  {
    id: 'plan-spo2',
    category: '呼吸守护类',
    name: '低血氧与呼吸健康配方',
    triggers: ['血氧饱和度（SpO2）：低于95%', '睡眠数据：血氧骤降', '问卷评估：有吸烟史或睡眠呼吸暂停'],
    dietPlan: ['增加富含维生素C的食物（如柑橘类水果）', '推荐富含锌和镁的食物（如坚果、绿叶蔬菜），增强免疫系统'],
    exercisePlan: ['呼吸肌训练：如缩唇呼吸、腹式呼吸训练', '夜间低氧报警：智能手表监测血氧低于90%时触发强震动报警'],
    dailyTasks: ['晨起进行3组深呼吸训练', '食用一份富含维C的水果', '午间监测一次血氧饱和度', '保持室内通风换气', '夜间采取侧卧位睡眠'],
    logic: '智能匹配：结合血氧和睡眠数据，自动推荐此方案；实时监控：通过设备监测夜间血氧水平，实时提醒'
  },
  {
    id: 'plan-asthma',
    category: '呼吸守护类',
    name: '哮喘护理配方',
    triggers: ['呼吸频率：喘息症状明显', '血氧：SpO2 < 90%', '吸烟史或过敏史'],
    dietPlan: ['低敏饮食：推荐低致敏食物，如低过敏鱼类、蔬菜', '避免乳制品、过多盐分和糖分'],
    exercisePlan: ['呼吸训练：如腹式呼吸、放松性瑜伽等，有助于缓解喘息症状'],
    dailyTasks: ['查看今日花粉与空气质量指数', '随身确认携带急救药物', '进行缩唇呼吸练习', '避免接触已知过敏原', '保持室内湿度适宜'],
    logic: '智能匹配：根据血氧、呼吸频率、吸烟史等数据自动推荐此方案；动态调整：根据呼吸情况和治疗进展调整饮食和运动方案'
  },

  // 6. 康复护理类
  {
    id: 'plan-recovery',
    category: '康复护理类',
    name: '术后与病后恢复配方',
    triggers: ['体温记录：有发热记录后恢复正常', 'HRV：极低', '步数：低于日常平均值', '药品订单：正在服药或手动标记为“康复期”'],
    dietPlan: ['高蛋白流食：易消化的优质蛋白（如蒸蛋、鱼肉泥）', '增加富含维生素C的果蔬，帮助组织修复'],
    exercisePlan: ['循序渐进的运动：不设定硬性运动时长，基于主观疲劳度（RPE）控制，推荐床边伸展或室内散步'],
    dailyTasks: ['早晚各测量一次体温', '摄入高蛋白易消化食物', '床边缓慢活动或伸展10分钟', '按时服用药物', '记录任何身体不适症状'],
    logic: '智能匹配：自动识别康复期用户，结合体温、HRV和用药记录推荐此方案；动态调整：根据体温、步数和用药数据，灵活调整运动和饮食推荐'
  },
  {
    id: 'plan-postpartum',
    category: '康复护理类',
    name: '产后恢复配方',
    triggers: ['体温：产后体温异常', '步数：运动量低于日常', '药物：处于哺乳期并且存在不良反应'],
    dietPlan: ['高铁高钙饮食：推荐富含铁、钙的食物（如菠菜、牛奶、豆腐）', '增加优质蛋白（如鸡胸肉、牛肉）'],
    exercisePlan: ['产后恢复运动：如盆底肌锻炼、瑜伽、步行等低强度运动，逐渐增加强度'],
    dailyTasks: ['进行盆底肌训练（凯格尔运动）', '补充钙剂或铁剂', '保证至少30分钟午休', '摄入优质蛋白', '保持心情愉悦，与家人交流'],
    logic: '智能匹配：根据产后用户的体温、步数和用药数据，推荐此方案；动态调整：根据产后恢复情况自动调整饮食和运动方案'
  }
];

export const MOCK_USERS: User[] = [
  {
    id: 'u1',
    name: '陈伯 (Robert)',
    role: '长辈',
    age: 68,
    avatar: 'https://picsum.photos/id/1005/200/200',
    healthScore: 72,
    activePlanId: 'plan-bp', // Assigned Hypertension Plan
    metrics: {
      heartRate: { label: '心率', value: 78, unit: 'bpm', status: 'normal', trend: 'stable', lastUpdated: '10分钟前' },
      bloodPressure: { label: '血压', value: '135/85', unit: 'mmHg', status: 'warning', trend: 'up', lastUpdated: '2小时前' },
      spO2: { label: '血氧', value: 96, unit: '%', status: 'normal', trend: 'stable', lastUpdated: '10分钟前' },
      sleep: { label: '睡眠', value: 5.5, unit: '小时', status: 'warning', trend: 'down', lastUpdated: '今天' },
    },
    risks: [
      {
        condition: '高血压预警',
        level: RiskLevel.MODERATE,
        probability: 65,
        description: '过去7天血压读数持续偏高，存在波动风险。',
        intervention: '建议减少盐分摄入，并每天进行20分钟散步。'
      }
    ],
    trends: {
      heartRate: [
        { day: '周一', value: 72 }, { day: '周二', value: 75 }, { day: '周三', value: 74 }, { day: '周四', value: 79 }, { day: '周五', value: 78 }, { day: '周六', value: 76 }, { day: '周日', value: 78 }
      ],
      bloodPressure: [
        { day: '周一', value: 120 }, { day: '周二', value: 122 }, { day: '周三', value: 125 }, { day: '周四', value: 130 }, { day: '周五', value: 132 }, { day: '周六', value: 134 }, { day: '周日', value: 135 }
      ]
    }
  },
  {
    id: 'u2',
    name: '陈莎拉 (Sarah)',
    role: '本人',
    age: 42,
    avatar: 'https://picsum.photos/id/1011/200/200',
    healthScore: 88,
    activePlanId: 'plan-sleep', // Assigned Sleep Plan
    metrics: {
      heartRate: { label: '心率', value: 65, unit: 'bpm', status: 'normal', trend: 'down', lastUpdated: '5分钟前' },
      bloodPressure: { label: '血压', value: '118/76', unit: 'mmHg', status: 'normal', trend: 'stable', lastUpdated: '4小时前' },
      spO2: { label: '血氧', value: 99, unit: '%', status: 'normal', trend: 'stable', lastUpdated: '5分钟前' },
      sleep: { label: '睡眠', value: 7.2, unit: '小时', status: 'normal', trend: 'up', lastUpdated: '今天' },
    },
    risks: [],
    trends: {
      heartRate: [
        { day: '周一', value: 68 }, { day: '周二', value: 66 }, { day: '周三', value: 65 }, { day: '周四', value: 69 }, { day: '周五', value: 64 }, { day: '周六', value: 63 }, { day: '周日', value: 65 }
      ],
      bloodPressure: [
        { day: '周一', value: 118 }, { day: '周二', value: 119 }, { day: '周三', value: 117 }, { day: '周四', value: 118 }, { day: '周五', value: 120 }, { day: '周六', value: 118 }, { day: '周日', value: 118 }
      ]
    }
  },
  {
    id: 'u3',
    name: '李明 (Mike)',
    role: '伴侣',
    age: 45,
    avatar: 'https://picsum.photos/id/1025/200/200',
    healthScore: 65,
    activePlanId: 'plan-spo2', // Assigned Respiratory Plan
    metrics: {
      heartRate: { label: '心率', value: 82, unit: 'bpm', status: 'warning', trend: 'up', lastUpdated: '1分钟前' },
      bloodPressure: { label: '血压', value: '125/82', unit: 'mmHg', status: 'normal', trend: 'stable', lastUpdated: '3小时前' },
      spO2: { label: '血氧', value: 93, unit: '%', status: 'warning', trend: 'down', lastUpdated: '1分钟前' },
      sleep: { label: '睡眠', value: 6.0, unit: '小时', status: 'warning', trend: 'stable', lastUpdated: '今天' },
    },
    risks: [
      {
        condition: '低血氧风险',
        level: RiskLevel.HIGH,
        probability: 80,
        description: '夜间血氧多次低于94%，建议关注呼吸健康。',
        intervention: '进行呼吸肌训练，避免仰卧睡眠。'
      }
    ],
    trends: {
      heartRate: [
        { day: '周一', value: 78 }, { day: '周二', value: 80 }, { day: '周三', value: 82 }, { day: '周四', value: 81 }, { day: '周五', value: 83 }, { day: '周六', value: 82 }, { day: '周日', value: 82 }
      ],
      bloodPressure: [
        { day: '周一', value: 124 }, { day: '周二', value: 125 }, { day: '周三', value: 125 }, { day: '周四', value: 126 }, { day: '周五', value: 125 }, { day: '周六', value: 124 }, { day: '周日', value: 125 }
      ]
    }
  }
];

export const MOCK_DEVICES: Device[] = [
  {
    id: 'd1',
    name: 'Apple Watch Series 8',
    type: DeviceType.WATCH,
    status: DeviceStatus.CONNECTED,
    batteryLevel: 64,
    lastSync: '刚刚'
  },
  {
    id: 'd2',
    name: '欧姆龙 (Omron) 血压计',
    type: DeviceType.BP_MONITOR,
    status: DeviceStatus.DISCONNECTED,
    batteryLevel: 12,
    lastSync: '昨天'
  },
  {
    id: 'd3',
    name: 'Withings 智能秤',
    type: DeviceType.SCALE,
    status: DeviceStatus.CONNECTED,
    batteryLevel: 88,
    lastSync: '今天, 8:00 AM'
  }
];