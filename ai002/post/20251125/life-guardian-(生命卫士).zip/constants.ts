import { User, HealthMetric, DeviceType, Alert, DailyTask, RiskProfile, HealthForecast, Medicine } from './types';

export const CURRENT_USER: User = {
  id: 'u1',
  name: '张伟',
  avatar: 'https://picsum.photos/200/200',
  age: 45,
  gender: 'Male',
  height: 175,
  weight: 80,
  conditions: ['高血压I级', '轻度脂肪肝'],
  role: 'Self'
};

export const FAMILY_MEMBERS: User[] = [
  CURRENT_USER,
  {
    id: 'u2',
    name: '父亲',
    avatar: 'https://picsum.photos/201/201',
    age: 72,
    gender: 'Male',
    height: 170,
    weight: 65,
    conditions: ['房颤', '糖尿病'],
    role: 'Family'
  }
];

export const RISK_PROFILE: RiskProfile = {
  cvdRisk: 'Medium',
  diabetesRisk: 'Low',
  sleepQuality: 'Fair',
  healthScore: 88
};

// New: Health Forecast based on "Algorithms"
export const TODAY_FORECAST: HealthForecast = {
  energyScore: 65,
  status: 'Fatigued',
  drivingFactors: ['昨夜深睡不足', '晨间HRV偏低'],
  suggestion: '今日身体机能略有下降，建议避免高强度无氧运动，午间安排20分钟小憩。'
};

// New: Medicine Inventory
export const MEDICINE_CABINET: Medicine[] = [
  { 
    id: 'm1', 
    name: '苯磺酸氨氯地平片', 
    dosage: '5mg x 1片/天', 
    stock: 4, 
    totalStock: 28, 
    expiryDate: '2025-06',
    tags: ['高血压', '处方药']
  },
  { 
    id: 'm2', 
    name: '二甲双胍缓释片', 
    dosage: '0.5g x 2片/天', 
    stock: 45, 
    totalStock: 60, 
    expiryDate: '2024-12',
    tags: ['糖尿病']
  }
];

// User has slightly high BP today - proactive scenario
export const MOCK_METRICS: HealthMetric[] = [
  { 
    id: '1', 
    title: '心率', 
    value: '78', 
    unit: 'bpm', 
    status: 'Normal', 
    icon: 'Heart', 
    color: 'text-red-500', 
    date: '10:00', 
    trend: 'stable',
    history: [
      { time: '06:00', value: 65 }, { time: '08:00', value: 72 }, { time: '10:00', value: 78 }
    ],
    analysis: '心率处于正常范围。运动后恢复速度良好，心脏负荷正常。',
    recommendations: ['保持当前运动频率', '关注静息心率变化']
  },
  { 
    id: '2', 
    title: '血压', 
    value: '142/91', 
    unit: 'mmHg', 
    status: 'Warning', 
    icon: 'Activity', 
    color: 'text-blue-500', 
    date: '09:30', 
    trend: 'up',
    history: [
      { time: '周一', value: 128, value2: 82 },
      { time: '周二', value: 130, value2: 85 },
      { time: '周三', value: 135, value2: 88 },
      { time: '昨日', value: 138, value2: 89 },
      { time: '今日', value: 142, value2: 91 }
    ],
    analysis: '检测到收缩压呈现连续上升趋势，且今日读数超出正常范围（<140/90）。算法分析可能与近期“睡眠质量差”及“运动量不足”有关。',
    recommendations: [
      '立即静坐休息 10 分钟后复测',
      '今日饮食请严格控制盐分摄入（<5g）',
      '如复测仍高于 140/90，建议启动视频医生咨询'
    ]
  },
  { 
    id: '3', 
    title: '血氧', 
    value: '98', 
    unit: '%', 
    status: 'Normal', 
    icon: 'Droplet', 
    color: 'text-cyan-500', 
    date: '10:00', 
    trend: 'stable',
     history: [
      { time: '08:00', value: 97 }, { time: '09:00', value: 98 }, { time: '10:00', value: 98 }
    ]
  },
  { 
    id: '4', 
    title: '睡眠', 
    value: '6h 15m', 
    unit: '', 
    status: 'Warning', 
    icon: 'Moon', 
    color: 'text-indigo-500', 
    date: '昨晚', 
    trend: 'down',
    analysis: '深睡比例不足 15%，属于低质量睡眠。可能导致次日血压波动。',
    recommendations: ['尝试睡前温水泡脚', '避免睡前查看手机']
  },
  { id: '5', title: '体温', value: '36.5', unit: '°C', status: 'Normal', icon: 'Thermometer', color: 'text-orange-500', date: '08:00', trend: 'stable' },
  { id: '6', title: '血糖', value: '5.8', unit: 'mmol/L', status: 'Normal', icon: 'Utensils', color: 'text-pink-500', date: '空腹', trend: 'up' },
];

export const ACTIVE_ALERTS: Alert[] = [
  {
    id: 'a1',
    type: 'Warning',
    message: '监测到您的血压偏高 (142/91)，且今日尚未记录服药。',
    actionLabel: '确认已服药',
    actionType: 'measure',
    timestamp: '09:35'
  }
];

export const DAILY_TASKS: DailyTask[] = [
  { id: 't1', title: '服用降压药', description: '苯磺酸氨氯地平片 5mg', type: 'medication', completed: false, time: '08:00', urgent: true },
  { id: 't2', title: '血压测量', description: '早晨空腹测量', type: 'measurement', completed: true, time: '09:30' },
  { id: 't3', title: '有氧运动', description: '快走或慢跑 30分钟', type: 'exercise', completed: false, time: '17:00' },
  { id: 't4', title: '睡前心电监测', description: '佩戴心电贴监测睡眠', type: 'measurement', completed: false, time: '22:00' },
];

export const MY_DEVICES = [
  { name: DeviceType.WATCH, status: '已连接', battery: 80 },
  { name: DeviceType.ECG_STICKER, status: '未佩戴', battery: 0 },
  { name: DeviceType.BP_MONITOR, status: '离线', battery: 45 },
];

export const HEART_RATE_DATA = [
  { time: '00:00', value: 65 },
  { time: '04:00', value: 62 },
  { time: '08:00', value: 75 },
  { time: '09:30', value: 88 }, // Peak during BP measurement
  { time: '12:00', value: 80 },
  { time: '16:00', value: 76 },
];