import React, { useState, useEffect } from 'react';
import { FileText, ChevronRight, ClipboardList, TrendingUp, Apple, Dumbbell, Activity, HeartPulse, Brain, Pill, ShoppingBag, Check, ChefHat, Play, Clock, Calendar, Wind, Smile, X, Moon, Volume2, CloudRain, Pause, Music, BarChart as BarChartIcon, Users, AlertTriangle, CheckCircle2, ArrowRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie } from 'recharts';
import { RISK_PROFILE, MEDICINE_CABINET, FAMILY_MEMBERS } from '../constants';
import FullScreenPage from '../components/FullScreenPage';

const Health: React.FC = () => {
  const [refillStatus, setRefillStatus] = useState<Record<string, boolean>>({});
  const [activePlan, setActivePlan] = useState<'diet' | 'exercise' | 'sleep' | null>(null);
  const [activeQuestionnaire, setActiveQuestionnaire] = useState<string | null>(null);
  
  // Report States
  const [activeReport, setActiveReport] = useState<'weekly' | 'monthly' | 'family' | null>(null);

  const [showBreathing, setShowBreathing] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [breathCount, setBreathCount] = useState(0);

  // Sleep Lab States
  const [smartWake, setSmartWake] = useState(true);
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);

  const handleRefill = (id: string) => {
    setRefillStatus(prev => ({ ...prev, [id]: true }));
    setTimeout(() => { }, 3000); // Simulate API
  };

  // Breathing Exercise Logic
  useEffect(() => {
    let interval: any;
    if (showBreathing) {
        let cycle = 0;
        const runCycle = () => {
            setBreathPhase('Inhale');
            setTimeout(() => {
                setBreathPhase('Hold');
                setTimeout(() => {
                    setBreathPhase('Exhale');
                    setTimeout(() => {
                        cycle++;
                        setBreathCount(cycle);
                        if (showBreathing) runCycle();
                    }, 4000); // Exhale 4s
                }, 2000); // Hold 2s
            }, 4000); // Inhale 4s
        };
        runCycle();
    }
    return () => clearTimeout(interval);
  }, [showBreathing]);

  const questionnaires = [
    { title: '饮食筛查问卷_湘', status: '待完成', color: 'text-orange-500' },
    { title: '基础初筛睡眠障碍问卷', status: '已完成', color: 'text-green-500' },
    { title: '心脑血管风险评估', status: '建议重测', color: 'text-red-500' },
  ];

  const getRiskColor = (risk: string) => {
      if (risk === 'High') return 'text-red-500 bg-red-50 border-red-100';
      if (risk === 'Medium') return 'text-orange-500 bg-orange-50 border-orange-100';
      return 'text-green-500 bg-green-50 border-green-100';
  };

  // --- Sub-Page Renderers ---
  
  // 1. Weekly Report - Focus on Adherence & Short term trends
  const renderWeeklyReport = () => {
    const weeklyBP = [
        { day: '周一', sys: 128, dia: 82 }, { day: '周二', sys: 130, dia: 85 },
        { day: '周三', sys: 135, dia: 88 }, { day: '周四', sys: 132, dia: 84 },
        { day: '周五', sys: 138, dia: 89 }, { day: '周六', sys: 142, dia: 91 },
        { day: '周日', sys: 136, dia: 86 },
    ];
    const adherenceData = [
        { name: 'Completed', value: 85, color: '#10b981' },
        { name: 'Missed', value: 15, color: '#e5e7eb' },
    ];

    return (
        <FullScreenPage title="健康周报 (第42周)" onClose={() => setActiveReport(null)}>
            <div className="p-4 space-y-6">
                {/* Header Summary */}
                <div className="bg-white p-5 rounded-2xl shadow-sm border-l-4 border-orange-500">
                    <h2 className="font-bold text-gray-900 text-lg mb-1">本周重点关注</h2>
                    <p className="text-sm text-gray-600 leading-relaxed">
                        本周血压呈现<span className="text-orange-600 font-bold">上升趋势</span>，尤其在周末达到峰值 (142/91)。关联分析显示，周末服药时间有推迟现象。
                    </p>
                </div>

                {/* Trend Chart */}
                <div className="bg-white p-4 rounded-2xl shadow-sm">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center">
                        <Activity size={18} className="mr-2 text-blue-500" />
                        血压波动趋势
                    </h3>
                    <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={weeklyBP}>
                                <defs>
                                    <linearGradient id="colorBp" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#f97316" stopOpacity={0.2}/>
                                        <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                                <Tooltip contentStyle={{borderRadius: '10px'}} />
                                <Area type="monotone" dataKey="sys" stroke="#f97316" fillOpacity={1} fill="url(#colorBp)" />
                                <Area type="monotone" dataKey="dia" stroke="#3b82f6" fillOpacity={0} />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Adherence / Compliance */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-2xl shadow-sm flex flex-col items-center justify-center">
                        <div className="relative w-24 h-24">
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={adherenceData} innerRadius={35} outerRadius={45} paddingAngle={5} dataKey="value">
                                        {adherenceData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                </PieChart>
                            </ResponsiveContainer>
                            <div className="absolute inset-0 flex items-center justify-center flex-col">
                                <span className="text-xl font-bold text-emerald-600">85%</span>
                            </div>
                        </div>
                        <span className="text-xs font-medium text-gray-500 mt-2">服药依从性</span>
                    </div>
                    
                    <div className="bg-white p-4 rounded-2xl shadow-sm flex flex-col justify-center space-y-3">
                        <div className="text-xs text-gray-500">运动达标天数</div>
                        <div className="flex items-baseline space-x-1">
                            <span className="text-3xl font-bold text-blue-600">4</span>
                            <span className="text-sm text-gray-400">/7 天</span>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-1.5">
                            <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: '57%' }}></div>
                        </div>
                    </div>
                </div>

                {/* Action Items */}
                <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                    <h3 className="font-bold text-blue-900 mb-3 text-sm">下周纠偏计划</h3>
                    <ul className="space-y-2">
                         <li className="flex items-start space-x-2 text-sm text-blue-800">
                             <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
                             <span>设置“强提醒”模式，确保周末早晨 08:00 准时服药。</span>
                         </li>
                         <li className="flex items-start space-x-2 text-sm text-blue-800">
                             <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
                             <span>增加 2 次 30分钟的晚间快走。</span>
                         </li>
                    </ul>
                </div>
            </div>
        </FullScreenPage>
    );
  };

  // 2. Monthly Report - Focus on Scores & Organ Systems
  const renderMonthlyReport = () => {
      const dimensions = [
          { name: '心血管', score: 75, color: 'bg-orange-500' },
          { name: '睡眠', score: 60, color: 'bg-indigo-500' },
          { name: '代谢', score: 90, color: 'bg-green-500' },
          { name: '情绪', score: 85, color: 'bg-teal-500' },
          { name: '活力', score: 70, color: 'bg-blue-500' },
      ];

      return (
        <FullScreenPage title="月度健康解读 (10月)" onClose={() => setActiveReport(null)}>
            <div className="p-4 space-y-6">
                {/* Big Score Card */}
                <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-6 text-white shadow-lg text-center relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-12 opacity-10 bg-white rounded-full translate-x-1/2 -translate-y-1/2"></div>
                    <p className="text-indigo-200 font-medium mb-2">综合健康评分</p>
                    <h1 className="text-6xl font-bold mb-4">78</h1>
                    <div className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-sm">
                        击败了全国 65% 的同龄男性
                    </div>
                </div>

                {/* Dimension Breakdown */}
                <div className="bg-white rounded-2xl p-5 shadow-sm">
                    <h3 className="font-bold text-gray-900 mb-4">五维健康画像</h3>
                    <div className="space-y-4">
                        {dimensions.map((dim, idx) => (
                            <div key={idx}>
                                <div className="flex justify-between text-sm mb-1">
                                    <span className="font-medium text-gray-700">{dim.name}</span>
                                    <span className="font-bold text-gray-900">{dim.score}分</span>
                                </div>
                                <div className="w-full bg-gray-100 rounded-full h-2">
                                    <div 
                                        className={`h-2 rounded-full ${dim.color}`} 
                                        style={{ width: `${dim.score}%` }}
                                    ></div>
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="mt-4 pt-4 border-t border-gray-100 text-xs text-gray-500 leading-relaxed">
                        <strong>分析：</strong> 您的代谢系统（血糖、血脂）控制良好，但“睡眠”是明显的短板，直接拉低了整体评分，并可能对“心血管”造成潜在压力。
                    </div>
                </div>

                {/* Doctor's Note */}
                <div className="bg-white rounded-2xl p-1 shadow-sm border border-indigo-50">
                    <div className="flex items-center space-x-3 p-3 bg-indigo-50 rounded-t-xl">
                        <img src="https://picsum.photos/101/101" className="w-10 h-10 rounded-full border border-white" />
                        <div>
                            <div className="font-bold text-gray-900 text-sm">王主任的复盘</div>
                            <div className="text-xs text-gray-500">三甲心内科副主任医师</div>
                        </div>
                    </div>
                    <div className="p-4 text-sm text-gray-700 leading-relaxed">
                        “张先生，这出个月的报告我看过了。虽然血压偶有波动，但不用过度紧张。重点还是在改善睡眠质量上。下个月建议尝试增加镁的摄入（如深色蔬菜），并坚持使用APP里的助眠白噪音功能。药物方案维持不变。”
                    </div>
                </div>
            </div>
        </FullScreenPage>
      );
  };

  // 3. Family Health Report - Focus on Guardian Role
  const renderFamilyReport = () => (
    <FullScreenPage title="家庭健康总览" onClose={() => setActiveReport(null)}>
        <div className="p-4 space-y-4">
            {/* Summary Header */}
            <div className="bg-blue-600 rounded-2xl p-6 text-white shadow-lg flex justify-between items-center">
                <div>
                    <h2 className="font-bold text-lg">家庭安全指数</h2>
                    <p className="text-blue-100 text-xs mt-1">全家 2 人，整体状况平稳</p>
                </div>
                <div className="text-4xl font-bold">92<span className="text-lg opacity-80">%</span></div>
            </div>

            {/* Family Members Cards */}
            {FAMILY_MEMBERS.map((member) => {
                const isDad = member.id === 'u2'; // Mock
                const riskLevel = isDad ? 'High' : 'Medium'; 
                const riskColor = riskLevel === 'High' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-orange-50 text-orange-600 border-orange-100';

                return (
                    <div key={member.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                        <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center space-x-3">
                                <img src={member.avatar} className="w-12 h-12 rounded-full object-cover" />
                                <div>
                                    <div className="font-bold text-gray-900">{member.name}</div>
                                    <div className="text-xs text-gray-500">{member.age}岁 • {member.conditions.join(', ')}</div>
                                </div>
                            </div>
                            <div className={`px-2 py-1 rounded-lg text-xs font-bold border ${riskColor}`}>
                                {riskLevel === 'High' ? '需关注' : '平稳'}
                            </div>
                        </div>

                        {/* Specific Issues */}
                        <div className="bg-gray-50 rounded-xl p-3 space-y-2">
                             {isDad ? (
                                 <>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-600">房颤监测</span>
                                        <span className="text-red-500 font-bold flex items-center"><AlertTriangle size={12} className="mr-1"/> 2次异常</span>
                                    </div>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-600">血糖控制</span>
                                        <span className="text-green-600 font-bold">达标</span>
                                    </div>
                                 </>
                             ) : (
                                 <>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-600">血压控制</span>
                                        <span className="text-orange-500 font-bold">波动 (142/91)</span>
                                    </div>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-600">睡眠质量</span>
                                        <span className="text-indigo-500 font-bold">待改善</span>
                                    </div>
                                 </>
                             )}
                        </div>

                        <div className="mt-3 flex justify-end">
                            <button className="text-xs font-bold text-blue-600 flex items-center">
                                查看详细档案 <ArrowRight size={12} className="ml-1" />
                            </button>
                        </div>
                    </div>
                );
            })}
        </div>
    </FullScreenPage>
  );

  const renderDietPlan = () => (
    <FullScreenPage title="DASH 饮食计划" onClose={() => setActivePlan(null)}>
        <div className="p-4 space-y-6">
            <div className="bg-green-50 p-4 rounded-xl text-green-800 text-sm leading-relaxed border border-green-100">
                DASH（Dietary Approaches to Stop Hypertension）饮食是专为高血压人群设计的饮食模式，核心是“低钠高钾”。
            </div>
            
            <div>
                <h3 className="font-bold text-gray-900 mb-3">今日食谱推荐</h3>
                <div className="space-y-4">
                    <div className="flex items-start space-x-3 bg-white p-3 rounded-xl shadow-sm">
                        <div className="w-16 h-16 bg-gray-100 rounded-lg flex-shrink-0 flex items-center justify-center text-xs text-gray-400">早餐图</div>
                        <div>
                            <div className="font-bold text-gray-900">燕麦牛奶粥 + 煮鸡蛋</div>
                            <p className="text-xs text-gray-500 mt-1">热量: 350kcal | 钠: 120mg</p>
                            <p className="text-xs text-gray-500">贴士: 使用脱脂牛奶，不加糖。</p>
                        </div>
                    </div>
                     <div className="flex items-start space-x-3 bg-white p-3 rounded-xl shadow-sm">
                        <div className="w-16 h-16 bg-gray-100 rounded-lg flex-shrink-0 flex items-center justify-center text-xs text-gray-400">午餐图</div>
                        <div>
                            <div className="font-bold text-gray-900">清蒸鲈鱼 + 蒜蓉菠菜 + 杂粮饭</div>
                            <p className="text-xs text-gray-500 mt-1">热量: 550kcal | 钠: 300mg</p>
                            <p className="text-xs text-gray-500">贴士: 菠菜富含钾元素，有助于排钠。</p>
                        </div>
                    </div>
                </div>
            </div>

            <button className="w-full bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg flex items-center justify-center space-x-2">
                <ChefHat size={20} />
                <span>生成下周购物清单</span>
            </button>
        </div>
    </FullScreenPage>
  );

  const renderExercisePlan = () => (
    <FullScreenPage title="中等强度有氧运动" onClose={() => setActivePlan(null)}>
        <div className="p-4 space-y-6">
            <div className="relative rounded-2xl overflow-hidden shadow-lg h-48 bg-gray-800 flex items-center justify-center">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <Play size={48} className="text-white relative z-10 opacity-80" fill="currentColor" />
                <span className="absolute bottom-4 left-4 text-white font-bold text-lg z-10">跟练：30分钟降压快走</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="bg-orange-50 p-4 rounded-xl border border-orange-100">
                    <div className="flex items-center space-x-2 text-orange-600 mb-1">
                        <Clock size={16} />
                        <span className="font-bold text-sm">时长</span>
                    </div>
                    <div className="text-xl font-bold text-gray-900">30 <span className="text-xs font-normal text-gray-500">分钟</span></div>
                </div>
                <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                    <div className="flex items-center space-x-2 text-blue-600 mb-1">
                        <HeartPulse size={16} />
                        <span className="font-bold text-sm">目标心率</span>
                    </div>
                    <div className="text-xl font-bold text-gray-900">110-130 <span className="text-xs font-normal text-gray-500">bpm</span></div>
                </div>
            </div>

            <div>
                <h3 className="font-bold text-gray-900 mb-3">运动要点</h3>
                <ul className="space-y-3">
                    {['保持呼吸均匀，不要憋气', '摆臂幅度要大，带动全身', '如感头晕或心悸，立即停止'].map((item, i) => (
                        <li key={i} className="flex items-start space-x-3">
                            <div className="w-1.5 h-1.5 rounded-full bg-orange-400 mt-2 shrink-0"></div>
                            <span className="text-sm text-gray-700">{item}</span>
                        </li>
                    ))}
                </ul>
            </div>
            
            <button className="w-full bg-orange-500 text-white font-bold py-3 rounded-xl shadow-lg mt-4">
                开始记录运动
            </button>
        </div>
    </FullScreenPage>
  );

  const renderSleepLab = () => (
      <FullScreenPage title="AI 睡眠实验室" onClose={() => setActivePlan(null)}>
          <div className="p-4 space-y-6">
              <div className="bg-indigo-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-20">
                      <Moon size={100} />
                  </div>
                  <h2 className="text-2xl font-bold mb-1 relative z-10">昨夜睡眠分析</h2>
                  <div className="text-4xl font-bold text-indigo-200 relative z-10">6<span className="text-lg text-indigo-400">h</span> 15<span className="text-lg text-indigo-400">m</span></div>
                  <div className="mt-6 flex space-x-4 relative z-10">
                      <div>
                          <div className="text-xs text-indigo-300">深睡比例</div>
                          <div className="font-bold text-red-300">15% (偏低)</div>
                      </div>
                      <div>
                          <div className="text-xs text-indigo-300">入睡时长</div>
                          <div className="font-bold">25min</div>
                      </div>
                  </div>
                  
                  {/* Mock Graph */}
                  <div className="mt-6 h-16 flex items-end space-x-1 opacity-80">
                      {[30, 50, 80, 40, 60, 90, 40, 20, 50, 70, 30, 60].map((h, i) => (
                          <div key={i} className="flex-1 bg-indigo-400 rounded-t-sm" style={{ height: `${h}%`}}></div>
                      ))}
                  </div>
              </div>

              {/* Smart Wake */}
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                  <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center space-x-3">
                          <div className="p-2 bg-orange-100 text-orange-600 rounded-lg">
                              <Clock size={20} />
                          </div>
                          <div>
                              <div className="font-bold text-gray-900">智能唤醒</div>
                              <div className="text-xs text-gray-500">检测浅睡期，无痛起床</div>
                          </div>
                      </div>
                      <button 
                        onClick={() => setSmartWake(!smartWake)}
                        className={`w-12 h-7 rounded-full transition-colors relative ${smartWake ? 'bg-green-500' : 'bg-gray-200'}`}
                      >
                          <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform shadow-sm ${smartWake ? 'left-6' : 'left-1'}`}></div>
                      </button>
                  </div>
                  {smartWake && (
                      <div className="bg-gray-50 p-3 rounded-xl text-sm text-gray-600 flex justify-between items-center">
                          <span>设定最晚起床</span>
                          <span className="font-bold text-xl text-gray-900">07:30</span>
                      </div>
                  )}
                  <p className="text-xs text-gray-400 mt-2">AI 将在 07:00 - 07:30 之间寻找您的浅睡阶段，通过手表轻微震动将您唤醒，避免起床气。</p>
              </div>

              {/* White Noise Player */}
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center">
                      <Volume2 size={18} className="mr-2 text-blue-500" />
                      助眠白噪音
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                      <button 
                        onClick={() => setPlayingAudio(playingAudio === 'rain' ? null : 'rain')}
                        className={`p-4 rounded-xl border flex flex-col items-center justify-center transition-colors ${playingAudio === 'rain' ? 'bg-blue-50 border-blue-200 text-blue-600' : 'border-gray-100 text-gray-600'}`}
                      >
                          {playingAudio === 'rain' ? <Pause size={24} className="mb-2" /> : <CloudRain size={24} className="mb-2" />}
                          <span className="text-xs font-medium">雨夜</span>
                      </button>
                      <button 
                         onClick={() => setPlayingAudio(playingAudio === 'forest' ? null : 'forest')}
                         className={`p-4 rounded-xl border flex flex-col items-center justify-center transition-colors ${playingAudio === 'forest' ? 'bg-green-50 border-green-200 text-green-600' : 'border-gray-100 text-gray-600'}`}
                      >
                          {playingAudio === 'forest' ? <Pause size={24} className="mb-2" /> : <Music size={24} className="mb-2" />}
                          <span className="text-xs font-medium">森林</span>
                      </button>
                  </div>
                  {playingAudio && (
                      <div className="mt-3 flex items-center justify-center space-x-2 text-xs text-blue-500 animate-pulse">
                          <span>正在播放...检测到入睡后自动关闭</span>
                      </div>
                  )}
              </div>
          </div>
      </FullScreenPage>
  );

  const renderBreathingExercise = () => (
      <div className="fixed inset-0 z-[70] bg-[#1a2332] flex flex-col items-center justify-center text-white animate-fade-in-up">
          <button onClick={() => setShowBreathing(false)} className="absolute top-12 right-6 p-2 bg-white/10 rounded-full">
              <X size={24} />
          </button>
          
          <h2 className="text-2xl font-light mb-8 opacity-90">身心减压</h2>
          
          <div className="relative flex items-center justify-center w-64 h-64 mb-12">
              <div className={`absolute inset-0 rounded-full border border-blue-400/30 transition-all duration-[4000ms] ease-in-out ${breathPhase === 'Inhale' ? 'scale-110 opacity-100' : breathPhase === 'Exhale' ? 'scale-50 opacity-50' : 'scale-110 opacity-80'}`}></div>
              <div className={`absolute inset-4 rounded-full bg-gradient-to-b from-blue-500 to-indigo-600 shadow-2xl shadow-blue-500/50 transition-all duration-[4000ms] ease-in-out flex items-center justify-center ${breathPhase === 'Inhale' ? 'scale-100' : breathPhase === 'Exhale' ? 'scale-50' : 'scale-100'}`}>
                   <span className="text-3xl font-bold">{breathPhase === 'Inhale' ? '吸气' : breathPhase === 'Hold' ? '屏气' : '呼气'}</span>
              </div>
          </div>
          
          <p className="text-lg opacity-80 font-medium">
              {breathPhase === 'Inhale' ? '用鼻子深深吸气...' : breathPhase === 'Hold' ? '保持气息...' : '用嘴缓慢呼气...'}
          </p>

          <div className="absolute bottom-20 text-sm text-gray-400">
              已完成 {breathCount} 次循环
          </div>
      </div>
  );

  const renderQuestionnaire = () => (
    <FullScreenPage title={activeQuestionnaire || "健康问卷"} onClose={() => setActiveQuestionnaire(null)}>
        <div className="p-4 flex flex-col h-full">
            <div className="flex-1 space-y-6">
                 <div className="w-full h-2 bg-gray-100 rounded-full mb-6">
                    <div className="w-1/3 h-full bg-blue-500 rounded-full"></div>
                 </div>
                 <h2 className="text-xl font-bold text-gray-900">1. 您过去一周摄入腌制食品（如咸菜、腊肉）的频率是？</h2>
                 <div className="space-y-3">
                    {['从不', '每周 1-2 次', '每周 3-5 次', '几乎每天'].map(opt => (
                        <button key={opt} className="w-full p-4 text-left bg-white border border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 font-medium transition-colors">
                            {opt}
                        </button>
                    ))}
                 </div>
            </div>
            <div className="pt-4">
                <p className="text-center text-xs text-gray-400 mb-4">本问卷由湘雅医院提供专业支持</p>
            </div>
        </div>
    </FullScreenPage>
  );

  return (
    <div className="pb-24 bg-[#F2F2F7] min-h-screen">
      {activePlan === 'diet' && renderDietPlan()}
      {activePlan === 'exercise' && renderExercisePlan()}
      {activePlan === 'sleep' && renderSleepLab()}
      {activeReport === 'weekly' && renderWeeklyReport()}
      {activeReport === 'monthly' && renderMonthlyReport()}
      {activeReport === 'family' && renderFamilyReport()}
      
      {activeQuestionnaire && renderQuestionnaire()}
      {showBreathing && renderBreathingExercise()}

      <div className="bg-[#F2F2F7]/90 backdrop-blur-md pt-12 pb-4 px-4 sticky top-0 z-10 safe-top flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">健康画像</h1>
        <div className="flex items-center space-x-1 bg-white px-3 py-1 rounded-full shadow-sm">
            <span className="text-sm font-bold text-blue-600">{RISK_PROFILE.healthScore}</span>
            <span className="text-xs text-gray-400">/100</span>
        </div>
      </div>

      <div className="px-4 space-y-6">
        
        {/* Risk Assessment Radar */}
        <section>
            <div className="bg-white rounded-3xl p-5 shadow-sm">
                <h2 className="text-sm font-bold text-gray-900 mb-4 flex items-center">
                    <Activity size={16} className="mr-2 text-blue-500" />
                    当前风险评估
                </h2>
                <div className="grid grid-cols-2 gap-3">
                    <div className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${getRiskColor(RISK_PROFILE.cvdRisk)}`}>
                        <HeartPulse size={24} className="mb-2" />
                        <span className="text-xs font-medium opacity-70">心血管风险</span>
                        <span className="text-lg font-bold">{RISK_PROFILE.cvdRisk === 'Medium' ? '中风险' : RISK_PROFILE.cvdRisk === 'High' ? '高风险' : '低风险'}</span>
                    </div>
                    <div className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${getRiskColor(RISK_PROFILE.diabetesRisk)}`}>
                        <TrendingUp size={24} className="mb-2" />
                        <span className="text-xs font-medium opacity-70">糖尿病风险</span>
                        <span className="text-lg font-bold">{RISK_PROFILE.diabetesRisk === 'Medium' ? '中风险' : RISK_PROFILE.diabetesRisk === 'High' ? '高风险' : '低风险'}</span>
                    </div>
                    <div 
                        onClick={() => setActivePlan('sleep')}
                        className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center active:scale-95 transition-transform cursor-pointer ${getRiskColor(RISK_PROFILE.sleepQuality === 'Poor' ? 'High' : RISK_PROFILE.sleepQuality === 'Fair' ? 'Medium' : 'Low')}`}
                    >
                        <Brain size={24} className="mb-2" />
                        <span className="text-xs font-medium opacity-70">睡眠质量</span>
                        <span className="text-lg font-bold flex items-center">{RISK_PROFILE.sleepQuality === 'Poor' ? '差' : RISK_PROFILE.sleepQuality === 'Fair' ? '一般' : '优'} <ChevronRight size={14} className="ml-1" /></span>
                    </div>
                    <div className="p-3 rounded-2xl border border-gray-100 bg-gray-50 flex flex-col items-center justify-center text-center text-gray-400">
                         <span className="text-xs">更多风险维度</span>
                         <span className="text-xs">计算中...</span>
                    </div>
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-xl text-xs text-blue-700 leading-relaxed">
                    💡 建议：由于心血管风险评估为中风险，且近期血压波动，建议增加有氧运动频次，并严格控制盐分摄入。
                </div>
            </div>
        </section>

        {/* New Feature: Mental Health / Stress Management */}
        <section>
            <div className="flex justify-between items-center mb-3 px-1">
                <h2 className="text-lg font-bold text-gray-900 flex items-center">
                    <Smile className="mr-2 text-teal-500" size={20} />
                    身心状态
                </h2>
                <span className="text-xs text-gray-400">智能手表监测中</span>
            </div>
            <div className="bg-gradient-to-r from-teal-500 to-emerald-600 rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
                <Wind className="absolute right-[-10px] bottom-[-10px] opacity-20" size={80} />
                <div className="flex justify-between items-start relative z-10">
                    <div>
                        <div className="text-sm font-medium opacity-90">今日压力指数</div>
                        <div className="text-3xl font-bold mt-1">42 <span className="text-sm font-normal opacity-70">/ 适中</span></div>
                    </div>
                    <button 
                        onClick={() => setShowBreathing(true)}
                        className="px-3 py-1.5 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold flex items-center space-x-1 hover:bg-white/30 transition-colors"
                    >
                        <Play size={10} fill="currentColor" />
                        <span>呼吸训练</span>
                    </button>
                </div>
                <div className="mt-4 text-xs text-teal-100 relative z-10">
                    监测到上午 10:30 心率变异性(HRV)短暂降低，建议进行 1 分钟深呼吸放松。
                </div>
            </div>
        </section>

        {/* Scenario 2: Smart Medicine Cabinet */}
        <section>
          <div className="flex justify-between items-center mb-3 px-1">
             <h2 className="text-lg font-bold text-gray-900 flex items-center">
                 <Pill className="mr-2 text-indigo-500" size={20} />
                 智能药箱
             </h2>
             <button className="text-xs text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg font-medium">用药记录</button>
          </div>
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
             {MEDICINE_CABINET.map((med, idx) => {
                 const percentage = (med.stock / med.totalStock) * 100;
                 const isLow = percentage < 20;

                 return (
                    <div key={med.id} className="p-4 border-b border-gray-100 last:border-0">
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="font-bold text-gray-900">{med.name}</h3>
                                <p className="text-xs text-gray-500 mt-0.5">{med.dosage}</p>
                                <div className="flex space-x-1 mt-1.5">
                                    {med.tags.map(tag => (
                                        <span key={tag} className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{tag}</span>
                                    ))}
                                </div>
                            </div>
                            <div className="text-right">
                                <span className={`text-sm font-bold ${isLow ? 'text-red-500' : 'text-gray-900'}`}>{med.stock}</span>
                                <span className="text-xs text-gray-400">/{med.totalStock}</span>
                            </div>
                        </div>
                        {/* Progress Bar */}
                        <div className="mt-3 relative h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div 
                                className={`absolute left-0 top-0 h-full rounded-full ${isLow ? 'bg-red-500' : 'bg-green-500'}`} 
                                style={{ width: `${percentage}%` }}
                            />
                        </div>
                        {isLow && (
                            <div className="mt-3 flex items-center justify-between bg-red-50 p-2 rounded-lg">
                                {refillStatus[med.id] ? (
                                    <div className="flex items-center space-x-2 text-green-600 animate-fade-in-up">
                                        <Check size={16} />
                                        <span className="text-xs font-bold">续药申请已提交</span>
                                    </div>
                                ) : (
                                    <>
                                        <span className="text-xs text-red-700 font-medium">余量不足，建议及时续方</span>
                                        <button 
                                            onClick={() => handleRefill(med.id)}
                                            className="flex items-center space-x-1 bg-white text-red-600 px-3 py-1 rounded-full text-xs font-bold shadow-sm border border-red-100 active:scale-95 transition-transform"
                                        >
                                            <ShoppingBag size={12} />
                                            <span>一键续药</span>
                                        </button>
                                    </>
                                )}
                            </div>
                        )}
                    </div>
                 );
             })}
          </div>
        </section>

        {/* Reports Section (Redesigned) */}
        <section>
          <div className="flex justify-between items-center mb-3 px-1">
            <h2 className="text-lg font-bold text-gray-900">健康报表中心</h2>
            <button className="text-sm text-blue-600">历史归档</button>
          </div>
          <div className="grid grid-cols-1 gap-3">
             {/* Weekly Report Card */}
            <div 
                onClick={() => setActiveReport('weekly')}
                className="bg-white p-4 rounded-2xl shadow-sm flex justify-between items-center active:scale-95 transition-transform"
            >
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                        <BarChartIcon size={24} />
                    </div>
                    <div>
                        <h3 className="font-bold text-gray-900">健康周报</h3>
                        <p className="text-xs text-gray-500">本周血压波动需关注</p>
                    </div>
                </div>
                <div className="flex flex-col items-end">
                    <span className="text-[10px] text-gray-400">第42周</span>
                    <span className="mt-1 text-[10px] bg-red-50 text-red-600 px-2 py-0.5 rounded-full font-medium">依从性 85%</span>
                </div>
            </div>

            {/* Monthly Report Card */}
            <div 
                onClick={() => setActiveReport('monthly')}
                className="bg-white p-4 rounded-2xl shadow-sm flex justify-between items-center active:scale-95 transition-transform"
            >
                <div className="flex items-center space-x-4">
                    