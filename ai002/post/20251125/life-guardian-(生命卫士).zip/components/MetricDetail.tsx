import React, { useEffect, useRef } from 'react';
import { X, Share2, Brain, AlertTriangle, CheckCircle, ArrowRight, Video, Calendar } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';
import { HealthMetric } from '../types';

interface MetricDetailProps {
  metric: HealthMetric;
  onClose: () => void;
  onAskAI: () => void;
}

const MetricDetail: React.FC<MetricDetailProps> = ({ metric, onClose, onAskAI }) => {
  const isWarning = metric.status === 'Warning' || metric.status === 'Critical';
  const analysisRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to AI analysis if there is a warning
  useEffect(() => {
    if (isWarning && analysisRef.current) {
        setTimeout(() => {
            analysisRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 300); // Small delay to allow render/animation
    }
  }, [isWarning]);

  // Parse values for dual-value metrics like BP (e.g., "142/91")
  const isDualValue = metric.value.includes('/');
  const displayHistory = metric.history?.map(h => ({
      ...h,
      displayValue: h.value
  })) || [];

  return (
    <div className="fixed inset-0 z-50 bg-[#F2F2F7] flex flex-col animate-fade-in-up">
      {/* Header */}
      <div className="bg-white p-4 safe-top flex justify-between items-center shadow-sm z-10">
        <button onClick={onClose} className="p-2 -ml-2 text-gray-500 active:scale-95 transition-transform">
          <X size={24} />
        </button>
        <h2 className="font-bold text-lg text-gray-900">{metric.title}详细报告</h2>
        <button className="p-2 -mr-2 text-gray-500 active:scale-95 transition-transform">
          <Share2 size={24} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto pb-safe">
        <div className="p-4 space-y-4">
            {/* Status Card */}
            <div className={`rounded-3xl p-6 text-center relative overflow-hidden transition-colors duration-500 ${isWarning ? 'bg-gradient-to-br from-red-500 to-red-600' : 'bg-gradient-to-br from-blue-500 to-blue-600'} text-white shadow-lg`}>
                <p className="text-blue-100 font-medium mb-1">{metric.date} 测量结果</p>
                <div className="flex justify-center items-end space-x-2">
                    <h1 className="text-5xl font-bold tracking-tight">{metric.value}</h1>
                    <span className="text-lg font-medium opacity-80 mb-2">{metric.unit}</span>
                </div>
                <div className="mt-4 inline-flex items-center space-x-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full">
                    {isWarning ? <AlertTriangle size={16} /> : <CheckCircle size={16} />}
                    <span className="text-sm font-bold">{metric.status === 'Warning' ? '数值偏高' : '数值正常'}</span>
                </div>
            </div>

            {/* Chart */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-gray-900">历史趋势</h3>
                    <div className="flex space-x-2">
                        <span className="px-2 py-1 bg-gray-100 rounded-lg text-xs font-medium text-gray-600">近7天</span>
                    </div>
                </div>
                <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={displayHistory}>
                            <defs>
                                <linearGradient id="colorMetric" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={isWarning ? "#ef4444" : "#3b82f6"} stopOpacity={0.2}/>
                                    <stop offset="95%" stopColor={isWarning ? "#ef4444" : "#3b82f6"} stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                            <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#9ca3af'}} dy={10} />
                            <YAxis hide domain={['auto', 'auto']} />
                            <Tooltip 
                                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                                cursor={{ stroke: '#cbd5e1', strokeWidth: 1, strokeDasharray: '4 4' }}
                            />
                            <Area 
                                type="monotone" 
                                dataKey="value" 
                                stroke={isWarning ? "#ef4444" : "#3b82f6"} 
                                strokeWidth={3} 
                                fill="url(#colorMetric)" 
                                animationDuration={1000}
                            />
                            {/* Render secondary line for BP Diastolic if exists */}
                            {isDualValue && (
                                <Area 
                                    type="monotone" 
                                    dataKey="value2" 
                                    stroke={isWarning ? "#ef4444" : "#3b82f6"} 
                                    strokeWidth={3} 
                                    strokeOpacity={0.5}
                                    fill="transparent" 
                                />
                            )}
                            {isWarning && (
                                <ReferenceLine y={140} stroke="red" strokeDasharray="3 3" label={{ value: '上限', fill: 'red', fontSize: 10, position: 'right' }} />
                            )}
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* AI Analysis Report (The "Proactive" Core) */}
            <div ref={analysisRef} className="bg-white rounded-2xl p-5 shadow-sm border border-indigo-50 scroll-mt-24">
                <div className="flex items-center space-x-2 mb-3">
                    <div className="p-1.5 bg-indigo-100 rounded-lg text-indigo-600">
                        <Brain size={18} />
                    </div>
                    <h3 className="font-bold text-gray-900">AI 智能分析报告</h3>
                </div>
                <div className="text-sm text-gray-700 leading-relaxed bg-gray-50 p-3 rounded-xl">
                    {metric.analysis || '数据正常，请继续保持健康的生活习惯。'}
                </div>
                
                {metric.recommendations && (
                    <div className="mt-4 space-y-3">
                        <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wide">行动建议</h4>
                        {metric.recommendations.map((rec, idx) => (
                            <div key={idx} className="flex items-start space-x-3">
                                <div className={`mt-0.5 min-w-[16px] h-4 rounded-full flex items-center justify-center text-[10px] font-bold text-white ${idx === 0 && isWarning ? 'bg-red-500' : 'bg-blue-400'}`}>
                                    {idx + 1}
                                </div>
                                <p className="text-sm text-gray-800">{rec}</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Service Connection (From Data to Service) */}
            {isWarning && (
                <button className="w-full bg-white p-4 rounded-2xl shadow-sm border border-red-100 flex items-center justify-between active:scale-95 transition-transform">
                    <div className="flex items-center space-x-3">
                        <div className="p-3 bg-red-50 text-red-600 rounded-full">
                            <Video size={20} />
                        </div>
                        <div className="text-left">
                            <div className="font-bold text-gray-900">预约视频医生</div>
                            <div className="text-xs text-gray-500">数据异常？咨询专家解读</div>
                        </div>
                    </div>
                    <ArrowRight size={20} className="text-gray-300" />
                </button>
            )}

            <button 
                onClick={onAskAI}
                className="w-full bg-blue-600 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-blue-200 flex items-center justify-center space-x-2 active:scale-95 transition-transform"
            >
                <Brain size={20} />
                <span>询问 AI 助手详情</span>
            </button>
        </div>
      </div>
    </div>
  );
};

export default MetricDetail;