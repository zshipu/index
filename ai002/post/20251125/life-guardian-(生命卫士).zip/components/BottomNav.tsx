import React from 'react';
import { Home, Activity, MessageSquare, User } from 'lucide-react';
import { Tab } from '../types';

interface BottomNavProps {
  currentTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md border-t border-gray-200 safe-bottom pb-2 pt-2 z-50">
      <div className="flex justify-around items-center">
        <button
          onClick={() => onTabChange(Tab.HOME)}
          className={`flex flex-col items-center space-y-1 w-16 ${currentTab === Tab.HOME ? 'text-blue-600' : 'text-gray-400'}`}
        >
          <Home size={24} strokeWidth={currentTab === Tab.HOME ? 2.5 : 2} />
          <span className="text-[10px] font-medium">首页</span>
        </button>
        
        <button
          onClick={() => onTabChange(Tab.HEALTH)}
          className={`flex flex-col items-center space-y-1 w-16 ${currentTab === Tab.HEALTH ? 'text-blue-600' : 'text-gray-400'}`}
        >
          <Activity size={24} strokeWidth={currentTab === Tab.HEALTH ? 2.5 : 2} />
          <span className="text-[10px] font-medium">健康</span>
        </button>

        <button
          onClick={() => onTabChange(Tab.ASSISTANT)}
          className={`flex flex-col items-center space-y-1 w-16 ${currentTab === Tab.ASSISTANT ? 'text-blue-600' : 'text-gray-400'}`}
        >
          <div className={`p-1 rounded-full ${currentTab === Tab.ASSISTANT ? 'bg-blue-100' : ''}`}>
             <MessageSquare size={24} strokeWidth={currentTab === Tab.ASSISTANT ? 2.5 : 2} />
          </div>
          <span className="text-[10px] font-medium">AI助手</span>
        </button>

        <button
          onClick={() => onTabChange(Tab.PROFILE)}
          className={`flex flex-col items-center space-y-1 w-16 ${currentTab === Tab.PROFILE ? 'text-blue-600' : 'text-gray-400'}`}
        >
          <User size={24} strokeWidth={currentTab === Tab.PROFILE ? 2.5 : 2} />
          <span className="text-[10px] font-medium">我的</span>
        </button>
      </div>
    </div>
  );
};

export default BottomNav;