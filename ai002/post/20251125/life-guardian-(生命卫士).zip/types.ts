export enum Tab {
  HOME = 'home',
  HEALTH = 'health',
  ASSISTANT = 'assistant',
  PROFILE = 'profile',
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  age: number;
  gender: 'Male' | 'Female';
  height: number;
  weight: number;
  conditions: string[]; // e.g., 'Hypertension'
  role?: 'Self' | 'Family'; // Context for guardian features
}

export interface MetricHistoryPoint {
  time: string;
  value: number; // For single value metrics
  value2?: number; // For range metrics like BP (systolic/diastolic)
}

export interface HealthMetric {
  id: string;
  title: string;
  value: string;
  unit: string;
  status: 'Normal' | 'Warning' | 'Critical';
  icon: string;
  color: string;
  date: string;
  trend?: 'up' | 'down' | 'stable';
  history?: MetricHistoryPoint[]; // Added for detailed analysis
  analysis?: string; // Pre-calculated algorithmic analysis
  recommendations?: string[]; // Specific actionable items
}

export interface Alert {
  id: string;
  type: 'Critical' | 'Warning' | 'Info';
  message: string;
  actionLabel?: string;
  actionType?: 'measure' | 'consult' | 'read' | 'remind_family'; // Added remind_family
  timestamp: string;
}

export interface DailyTask {
  id: string;
  title: string;
  description: string;
  type: 'medication' | 'measurement' | 'exercise' | 'diet';
  completed: boolean;
  time: string;
  urgent?: boolean; // Highlight if linked to bad metric
}

export interface RiskProfile {
  cvdRisk: 'Low' | 'Medium' | 'High'; // Cardiovascular
  diabetesRisk: 'Low' | 'Medium' | 'High';
  sleepQuality: 'Good' | 'Fair' | 'Poor';
  healthScore: number;
}

export interface HealthForecast {
  energyScore: number; // 0-100
  status: 'High Energy' | 'Balanced' | 'Fatigued';
  drivingFactors: string[]; // e.g. "Good Sleep", "Low HRV"
  suggestion: string;
}

export interface Medicine {
  id: string;
  name: string;
  dosage: string;
  stock: number;
  totalStock: number;
  expiryDate: string;
  tags: string[]; // e.g. "Hypertension"
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum DeviceType {
  WATCH = 'Watch H1',
  ECG_STICKER = 'ECG Sticker',
  BP_MONITOR = 'BP Monitor 117',
  GLUCOSE = 'Glucose Meter'
}