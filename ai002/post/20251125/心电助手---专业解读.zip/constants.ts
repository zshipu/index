import { UserProfile, HealthMetric, Device, FamilyTask, SubscriptionPlan, RiskLevel, RiskReport, HealthPlan } from './types';

// --- Health Plans Data (Based on User's Excel) ---
export const HEALTH_PLANS: Record<string, HealthPlan> = {
  // 1. 慢病干预类 - 稳糖控糖
  'PLAN_SUGAR': {
    id: 'plan_sugar',
    category: '慢病干预类',
    title: '稳糖控糖配方',
    color: 'from-blue-500 to-cyan-500',
    diet: [
      '低GI/GL饮食策略：推荐全谷物、叶菜等低升糖指数食物。',
      '控制精制碳水摄入：减少白米饭、面条，增加荞麦、燕麦。',
      '进食顺序调整：先吃蔬菜，再吃蛋白质，最后吃主食。'
    ],
    exercise: [
      '餐后微动计划：餐后30-60分钟内进行低强度步行（15分钟）。',
      '简单的抗阻训练（深蹲、俯卧撑）提高胰岛素敏感性。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'diet', title: '全谷物早餐', desc: '燕麦片冲牛奶，搭配一个煮鸡蛋，避免白粥馒头。' },
      { time: '12:30', category: 'exercise', title: '餐后消食', desc: '午餐后不要立即午睡，散步15-20分钟平稳血糖。' },
      { time: '16:00', category: 'diet', title: '低升糖加餐', desc: '若有饥饿感，吃一小把原味坚果或半个苹果。' },
      { time: '20:00', category: 'check', title: '血糖监测', desc: '记录空腹或餐后2小时血糖，观察今日饮食影响。' }
    ],
    matchReason: '根据血糖及糖化血红蛋白数据自动推荐此方案，旨在平稳血糖波动。'
  },
  // 2. 慢病干预类 - 降压护航
  'PLAN_BP': {
    id: 'plan_bp',
    category: '慢病干预类',
    title: '降压护航配方',
    color: 'from-orange-500 to-red-500',
    diet: [
      'DASH饮食改良版：推荐高钾、高镁、高钙食物（如菠菜、香蕉、坚果）。',
      '强制限盐提醒：每日盐摄入量严格控制在 5g 以内。',
      '增加膳食纤维：多吃深色蔬菜和全谷物。'
    ],
    exercise: [
      '等长收缩训练：如靠墙静蹲（每日2次，每次2分钟），有助于降低静息血压。',
      '握力器训练：每日4组，每组2分钟。'
    ],
    dailyRoutine: [
      { time: '07:00', category: 'check', title: '晨间血压', desc: '起床排空后静坐5分钟测量血压，记录数值。' },
      { time: '08:00', category: 'diet', title: '高钾早餐', desc: '喝一杯低脂牛奶，搭配一根香蕉或一份菠菜蛋饼。' },
      { time: '15:00', category: 'exercise', title: '降压训练', desc: '完成2组靠墙静蹲（每组2分钟），辅助降压。' },
      { time: '19:00', category: 'diet', title: '清淡晚餐', desc: '晚餐严格控盐，避免腌制小菜和加工肉类。' }
    ],
    matchReason: '基于血压数据（收缩压/舒张压偏高）及心血管风险评估自动推荐。'
  },
  // 3. 慢病干预类 - 降脂护心
  'PLAN_LIPID': {
    id: 'plan_lipid',
    category: '慢病干预类',
    title: '降脂护心配方',
    color: 'from-yellow-500 to-amber-600',
    diet: [
      '富含Omega-3脂肪酸：推荐每周至少吃两次深海鱼（如三文鱼、沙丁鱼）。',
      '控制反式脂肪和饱和脂肪：少吃油炸食品、奶油蛋糕。',
      '增加植物固醇摄入：如豆类、坚果。'
    ],
    exercise: [
      '有氧运动：如快走、游泳、骑车等，至少30分钟/天，每周5次。',
      '减脂增肌：结合适量力量训练，提高基础代谢。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'diet', title: '优质脂肪', desc: '早餐加入一小勺亚麻籽粉或几颗核桃。' },
      { time: '18:00', category: 'exercise', title: '有氧燃脂', desc: '进行30分钟快走或慢跑，保持心率在燃脂区间。' },
      { time: '19:00', category: 'diet', title: '轻食晚餐', desc: '主食减半，增加深色蔬菜和清蒸鱼类。' }
    ],
    matchReason: '根据血脂数据（总胆固醇、LDL超标）及个人肥胖风险评估推荐。'
  },
  // 4. 慢病干预类 - 肝脏修复
  'PLAN_LIVER': {
    id: 'plan_liver',
    category: '慢病干预类',
    title: '肝脏修复配方',
    color: 'from-lime-500 to-green-600',
    diet: [
      '低脂、高纤维饮食：推荐富含膳食纤维的食物，如绿叶蔬菜、燕麦。',
      '增加抗氧化食物：如蓝莓、葡萄、西兰花，帮助肝脏排毒。',
      '严格戒酒：减轻肝脏代谢负担。'
    ],
    exercise: [
      '低强度有氧运动：如快步走、瑜伽等促进血液循环。',
      '避免过度剧烈运动：防止产生过多乳酸增加肝脏负担。'
    ],
    dailyRoutine: [
      { time: '07:30', category: 'habit', title: '空腹饮水', desc: '起床喝一杯温水，促进新陈代谢。' },
      { time: '12:00', category: 'diet', title: '护肝午餐', desc: '增加十字花科蔬菜（西兰花、花椰菜），帮助排毒。' },
      { time: '22:30', category: 'habit', title: '早睡养肝', desc: '尽量在23点前入睡，保证肝脏修复时间。' }
    ],
    matchReason: '结合肝功能数据（ALT/AST异常）和个人饮酒习惯推荐此方案。'
  },
  // 5. 身心调节类 - 助眠舒压
  'PLAN_SLEEP': {
    id: 'plan_sleep',
    category: '身心调节类',
    title: '助眠舒压配方',
    color: 'from-indigo-500 to-purple-600',
    diet: [
      '色氨酸强化：晚餐包含牛奶、小米粥或火鸡肉。',
      '镁元素补充：适量食用深色绿叶菜、香蕉、南瓜籽。',
      '下午3点后严禁摄入咖啡因（茶、咖啡、可乐）。'
    ],
    exercise: [
      '晚间舒缓瑜伽：睡前30分钟进行，避免剧烈出汗。',
      '4-7-8 呼吸法训练：降低皮质醇水平，激活副交感神经。'
    ],
    dailyRoutine: [
      { time: '15:00', category: 'habit', title: '咖啡截止', desc: '下午3点后停止饮用茶、咖啡等含咖啡因饮料。' },
      { time: '20:00', category: 'diet', title: '助眠晚餐', desc: '晚餐七分饱，可适量食用小米粥或热牛奶。' },
      { time: '21:30', category: 'habit', title: '屏幕戒断', desc: '将手机调至护眼模式，减少蓝光刺激。' },
      { time: '22:15', category: 'exercise', title: '呼吸放松', desc: '上床后进行3组 4-7-8 呼吸练习，快速入静。' }
    ],
    matchReason: '监测到深睡比例低、HRV持续偏低，且压力评估异常。'
  },
  // 6. 身心调节类 - 焦虑情绪调节
  'PLAN_ANXIETY': {
    id: 'plan_anxiety',
    category: '身心调节类',
    title: '焦虑情绪调节配方',
    color: 'from-violet-400 to-fuchsia-500',
    diet: [
      '高Omega-3饮食：增加鱼类、坚果、亚麻籽等食品，调节情绪波动。',
      '补充益生菌：酸奶或补剂，改善肠道菌群（脑肠轴）影响情绪。'
    ],
    exercise: [
      '放松训练：每日进行冥想或深呼吸练习。',
      '渐进式肌肉放松（PMR）：缓解身体紧张感。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'exercise', title: '晨间唤醒', desc: '进行5分钟正念冥想，设定今日积极意图。' },
      { time: '16:00', category: 'diet', title: '情绪零食', desc: '吃一小块黑巧克力或一把坚果，缓解下午焦虑。' },
      { time: '21:00', category: 'exercise', title: '肌肉放松', desc: '跟随音频进行渐进式肌肉放松（PMR）练习。' }
    ],
    matchReason: '根据情绪评分（焦虑、烦躁）和HRV数据（持续偏低）自动推荐。'
  },
  // 7. 身心调节类 - 情绪平衡
  'PLAN_MOOD': {
    id: 'plan_mood',
    category: '身心调节类',
    title: '情绪平衡配方',
    color: 'from-pink-400 to-rose-400',
    diet: [
      '富含维生素B族：瘦肉、全谷物、豆类，辅助神经系统健康。',
      '快乐食物：香蕉、黑巧克力（适量）帮助合成血清素。'
    ],
    exercise: [
      '轻度有氧运动：如户外散步、游泳、慢跑，促进多巴胺分泌。',
      '团体运动：增加社交互动，缓解孤独感。'
    ],
    dailyRoutine: [
      { time: '09:00', category: 'exercise', title: '户外阳光', desc: '户外散步20分钟，晒太阳促进血清素合成。' },
      { time: '12:30', category: 'diet', title: '活力午餐', desc: '选择富含维生素B的糙米饭和瘦肉。' },
      { time: '20:00', category: 'habit', title: '感恩日记', desc: '记录今天发生的3件小确幸，提升幸福感。' }
    ],
    matchReason: '根据HRV监测和情绪评分（抑郁倾向）数据自动推荐。'
  },
  // 8. 风险防御类 - 强心护脉
  'PLAN_HEART': {
    id: 'plan_heart',
    category: '风险防御类',
    title: '强心护脉配方',
    color: 'from-rose-600 to-red-700',
    diet: [
      '极低脂饮食：严格限制饱和脂肪酸。',
      '富含抗氧化物：大量摄入蓝莓、西红柿、胡萝卜。',
      '辅酶Q10食物来源：沙丁鱼、牛肉、花生。'
    ],
    exercise: [
      '限制性运动：仅推荐温和运动（散步、太极）。',
      '实时心率超限预警：心率超过安全阈值时强制休息。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'check', title: '晨脉监测', desc: '醒来后记录静息心率，观察是否有心律不齐。' },
      { time: '12:00', category: 'diet', title: '红心午餐', desc: '多吃西红柿（番茄红素）和深海鱼。' },
      { time: '18:00', category: 'exercise', title: '温和漫步', desc: '进行20分钟轻松散步，避免任何剧烈跑跳。' },
      { time: '20:00', category: 'check', title: '心电自测', desc: '使用手表或心电贴进行一次ECG测量。' }
    ],
    matchReason: '心电图发现异常波形，房颤概率评估偏高，需重点防护。'
  },
  // 9. 风险防御类 - 冠心病护理
  'PLAN_CORONARY': {
    id: 'plan_coronary',
    category: '风险防御类',
    title: '冠心病护理配方',
    color: 'from-red-700 to-red-900',
    diet: [
      '低胆固醇饮食：严格控制蛋黄、内脏摄入。',
      '高纤维溶脂：燕麦、豆类、苹果，帮助排出胆固醇。',
      '控制钠摄入：减轻心脏负荷。'
    ],
    exercise: [
      '康复性有氧：如慢速散步、太极，避免任何剧烈竞技运动。',
      '运动心率监控：严格控制在医生建议的靶心率范围内。'
    ],
    dailyRoutine: [
      { time: '07:30', category: 'habit', title: '按时服药', desc: '确认是否已服用医生开具的阿司匹林或他汀类药物。' },
      { time: '08:00', category: 'diet', title: '燕麦早餐', desc: '燕麦富含β-葡聚糖，有助于降低胆固醇。' },
      { time: '16:00', category: 'exercise', title: '太极/气功', desc: '进行15分钟太极练习，调理气息。' }
    ],
    matchReason: '根据心电图（ST段改变）、血脂异常及家族病史自动推荐。'
  },
  // 10. 代谢矫正类 - 痛风与高尿酸干预
  'PLAN_GOUT': {
    id: 'plan_gout',
    category: '代谢矫正类',
    title: '痛风/高尿酸干预',
    color: 'from-emerald-500 to-teal-600',
    diet: [
      '低嘌呤饮食：严禁动物内脏、海鲜浓汤、啤酒。',
      '碱化尿液食物：多吃黄瓜、樱桃、苏打水。',
      '强制饮水提醒：每日目标尿量 > 2000ml，促进尿酸排泄。'
    ],
    exercise: [
      '无酸运动：推荐慢走、太极、游泳。',
      '屏蔽无氧运动：避免快跑、举重等产生大量乳酸抑制尿酸排泄。'
    ],
    dailyRoutine: [
      { time: '09:00', category: 'habit', title: '饮水打卡', desc: '上午目标饮水 800ml，首选苏打水或白开水。' },
      { time: '12:00', category: 'diet', title: '低嘌呤餐', desc: '避免浓肉汤，蛋白质来源首选鸡蛋和牛奶。' },
      { time: '15:00', category: 'habit', title: '饮水打卡', desc: '下午目标饮水 800ml，促进尿酸排泄。' },
      { time: '19:00', category: 'exercise', title: '舒缓运动', desc: '散步或游泳，切忌剧烈无氧运动。' }
    ],
    matchReason: '基于尿酸数值偏高及生活习惯（饮酒/饮食）风险匹配。'
  },
  // 11. 代谢矫正类 - 糖尿病防控
  'PLAN_DIABETES': {
    id: 'plan_diabetes',
    category: '代谢矫正类',
    title: '糖尿病防控配方',
    color: 'from-cyan-600 to-blue-700',
    diet: [
      '严格低GI饮食：豆类、全谷物为主，拒绝精米白面。',
      '高膳食纤维：每餐必有绿叶菜，延缓血糖上升。',
      '定时定量：规律进餐，防止血糖大幅波动。'
    ],
    exercise: [
      '间歇性运动：如快慢交替走，提高代谢效率。',
      '饭后一小时运动：避免空腹运动导致低血糖。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'diet', title: '粗粮早餐', desc: '杂粮粥或全麦面包，搭配水煮蛋。' },
      { time: '13:00', category: 'exercise', title: '午后散步', desc: '午餐后休息30分钟，散步20分钟。' },
      { time: '19:00', category: 'diet', title: '蔬菜优先', desc: '晚餐先吃一碗绿叶菜，增加饱腹感。' }
    ],
    matchReason: '根据生化数据（空腹血糖升高）、家族史及久坐习惯推荐。'
  },
  // 12. 呼吸守护类 - 低血氧与呼吸健康
  'PLAN_OXYGEN': {
    id: 'plan_oxygen',
    category: '呼吸守护类',
    title: '呼吸健康配方',
    color: 'from-sky-400 to-blue-500',
    diet: [
      '富含维生素C：柑橘、猕猴桃，增强呼吸道免疫力。',
      '微量元素锌和镁：坚果、瘦肉，辅助呼吸肌功能。'
    ],
    exercise: [
      '呼吸肌训练：缩唇呼吸、腹式呼吸训练，增加肺活量。',
      '夜间低氧监测：睡眠时血氧低于90%触发强震动报警。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'exercise', title: '呼吸操', desc: '进行5分钟缩唇呼吸训练，锻炼肺功能。' },
      { time: '10:00', category: 'diet', title: '维C补充', desc: '吃一个猕猴桃或橙子，增强免疫力。' },
      { time: '22:00', category: 'check', title: '佩戴监测', desc: '确保佩戴手表入睡，开启血氧监测功能。' }
    ],
    matchReason: '结合血氧（SpO2 < 95%）和睡眠呼吸暂停风险推荐。'
  },
  // 13. 呼吸守护类 - 哮喘护理
  'PLAN_ASTHMA': {
    id: 'plan_asthma',
    category: '呼吸守护类',
    title: '哮喘护理配方',
    color: 'from-teal-400 to-cyan-500',
    diet: [
      '低敏饮食：避免海鲜、乳制品等常见过敏原。',
      '抗炎食物：姜黄、生姜、深海鱼。',
      '避免冷饮：防止诱发气道痉挛。'
    ],
    exercise: [
      '温和呼吸训练：瑜伽呼吸法，缓解喘息。',
      '环境控制：避免在寒冷干燥或污染环境中运动。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'habit', title: '峰流速仪', desc: '使用峰流速仪自测，记录PEF数值。' },
      { time: '12:00', category: 'diet', title: '温热饮食', desc: '食物保持温热，避免生冷刺激气道。' },
      { time: '20:00', category: 'habit', title: '清理环境', desc: '检查卧室是否有尘螨源（地毯、毛绒玩具）。' }
    ],
    matchReason: '根据呼吸频率、血氧及过敏/吸烟史自动推荐。'
  },
  // 14. 康复护理类 - 术后与病后恢复
  'PLAN_RECOVERY': {
    id: 'plan_recovery',
    category: '康复护理类',
    title: '术后/病后恢复',
    color: 'from-emerald-400 to-green-500',
    diet: [
      '高蛋白流食：蒸蛋、鱼泥、蛋白粉，易消化且促进伤口愈合。',
      '高维生素C：鲜榨果汁、蔬菜泥，促进组织修复。',
      '少量多餐：减轻消化系统负担。'
    ],
    exercise: [
      'RPE主观疲劳度控制：不设硬性指标，以不感疲劳为准。',
      '床边活动：简单的伸展、室内慢步走。'
    ],
    dailyRoutine: [
      { time: '08:00', category: 'diet', title: '营养早餐', desc: '蒸蛋羹或蛋白粉流食，补充优质蛋白。' },
      { time: '10:00', category: 'check', title: '体温监测', desc: '测量体温，观察是否有发热反复。' },
      { time: '16:00', category: 'exercise', title: '室内微动', desc: '在室内缓慢走动5-10分钟，防止血栓。' }
    ],
    matchReason: '自动识别康复期（体温异常记录、步数骤减）及用药记录推荐。'
  },
  // 15. 康复护理类 - 产后恢复
  'PLAN_POSTPARTUM': {
    id: 'plan_postpartum',
    category: '康复护理类',
    title: '产后恢复配方',
    color: 'from-pink-300 to-rose-300',
    diet: [
      '补铁补血：红肉、动物血、菠菜，改善贫血。',
      '高钙饮食：牛奶、豆腐，补充哺乳期流失钙质。',
      '优质蛋白：鸡胸肉、鱼肉，帮助身体复原。'
    ],
    exercise: [
      '盆底肌修复：凯格尔运动（Kegel Exercises）。',
      '核心恢复：温和的腹部呼吸训练，避免剧烈卷腹。'
    ],
    dailyRoutine: [
      { time: '09:00', category: 'diet', title: '补钙补铁', desc: '早餐包含牛奶和鸡蛋。' },
      { time: '11:00', category: 'exercise', title: '凯格尔', desc: '进行一组凯格尔运动，修复盆底肌。' },
      { time: '15:00', category: 'diet', title: '优质加餐', desc: '水果酸奶或鱼胶，补充胶原蛋白。' }
    ],
    matchReason: '根据产后体温、步数及特殊用药标签自动推荐。'
  }
};

export const MOCK_FAMILY: UserProfile[] = [
  {
    id: 'user_001',
    name: '我自己',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix',
    age: 35,
    relation: 'Me',
    healthScore: 85,
    riskLevel: RiskLevel.LOW,
    activePlanId: 'PLAN_SLEEP' // Fixed: Updated to match uppercase key
  },
  {
    id: 'user_002',
    name: '父亲',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aneka',
    age: 68,
    relation: 'Parent',
    healthScore: 62,
    riskLevel: RiskLevel.HIGH,
    activePlanId: 'PLAN_BP' // Fixed: Updated to match uppercase key
  },
  {
    id: 'user_003',
    name: '母亲',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jude',
    age: 65,
    relation: 'Parent',
    healthScore: 78,
    riskLevel: RiskLevel.MEDIUM,
    activePlanId: 'PLAN_SUGAR' // Fixed: Updated to match uppercase key
  }
];

export const REPORT_TEMPLATES: Record<string, RiskReport> = {
  'PREMATURE': {
    id: 'rpt_premature',
    title: '检测到【室性早搏】信号',
    riskLevel: RiskLevel.MEDIUM,
    shortDescription: '发现提前出现的心跳波形。偶发早搏常见于疲劳，频发需医学关注。',
    doctorName: '李国强 副主任医师',
    doctorAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=DoctorLi',
    fullDescription: '心电图捕捉到宽大畸形的QRS波群，且提前出现。这通常意味着心室在没有收到“上级指令”的情况下，自己“抢跑”跳了一次。这可能是心脏疲劳的抗议。',
    reasoning: [
      '生理性诱因：近期是否熬夜、焦虑、过量饮用浓茶或咖啡？',
      '电解质紊乱：腹泻或饮食不规律可能导致钾镁流失。',
      '病理风险：若伴有胸闷气短，不排除心肌炎或高血压心脏病的可能。'
    ],
    actionGuide: {
      red: '频发早搏（>10次/分）伴有晕厥感或剧烈胸痛 -> 立即前往急诊。',
      yellow: '感觉心悸，但无其他不适 -> 建议进行24小时动态心电图（Holter）排查。',
      green: '偶发心悸 -> 规律作息，补充富含钾的食物（如香蕉），减少压力。'
    }
  },
  'HIGH_BP': {
    id: 'rpt_bp',
    title: '检测到【血压偏高】',
    riskLevel: RiskLevel.HIGH,
    shortDescription: '收缩压/舒张压超出正常范围，需密切关注。',
    doctorName: '张敏 主任医师',
    doctorAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=DoctorZhang',
    fullDescription: '监测数据显示您的血压持续处于较高水平。高血压是心脑血管疾病的主要风险因素，长期不控制可能导致心脏和肾脏损伤。',
    reasoning: [
      '饮食因素：近期盐分或油脂摄入过高。',
      '情绪因素：近期压力较大或情绪激动。',
      '药物依从性：是否漏服降压药？'
    ],
    actionGuide: {
      red: '收缩压>180或舒张压>110，伴头痛呕吐 -> 立即急诊。',
      yellow: '血压波动 -> 每日早晚定时测量，记录数值就医咨询。',
      green: '日常管理 -> 低盐饮食，适量运动，按时服药。'
    }
  }
};

export const MOCK_METRICS: Record<string, HealthMetric[]> = {
  'user_001': [
    { type: 'heart_rate', label: '静息心率', value: 68, unit: 'BPM', status: 'normal', trend: [65, 66, 68, 70, 68, 67, 68], lastUpdate: '10分钟前' },
    { type: 'sleep', label: '睡眠时长', value: '5.2', unit: '小时', status: 'warning', trend: [6.5, 7, 5.5, 6, 5, 5.5, 5.2], lastUpdate: '今天' },
    { type: 'steps', label: '今日步数', value: 8432, unit: '步', status: 'normal', trend: [5000, 8000, 10000, 12000, 4000, 8000, 8432], lastUpdate: '实时' },
    { type: 'weight', label: '体重', value: 72.5, unit: 'kg', status: 'normal', trend: [73, 72.8, 72.6, 72.5, 72.5], lastUpdate: '昨天' }
  ],
  'user_002': [
    { type: 'heart_rate', label: '静息心率', value: 82, unit: 'BPM', status: 'warning', trend: [78, 80, 82, 85, 80, 81, 82], lastUpdate: '5分钟前' },
    { type: 'bp', label: '血压', value: '145/95', unit: 'mmHg', status: 'danger', trend: [130, 135, 140, 142, 145, 148, 145], lastUpdate: '30分钟前' },
    { type: 'spo2', label: '血氧', value: 94, unit: '%', status: 'warning', trend: [96, 95, 95, 94, 93, 94, 94], lastUpdate: '1小时前' },
    { type: 'ecg', label: '房颤风险', value: '高', unit: '', status: 'danger', trend: [], lastUpdate: '昨天' }
  ],
  'user_003': [
    { type: 'heart_rate', label: '静息心率', value: 75, unit: 'BPM', status: 'normal', trend: [72, 74, 75, 73, 75, 76, 75], lastUpdate: '15分钟前' },
    { type: 'sleep', label: '睡眠时长', value: '6.5', unit: '小时', status: 'warning', trend: [6, 6.5, 6, 7, 6, 5.5, 6.5], lastUpdate: '今天' }
  ]
};

export const MOCK_DEVICES: Device[] = [
  { id: 'dev_01', name: 'Apple Watch S8', type: 'watch', battery: 65, status: 'connected', lastSync: '刚刚', image: '⌚️' },
  { id: 'dev_02', name: 'Omron 血压计', type: 'bp_monitor', battery: 100, status: 'disconnected', lastSync: '昨天', image: '🩺' },
  { id: 'dev_03', name: 'Holter 心电贴', type: 'ecg_patch', battery: 20, status: 'syncing', lastSync: '同步中...', image: '🩹' }
];

export const MOCK_TASKS: FamilyTask[] = [
  { id: 't1', title: '全家步数挑战', target: '30,000步/天', progress: 75, participants: ['user_001', 'user_002', 'user_003'] },
  { id: 't2', title: '父亲血压打卡', target: '连续7天', progress: 42, participants: ['user_002'] }
];

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  { name: '基础版', price: '免费', features: ['数据记录', '基础报表', '设备连接'], isActive: true },
  { name: 'Health+ 会员', price: '¥19/月', features: ['AI 深度解读', '家庭共享图谱', '异常实时预警', '专家快速咨询'], isActive: false },
];

export const generateEcgData = (length: number): { value: number }[] => {
  const data = [];
  for (let i = 0; i < length; i++) {
    const base = 50;
    let noise = Math.random() * 5;
    let spike = 0;
    
    // Simulate ECG waveform
    if (i % 50 > 5 && i % 50 < 15) spike = 10 * Math.sin((i % 50 - 5) * Math.PI / 10);
    else if (i % 50 > 20 && i % 50 < 25) spike = -10;
    else if (i % 50 >= 25 && i % 50 < 28) spike = 60;
    else if (i % 50 >= 28 && i % 50 < 32) spike = -15;
    else if (i % 50 > 35 && i % 50 < 45) spike = 15 * Math.sin((i % 50 - 35) * Math.PI / 10);

    data.push({ value: base + spike + noise });
  }
  return data;
};