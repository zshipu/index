export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  age: number;
  relation: 'Me' | 'Parent' | 'Child' | 'Spouse';
  healthScore: number;
  riskLevel: RiskLevel;
  activePlanId?: string; // Link to a specific Health Plan
}

export interface PlanTask {
  time: string;
  category: 'diet' | 'exercise' | 'check' | 'habit';
  title: string;
  desc: string;
}

export interface HealthPlan {
  id: string;
  category: string; // e.g. '慢病干预类'
  title: string; // e.g. '稳糖控糖配方'
  color: string; // UI accent color
  diet: string[];
  exercise: string[];
  dailyRoutine: PlanTask[]; // New: Daily Execution Guide
  matchReason: string; // The smart logic explanation displayed to user
}

export interface ActionGuide {
  red: string;
  yellow: string;
  green: string;
}

export interface RiskReport {
  id: string;
  title: string;
  riskLevel: RiskLevel;
  shortDescription: string;
  doctorName: string;
  doctorAvatar: string;
  fullDescription: string;
  reasoning: string[];
  actionGuide: ActionGuide;
}

export interface HealthMetric {
  type: 'heart_rate' | 'bp' | 'sleep' | 'steps' | 'spo2' | 'weight' | 'ecg';
  label: string;
  value: string | number;
  unit: string;
  status: 'normal' | 'warning' | 'danger';
  trend: number[]; // Simple array for sparkline
  lastUpdate: string;
}

export interface Device {
  id: string;
  name: string;
  type: 'watch' | 'ecg_patch' | 'bp_monitor';
  battery: number;
  status: 'connected' | 'disconnected' | 'syncing';
  lastSync: string;
  image: string;
}

export interface AiMessage {
  id: string;
  role: 'user' | 'ai';
  content: string;
  timestamp: Date;
  suggestions?: string[]; // Quick reply suggestions
}

export interface FamilyTask {
  id: string;
  title: string;
  target: string;
  progress: number; // 0-100
  participants: string[]; // User IDs
}

export interface SubscriptionPlan {
  name: string;
  price: string;
  features: string[];
  isActive: boolean;
}