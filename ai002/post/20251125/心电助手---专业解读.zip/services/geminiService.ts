
import { GoogleGenAI } from "@google/genai";
import { UserProfile, HealthMetric } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to format context for the AI
const formatHealthContext = (user: UserProfile, metrics: HealthMetric[]) => {
  const metricStr = metrics.map(m => `${m.label}: ${m.value} ${m.unit} (${m.status})`).join(', ');
  return `用户概况: ${user.name}, ${user.age}岁, 关系: ${user.relation}.
当前健康数据: ${metricStr}.
风险等级: ${user.riskLevel}.`;
};

export const chatWithHealthCoach = async (message: string, user: UserProfile, metrics: HealthMetric[]): Promise<string> => {
  if (!apiKey) return "AI 助手离线中。请检查网络或 API Key 设置。";

  try {
    const context = formatHealthContext(user, metrics);
    const systemInstruction = `
      你是一款名为 "Health Guardian AI" 的高级健康管理助手。
      
      你的角色：
      1. 专业的家庭医生助手，语气亲切、专业、客观。
      2. 你的目标是基于用户的数据提供“预见性干预”和“生活方式建议”。
      3. 如果用户数据有异常（如高血压），请优先提醒风险，但不要下确诊诊断。
      
      上下文信息：
      ${context}
      
      用户问题：${message}
      
      回答要求：
      - 简练，不要长篇大论。
      - 给出1-2个可执行的建议。
      - 如果涉及严重风险，建议线下就医。
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: systemInstruction,
    });

    return response.text || "抱歉，我暂时无法分析您的请求。";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "连接 AI 服务时出现问题，请稍后再试。";
  }
};

export const generateDailySuggestions = async (user: UserProfile): Promise<string[]> => {
    // Simulated async call for mock suggestions based on user risk
    return new Promise(resolve => {
        setTimeout(() => {
            if (user.riskLevel === 'HIGH') {
                resolve([
                    "监测：今日请务必测量两次血压（早/晚）。",
                    "饮食：晚餐建议减少盐分摄入，尝试清淡饮食。",
                    "运动：避免剧烈运动，建议散步15分钟。"
                ]);
            } else {
                resolve([
                    "运动：今天天气不错，试着完成 8000 步目标？",
                    "睡眠：昨晚睡眠质量一般，建议今晚提前30分钟入睡。",
                    "饮水：记得补充水分，目标 2000ml。"
                ]);
            }
        }, 1000);
    });
};
