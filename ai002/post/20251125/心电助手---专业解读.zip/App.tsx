import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, Home, Users, Watch, MessageSquareHeart, User, 
  ChevronRight, Battery, RefreshCw, Plus, Heart, 
  Thermometer, Moon, Footprints, AlertTriangle, Send, 
  Sparkles, Trophy, Settings, CreditCard, ChevronDown,
  LineChart as IconLineChart, Bell, Loader2, X, Share, 
  ChevronLeft, FileText, CheckCircle2, QrCode, Copy, Link as LinkIcon,
  Utensils, Dumbbell, BrainCircuit, Clock
} from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, YAxis, XAxis, Tooltip, AreaChart, Area } from 'recharts';
import { MOCK_FAMILY, MOCK_METRICS, MOCK_DEVICES, MOCK_TASKS, SUBSCRIPTION_PLANS, REPORT_TEMPLATES, HEALTH_PLANS } from './constants';
import { UserProfile, HealthMetric, Device, AiMessage, RiskLevel, FamilyTask, RiskReport, HealthPlan, PlanTask } from './types';
import { chatWithHealthCoach, generateDailySuggestions } from './services/geminiService';
import { EcgChart } from './components/EcgChart';

// --- Shared Components ---

const TabBar: React.FC<{ activeTab: string; onTabChange: (tab: string) => void }> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home', label: '概览', icon: <Home size={24} /> },
    { id: 'family', label: '家庭', icon: <Users size={24} /> },
    { id: 'devices', label: '设备', icon: <Watch size={24} /> },
    { id: 'ai', label: 'AI助手', icon: <MessageSquareHeart size={24} /> },
    { id: 'profile', label: '我的', icon: <User size={24} /> },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-gray-200 pb-safe pt-2 px-2 flex justify-around z-50">
      {tabs.map(tab => (
        <button 
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${activeTab === tab.id ? 'text-[#007AFF] bg-blue-50' : 'text-gray-400'}`}
        >
          {tab.icon}
          <span className="text-[10px] font-medium">{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

const Header: React.FC<{ title: string; rightAction?: React.ReactNode }> = ({ title, rightAction }) => (
  <div className="sticky top-0 z-40 bg-[#F2F2F7]/80 backdrop-blur-md px-6 pt-safe pb-3 flex justify-between items-end border-b border-gray-200/50">
    <h1 className="text-[30px] font-bold text-gray-900 tracking-tight leading-none">{title}</h1>
    {rightAction}
  </div>
);

// --- Sub-Views ---

const FamilySelector: React.FC<{ members: UserProfile[]; activeId: string; onSelect: (id: string) => void }> = ({ members, activeId, onSelect }) => (
  <div className="flex gap-4 overflow-x-auto no-scrollbar px-6 py-4">
    {members.map(member => (
      <div 
        key={member.id} 
        onClick={() => onSelect(member.id)}
        className={`flex flex-col items-center gap-2 min-w-[64px] transition-opacity ${activeId === member.id ? 'opacity-100 scale-105' : 'opacity-50'}`}
      >
        <div className={`w-14 h-14 rounded-full p-[2px] ${activeId === member.id ? (member.riskLevel === 'HIGH' ? 'bg-red-500' : 'bg-[#007AFF]') : 'bg-transparent'}`}>
          <img src={member.avatar} alt={member.name} className="w-full h-full rounded-full border-2 border-[#F2F2F7]" />
        </div>
        <span className="text-xs font-medium text-gray-700">{member.name}</span>
      </div>
    ))}
    <div className="flex flex-col items-center gap-2 min-w-[64px] opacity-50">
        <div className="w-14 h-14 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 border-2 border-transparent">
            <Plus size={24} />
        </div>
        <span className="text-xs font-medium text-gray-700">添加</span>
    </div>
  </div>
);

const MetricCard: React.FC<{ metric: HealthMetric; onClick?: () => void }> = ({ metric, onClick }) => {
  const isDanger = metric.status === 'danger';
  const isWarning = metric.status === 'warning';
  
  const iconMap: Record<string, any> = {
    heart_rate: { icon: Heart, color: 'text-rose-500', bg: 'bg-rose-100' },
    bp: { icon: Activity, color: 'text-orange-500', bg: 'bg-orange-100' },
    sleep: { icon: Moon, color: 'text-indigo-500', bg: 'bg-indigo-100' },
    steps: { icon: Footprints, color: 'text-green-500', bg: 'bg-green-100' },
    spo2: { icon: Thermometer, color: 'text-blue-500', bg: 'bg-blue-100' },
    weight: { icon: User, color: 'text-purple-500', bg: 'bg-purple-100' },
    ecg: { icon: Activity, color: 'text-red-500', bg: 'bg-red-100' },
  };

  const style = iconMap[metric.type] || { icon: Activity, color: 'text-gray-500', bg: 'bg-gray-100' };
  const Icon = style.icon;

  // Mini Sparkline Data
  const chartData = metric.trend.map((val, i) => ({ i, val }));

  return (
    <div 
      onClick={onClick}
      className={`bg-white rounded-2xl p-4 shadow-sm relative overflow-hidden active:scale-95 transition-transform cursor-pointer ${isDanger ? 'ring-2 ring-red-500/50' : ''}`}
    >
      <div className="flex justify-between items-start mb-2">
        <div className={`p-2 rounded-full ${style.bg}`}>
          <Icon size={18} className={style.color} />
        </div>
        <span className="text-[10px] text-gray-400">{metric.lastUpdate}</span>
      </div>
      
      <div className="mb-1">
        <span className="text-[13px] font-medium text-gray-500 block">{metric.label}</span>
        <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-bold tracking-tight ${isDanger ? 'text-red-600' : 'text-gray-900'}`}>{metric.value}</span>
            <span className="text-xs text-gray-400">{metric.unit}</span>
        </div>
      </div>

      {/* Mini Trend Chart */}
      <div className="h-8 -mx-2 -mb-2 opacity-50">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <Area type="monotone" dataKey="val" stroke={isDanger ? '#DC2626' : '#007AFF'} fill={isDanger ? '#FECACA' : '#E0F2FE'} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {isWarning && <div className="absolute top-2 right-2 w-2 h-2 bg-orange-400 rounded-full animate-pulse" />}
      {isDanger && <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse" />}
    </div>
  );
};

// --- New Component: Daily Routine Widget for Dashboard ---

const DailyRoutineWidget: React.FC<{ routine: PlanTask[]; onExpand: () => void }> = ({ routine, onExpand }) => {
  const [checkedState, setCheckedState] = useState<Record<number, boolean>>({});

  const toggleTask = (idx: number) => {
    setCheckedState(prev => ({ ...prev, [idx]: !prev[idx] }));
  };
  
  const completedCount = Object.values(checkedState).filter(Boolean).length;
  const progress = Math.round((completedCount / routine.length) * 100);

  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
        <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <CheckCircle2 size={20} className="text-[#007AFF]" />
                今日任务清单
            </h3>
            <span className="text-[10px] font-bold text-[#007AFF] bg-blue-50 px-2 py-1 rounded-full">
                {progress}% 完成
            </span>
        </div>

        <div className="space-y-3">
            {routine.slice(0, 3).map((task, idx) => {
                const isChecked = !!checkedState[idx];
                return (
                    <div 
                        key={idx} 
                        onClick={() => toggleTask(idx)}
                        className={`group flex items-start gap-3 p-3 rounded-xl transition-all duration-200 cursor-pointer ${isChecked ? 'bg-gray-50' : 'bg-white border border-gray-100 shadow-sm hover:border-blue-200'}`}
                    >
                        <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors duration-200 ${isChecked ? 'bg-[#007AFF] border-[#007AFF]' : 'border-gray-300 group-hover:border-[#007AFF]'}`}>
                            {isChecked && <CheckCircle2 size={12} className="text-white" />}
                        </div>
                        <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start gap-2">
                                 <span className={`text-sm font-bold truncate ${isChecked ? 'text-gray-400 line-through' : 'text-gray-900'}`}>{task.title}</span>
                                 <span className="text-[10px] font-bold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded whitespace-nowrap shrink-0">{task.time}</span>
                            </div>
                            <p className={`text-xs mt-1 leading-relaxed line-clamp-2 ${isChecked ? 'text-gray-300 line-through' : 'text-gray-500'}`}>
                                {task.desc}
                            </p>
                        </div>
                    </div>
                );
            })}
        </div>
        
        <button onClick={onExpand} className="w-full mt-3 py-2 text-xs font-medium text-gray-400 hover:text-[#007AFF] flex items-center justify-center gap-1 transition-colors">
            查看全部 {routine.length} 项任务 <ChevronRight size={12} />
        </button>
    </div>
  );
};

// --- New Component: Plan Detail Modal ---

const PlanDetailModal: React.FC<{ plan: HealthPlan; onClose: () => void }> = ({ plan, onClose }) => {
  const getIconForCategory = (cat: string) => {
      switch(cat) {
          case 'diet': return <Utensils size={16} />;
          case 'exercise': return <Dumbbell size={16} />;
          case 'check': return <Activity size={16} />;
          case 'habit': return <Clock size={16} />;
          default: return <Clock size={16} />;
      }
  };

  const getColorForCategory = (cat: string) => {
      switch(cat) {
          case 'diet': return 'bg-green-100 text-green-600';
          case 'exercise': return 'bg-orange-100 text-orange-600';
          case 'check': return 'bg-blue-100 text-blue-600';
          case 'habit': return 'bg-purple-100 text-purple-600';
          default: return 'bg-gray-100 text-gray-600';
      }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#F2F2F7] overflow-y-auto animate-in slide-in-from-bottom duration-300">
      {/* Sticky Header */}
      <div className="sticky top-0 bg-[#F2F2F7]/95 backdrop-blur-md px-4 py-3 flex justify-between items-center border-b border-gray-200 z-10">
        <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 text-gray-600">
          <ChevronDown size={24} />
        </button>
        <span className="font-semibold text-gray-900">健康干预方案详情</span>
        <div className="w-10" /> 
      </div>

      <div className="p-5 pb-20 space-y-6">
        
        {/* Header Card */}
        <div className={`rounded-3xl p-6 text-white shadow-lg bg-gradient-to-br ${plan.color}`}>
          <div className="flex items-center gap-2 mb-2 opacity-90">
             <BrainCircuit size={18} />
             <span className="text-sm font-bold tracking-wider uppercase">{plan.category}</span>
          </div>
          <h2 className="text-3xl font-bold mb-4">{plan.title}</h2>
          
          <div className="bg-white/20 backdrop-blur-md rounded-xl p-4">
             <p className="text-sm font-medium leading-relaxed">
               {plan.matchReason}
             </p>
          </div>
        </div>

        {/* --- Daily Routine Timeline (New) --- */}
        <div className="bg-white rounded-3xl p-6 shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Clock size={20} className="text-[#007AFF]" />
                今日执行指南
            </h3>
            
            <div className="relative pl-4 space-y-8 before:absolute before:left-[19px] before:top-2 before:bottom-4 before:w-[2px] before:bg-gray-100">
                {plan.dailyRoutine && plan.dailyRoutine.length > 0 ? (
                   plan.dailyRoutine.map((task, idx) => (
                    <div key={idx} className="relative pl-8">
                        {/* Dot */}
                        <div className={`absolute left-0 top-1 w-10 h-10 rounded-full border-4 border-white shadow-sm flex items-center justify-center z-10 ${getColorForCategory(task.category)}`}>
                            {getIconForCategory(task.category)}
                        </div>
                        
                        {/* Content */}
                        <div className="flex flex-col">
                            <span className="text-xs font-bold text-gray-400 mb-1 tracking-wide">{task.time}</span>
                            <h4 className="text-base font-bold text-gray-900 mb-1">{task.title}</h4>
                            <p className="text-sm text-gray-600 leading-relaxed bg-gray-50 p-3 rounded-xl border border-gray-100">
                                {task.desc}
                            </p>
                        </div>
                    </div>
                   ))
                ) : (
                    <p className="text-gray-400 text-sm pl-4">暂无今日任务</p>
                )}
            </div>
        </div>

        {/* Diet Section */}
        <div className="bg-white rounded-3xl p-6 shadow-sm">
           <div className="flex items-center gap-3 mb-4">
             <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
               <Utensils size={20} />
             </div>
             <h3 className="text-xl font-bold text-gray-900">饮食方案设计</h3>
           </div>
           <ul className="space-y-4">
             {plan.diet.map((item, idx) => (
               <li key={idx} className="flex gap-3">
                 <div className="w-6 h-6 rounded-full bg-green-50 text-green-600 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                   {idx + 1}
                 </div>
                 <span className="text-gray-700 leading-relaxed text-[15px]">{item}</span>
               </li>
             ))}
           </ul>
        </div>

        {/* Exercise Section */}
        <div className="bg-white rounded-3xl p-6 shadow-sm">
           <div className="flex items-center gap-3 mb-4">
             <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600">
               <Dumbbell size={20} />
             </div>
             <h3 className="text-xl font-bold text-gray-900">运动方案设计</h3>
           </div>
           <ul className="space-y-4">
             {plan.exercise.map((item, idx) => (
               <li key={idx} className="flex gap-3">
                 <div className="w-6 h-6 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                   {idx + 1}
                 </div>
                 <span className="text-gray-700 leading-relaxed text-[15px]">{item}</span>
               </li>
             ))}
           </ul>
        </div>

        {/* Footer info */}
        <p className="text-center text-xs text-gray-400 mt-4 px-8">
          本方案由 AI 智能匹配生成，并经由医学知识库校准。仅供健康管理参考，不替代医生面诊。
        </p>
      </div>
    </div>
  );
};

// --- New Component: Detailed Report View with Share & Next Steps ---

const ShareModal: React.FC<{ report: RiskReport; onClose: () => void }> = ({ report, onClose }) => {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="bg-white rounded-[24px] w-full max-w-sm p-6 relative z-10 animate-in zoom-in-95 duration-200">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <X size={24} />
        </button>
        
        <div className="text-center mb-6">
          <h3 className="text-xl font-bold text-gray-900 mb-1">分享报告</h3>
          <p className="text-sm text-gray-500">邀请家人或医生查看完整分析</p>
        </div>

        <div className="bg-[#F2F2F7] rounded-xl p-4 flex flex-col items-center mb-6">
           <div className="bg-white p-2 rounded-lg shadow-sm mb-3">
             <QrCode size={120} className="text-gray-900" />
           </div>
           <p className="text-xs text-gray-500 font-medium">使用微信扫描查看</p>
        </div>

        <div className="flex flex-col gap-3">
           <button className="flex items-center justify-center gap-2 w-full bg-[#007AFF] text-white py-3.5 rounded-xl font-semibold active:opacity-90">
             <LinkIcon size={18} />
             复制链接
           </button>
           <button className="flex items-center justify-center gap-2 w-full bg-gray-100 text-gray-900 py-3.5 rounded-xl font-semibold active:bg-gray-200">
             <Share size={18} />
             系统分享
           </button>
        </div>
      </div>
    </div>
  );
};

const ReportDetailView: React.FC<{ report: RiskReport; onClose: () => void }> = ({ report, onClose }) => {
  const [showShare, setShowShare] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-[#F2F2F7] overflow-y-auto animate-in slide-in-from-bottom duration-300">
      {showShare && <ShareModal report={report} onClose={() => setShowShare(false)} />}
      
      {/* Sticky Header */}
      <div className="sticky top-0 bg-[#F2F2F7]/95 backdrop-blur-md px-4 py-3 flex justify-between items-center border-b border-gray-200 z-10">
        <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 text-[#007AFF]">
          <ChevronLeft size={24} />
        </button>
        <span className="font-semibold text-gray-900">详细分析报告</span>
        <button onClick={() => setShowShare(true)} className="p-2 rounded-full hover:bg-gray-200 text-[#007AFF] flex flex-col items-center">
          <Share size={20} />
        </button>
      </div>

      <div className="p-5 pb-20 space-y-6">
        
        {/* Main Risk Card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
             <AlertTriangle className={`w-6 h-6 ${report.riskLevel === 'HIGH' ? 'text-red-500' : 'text-orange-500'}`} />
             <h2 className={`text-xl font-bold ${report.riskLevel === 'HIGH' ? 'text-red-600' : 'text-orange-600'}`}>
               {report.title}
             </h2>
          </div>
          <p className="text-gray-600 leading-relaxed text-[15px]">
            {report.fullDescription}
          </p>
          
          <div className="mt-4 bg-gray-50 rounded-xl p-3 border border-gray-100">
             <div className="flex items-center gap-3 mb-2">
               <img src={report.doctorAvatar} className="w-8 h-8 rounded-full" alt="Doctor" />
               <div className="flex flex-col">
                 <span className="text-xs font-bold text-gray-900">{report.doctorName}</span>
                 <span className="text-[10px] text-gray-500">已复核分析结果</span>
               </div>
             </div>
             <p className="text-xs text-gray-500 italic">"建议仔细阅读下方的行动指南，并密切关注身体变化。"</p>
          </div>
        </div>

        {/* ECG Chart (Mock) if applicable */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
           <h3 className="text-sm font-bold text-gray-900 mb-2">波形记录</h3>
           <EcgChart />
        </div>

        {/* Reasoning */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
           <h3 className="text-base font-bold text-gray-900 mb-3">为什么会出现这个结果？</h3>
           <ul className="space-y-2">
             {report.reasoning.map((r, i) => (
               <li key={i} className="flex gap-2 items-start text-sm text-gray-600">
                 <span className="font-bold text-gray-400 mt-[2px]">•</span>
                 <span>{r}</span>
               </li>
             ))}
           </ul>
        </div>

        {/* Next Steps Guide (Traffic Light) */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
           <div className="p-4 border-b border-gray-100 bg-gray-50/50">
              <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                <CheckCircle2 size={18} className="text-green-600" />
                下一步行动指南
              </h3>
           </div>
           
           <div className="divide-y divide-gray-100">
              <div className="p-4 flex gap-4 bg-red-50/30">
                 <div className="shrink-0 pt-1">
                   <div className="w-3 h-3 rounded-full bg-red-500 ring-4 ring-red-100"></div>
                 </div>
                 <div>
                   <span className="block text-xs font-bold text-red-600 mb-1 uppercase tracking-wide">紧急警报 (Red)</span>
                   <p className="text-sm text-gray-700 leading-relaxed">{report.actionGuide.red}</p>
                 </div>
              </div>
              <div className="p-4 flex gap-4 bg-orange-50/30">
                 <div className="shrink-0 pt-1">
                   <div className="w-3 h-3 rounded-full bg-yellow-500 ring-4 ring-yellow-100"></div>
                 </div>
                 <div>
                   <span className="block text-xs font-bold text-yellow-700 mb-1 uppercase tracking-wide">观察建议 (Yellow)</span>
                   <p className="text-sm text-gray-700 leading-relaxed">{report.actionGuide.yellow}</p>
                 </div>
              </div>
              <div className="p-4 flex gap-4 bg-green-50/30">
                 <div className="shrink-0 pt-1">
                   <div className="w-3 h-3 rounded-full bg-green-500 ring-4 ring-green-100"></div>
                 </div>
                 <div>
                   <span className="block text-xs font-bold text-green-700 mb-1 uppercase tracking-wide">日常保养 (Green)</span>
                   <p className="text-sm text-gray-700 leading-relaxed">{report.actionGuide.green}</p>
                 </div>
              </div>
           </div>
        </div>

      </div>
    </div>
  );
};

// --- Views ---

const DashboardView: React.FC<{ 
  members: UserProfile[]; 
  activeMemberId: string; 
  setActiveMemberId: (id: string) => void; 
}> = ({ members, activeMemberId, setActiveMemberId }) => {
  const activeUser = members.find(m => m.id === activeMemberId) || members[0];
  const metrics = MOCK_METRICS[activeMemberId] || [];
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [selectedReport, setSelectedReport] = useState<RiskReport | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<HealthPlan | null>(null);

  useEffect(() => {
    generateDailySuggestions(activeUser).then(setSuggestions);
  }, [activeUser]);

  const handleMetricClick = (metric: HealthMetric) => {
    // Map metrics to reports for demo purposes
    if (metric.type === 'ecg') {
      setSelectedReport(REPORT_TEMPLATES['PREMATURE']);
    } else if (metric.type === 'bp' && metric.status === 'danger') {
      setSelectedReport(REPORT_TEMPLATES['HIGH_BP']);
    }
  };

  // Determine if we should show a quick action guide on dashboard for high risk
  const highRiskTemplate = activeUser.riskLevel === 'HIGH' ? REPORT_TEMPLATES['HIGH_BP'] : null;

  // Get Active Plan
  const activePlan = activeUser.activePlanId ? HEALTH_PLANS[activeUser.activePlanId] : null;

  return (
    <div className="animate-in fade-in duration-500 pb-24">
      {/* Modals */}
      {selectedReport && (
        <ReportDetailView report={selectedReport} onClose={() => setSelectedReport(null)} />
      )}
      {selectedPlan && (
        <PlanDetailModal plan={selectedPlan} onClose={() => setSelectedPlan(null)} />
      )}

      <Header 
        title="健康概览" 
        rightAction={<div className="bg-gray-200 p-2 rounded-full"><Bell size={20} className="text-gray-600" /></div>} 
      />
      
      {/* Family Switcher */}
      <div className="bg-white/50 backdrop-blur-sm sticky top-[70px] z-30 border-b border-gray-100">
        <FamilySelector members={members} activeId={activeMemberId} onSelect={setActiveMemberId} />
      </div>

      <div className="px-5 pt-4 space-y-6">
        
        {/* Risk / Status Card */}
        <div className={`rounded-2xl p-5 text-white shadow-lg transition-colors duration-500 ${activeUser.riskLevel === 'HIGH' ? 'bg-gradient-to-br from-red-500 to-rose-600' : 'bg-gradient-to-br from-blue-500 to-indigo-600'}`}>
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-lg font-bold opacity-90">综合健康评分</h2>
              <p className="text-sm opacity-75">基于今日实时数据</p>
            </div>
            <div className="text-4xl font-bold tracking-tight">{activeUser.healthScore}</div>
          </div>
          
          {activeUser.riskLevel === 'HIGH' ? (
            <div className="bg-white/20 backdrop-blur-md rounded-xl p-3 flex items-start gap-3">
              <AlertTriangle className="shrink-0 animate-bounce" />
              <div>
                <p className="font-bold text-sm">检测到健康风险</p>
                <p className="text-xs opacity-90 mt-1">
                    {highRiskTemplate ? highRiskTemplate.shortDescription : '多项数据出现异常波动，建议立即关注。'}
                </p>
              </div>
            </div>
          ) : (
             <div className="bg-white/20 backdrop-blur-md rounded-xl p-3 flex items-center gap-3">
              <Sparkles className="shrink-0" />
              <p className="text-sm font-medium">状态良好，继续保持！</p>
            </div>
          )}
        </div>

        {/* --- Active Health Plan Card (NEW) --- */}
        {activePlan && (
          <div 
            onClick={() => setSelectedPlan(activePlan)}
            className="bg-white rounded-2xl p-1 shadow-sm border border-gray-100 cursor-pointer active:scale-95 transition-transform"
          >
            <div className={`rounded-xl p-4 bg-gradient-to-r ${activePlan.color} text-white`}>
               <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-2">
                     <BrainCircuit size={18} className="text-white/90" />
                     <span className="text-xs font-bold bg-white/20 px-2 py-0.5 rounded-lg">{activePlan.category}</span>
                  </div>
                  <ChevronRight size={18} className="text-white/80" />
               </div>
               <h3 className="text-lg font-bold mb-1">{activePlan.title}</h3>
               <p className="text-xs text-white/80 line-clamp-1">{activePlan.matchReason}</p>
            </div>
            <div className="p-3 flex justify-around text-center">
                <div className="flex flex-col items-center gap-1">
                   <div className="w-8 h-8 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
                      <Utensils size={16} />
                   </div>
                   <span className="text-[10px] text-gray-500 font-medium">饮食方案</span>
                </div>
                <div className="w-[1px] bg-gray-100" />
                <div className="flex flex-col items-center gap-1">
                   <div className="w-8 h-8 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center">
                      <Dumbbell size={16} />
                   </div>
                   <span className="text-[10px] text-gray-500 font-medium">运动计划</span>
                </div>
            </div>
          </div>
        )}

        {/* NEW: Daily Routine Widget */}
        {activePlan && activePlan.dailyRoutine && (
            <DailyRoutineWidget routine={activePlan.dailyRoutine} onExpand={() => setSelectedPlan(activePlan)} />
        )}

        {/* Dashboard Quick Action Guide (For High Risk) */}
        {activeUser.riskLevel === 'HIGH' && highRiskTemplate && (
            <div className="bg-white rounded-2xl p-4 shadow-sm border border-red-100">
                <div className="flex justify-between items-center mb-3">
                    <h3 className="font-bold text-red-600 flex items-center gap-2 text-sm">
                        <CheckCircle2 size={16} /> 
                        行动建议 (High Priority)
                    </h3>
                    <button 
                        onClick={() => setSelectedReport(highRiskTemplate)} 
                        className="text-xs text-gray-400 flex items-center"
                    >
                        查看详情 <ChevronRight size={14} />
                    </button>
                </div>
                <div className="space-y-2">
                    <div className="flex gap-2 items-start text-sm">
                         <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                         <span className="text-gray-700">{highRiskTemplate.actionGuide.red.split(' -> ')[0]}</span>
                    </div>
                     <div className="flex gap-2 items-start text-sm">
                         <div className="w-1.5 h-1.5 rounded-full bg-yellow-500 mt-1.5 shrink-0" />
                         <span className="text-gray-700">{highRiskTemplate.actionGuide.yellow.split(' -> ')[0]}</span>
                    </div>
                </div>
            </div>
        )}

        {/* Metrics Grid */}
        <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Activity size={20} className="text-[#007AFF]" />
                关键指标
            </h3>
            <div className="grid grid-cols-2 gap-3">
                {metrics.map((m, i) => (
                  <MetricCard 
                    key={i} 
                    metric={m} 
                    onClick={() => handleMetricClick(m)}
                  />
                ))}
            </div>
        </div>

        {/* AI Suggestions */}
        <div className="bg-gradient-to-br from-purple-50 to-white rounded-2xl p-4 border border-purple-100">
            <h3 className="text-md font-bold text-purple-900 mb-3 flex items-center gap-2">
                <Sparkles size={18} className="text-purple-600" />
                今日 AI 建议
            </h3>
            <ul className="space-y-3">
                {suggestions.length === 0 ? (
                    <div className="flex gap-2 text-sm text-gray-400 items-center"><Loader2 className="animate-spin" size={16}/> 分析中...</div>
                ) : (
                    suggestions.map((s, i) => (
                        <li key={i} className="flex gap-3 items-start bg-white p-3 rounded-xl shadow-sm">
                             <div className="w-5 h-5 rounded-full border-2 border-purple-200 flex items-center justify-center shrink-0 mt-0.5" />
                             <span className="text-sm text-gray-700 leading-snug">{s}</span>
                        </li>
                    ))
                )}
            </ul>
        </div>
      </div>
    </div>
  );
};

const FamilyHubView: React.FC<{ tasks: FamilyTask[] }> = ({ tasks }) => (
  <div className="animate-in fade-in duration-500 pb-24">
    <Header title="家庭协作" />
    <div className="px-5 pt-4 space-y-6">
        
        {/* Family Graph Placeholder */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-4">家庭健康图谱</h3>
            <div className="flex items-end justify-between h-32 px-2 border-b border-gray-100 pb-2">
                 {/* Simulated Graph Bars */}
                 <div className="flex flex-col items-center gap-2">
                    <div className="w-8 bg-[#007AFF] rounded-t-lg h-[85%]" />
                    <span className="text-xs text-gray-500">我自己</span>
                 </div>
                 <div className="flex flex-col items-center gap-2">
                    <div className="w-8 bg-red-400 rounded-t-lg h-[60%]" />
                    <span className="text-xs text-gray-500">父亲</span>
                 </div>
                 <div className="flex flex-col items-center gap-2">
                    <div className="w-8 bg-green-400 rounded-t-lg h-[78%]" />
                    <span className="text-xs text-gray-500">母亲</span>
                 </div>
            </div>
            <p className="text-xs text-gray-400 mt-3 text-center">父亲的健康指数本周下降 12%，请多加关注。</p>
        </div>

        {/* Shared Tasks */}
        <div>
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Trophy className="text-yellow-500" size={20} />
                家庭挑战
            </h3>
            <div className="space-y-3">
                {tasks.map(task => (
                    <div key={task.id} className="bg-white rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                        <div className="flex justify-between items-start">
                            <div>
                                <h4 className="font-bold text-gray-900">{task.title}</h4>
                                <p className="text-xs text-gray-500">目标: {task.target}</p>
                            </div>
                            <span className="text-xs font-bold bg-yellow-100 text-yellow-700 px-2 py-1 rounded-lg">{task.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                            <div className="bg-yellow-500 h-full rounded-full transition-all duration-1000" style={{ width: `${task.progress}%` }} />
                        </div>
                        <div className="flex -space-x-2">
                             {task.participants.map((pid, idx) => (
                                 <div key={pid} className="w-6 h-6 rounded-full bg-gray-300 border-2 border-white flex items-center justify-center text-[8px] overflow-hidden">
                                     <img src={MOCK_FAMILY.find(f => f.id === pid)?.avatar} alt="" />
                                 </div>
                             ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>

        {/* Add Member Card */}
        <div className="border-2 border-dashed border-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center text-gray-400 gap-2">
             <div className="bg-gray-100 p-3 rounded-full">
                <Plus size={24} />
             </div>
             <span className="text-sm font-medium">邀请家庭成员</span>
        </div>
    </div>
  </div>
);

const DeviceView: React.FC<{ devices: Device[] }> = ({ devices }) => (
  <div className="animate-in fade-in duration-500 pb-24">
    <Header title="设备管理" rightAction={<Plus className="text-[#007AFF]" />} />
    <div className="px-5 pt-4 space-y-4">
        {devices.map(dev => (
            <div key={dev.id} className="bg-white rounded-2xl p-4 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center text-2xl">
                    {dev.image}
                </div>
                <div className="flex-1">
                    <h3 className="font-bold text-gray-900">{dev.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                        <span className={`w-2 h-2 rounded-full ${dev.status === 'connected' ? 'bg-green-500' : 'bg-gray-400'}`} />
                        <span className="text-xs text-gray-500 capitalize">{dev.status === 'syncing' ? '正在同步...' : dev.status}</span>
                    </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Battery size={14} /> {dev.battery}%
                    </div>
                    <span className="text-[10px] text-gray-400">上次: {dev.lastSync}</span>
                </div>
            </div>
        ))}
    </div>
  </div>
);

const AICoachView: React.FC<{ user: UserProfile }> = ({ user }) => {
    const [messages, setMessages] = useState<AiMessage[]>([
        { id: '1', role: 'ai', content: `你好，我是你的 AI 健康管家。基于${user.relation === 'Me' ? '你' : user.name}的最新数据，有什么我可以帮你的吗？`, timestamp: new Date() }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    const handleSend = async () => {
        if (!input.trim()) return;
        
        const newMsg: AiMessage = { id: Date.now().toString(), role: 'user', content: input, timestamp: new Date() };
        setMessages(prev => [...prev, newMsg]);
        setInput('');
        setLoading(true);

        const metrics = MOCK_METRICS[user.id] || [];
        const responseText = await chatWithHealthCoach(input, user, metrics);
        
        setMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'ai', content: responseText, timestamp: new Date() }]);
        setLoading(false);
    };

    useEffect(() => {
        if(scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, [messages]);

    return (
        <div className="flex flex-col h-screen bg-[#F2F2F7]">
            <Header title="AI 健康顾问" />
            
            {/* Chat Area */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-32">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-4 rounded-2xl text-[15px] leading-relaxed shadow-sm ${
                            msg.role === 'user' 
                            ? 'bg-[#007AFF] text-white rounded-br-none' 
                            : 'bg-white text-gray-800 rounded-bl-none'
                        }`}>
                            {msg.content}
                        </div>
                    </div>
                ))}
                {loading && (
                    <div className="flex justify-start">
                        <div className="bg-white p-4 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-3">
                             <div className="flex gap-1">
                                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" />
                                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-75" />
                                <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-150" />
                             </div>
                             <span className="text-sm text-gray-400 font-medium">AI 正在分析您的数据...</span>
                        </div>
                    </div>
                )}
            </div>

            {/* Input Area */}
            <div className="fixed bottom-[90px] left-0 right-0 px-4">
                <div className="bg-white/80 backdrop-blur-xl p-2 rounded-full shadow-lg border border-gray-200 flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-[#007AFF]">
                        <Sparkles size={20} />
                    </div>
                    <input 
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleSend()}
                        placeholder="询问健康建议或数据分析..."
                        className="flex-1 bg-transparent border-none outline-none text-[16px] placeholder:text-gray-400"
                    />
                    <button onClick={handleSend} disabled={loading} className="w-10 h-10 rounded-full bg-[#007AFF] flex items-center justify-center text-white disabled:opacity-50">
                        <Send size={18} />
                    </button>
                </div>
            </div>
        </div>
    );
};

const ProfileView: React.FC = () => (
    <div className="animate-in fade-in duration-500 pb-24">
        <Header title="我的" rightAction={<Settings className="text-gray-600" />} />
        
        {/* User Card */}
        <div className="bg-white p-6 mb-6 flex items-center gap-4">
            <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-white shadow-lg">
                <img src={MOCK_FAMILY[0].avatar} alt="" className="w-full h-full" />
            </div>
            <div>
                <h2 className="text-2xl font-bold text-gray-900">Felix</h2>
                <span className="bg-blue-100 text-[#007AFF] text-xs font-bold px-2 py-1 rounded-full">Health+ 会员</span>
            </div>
        </div>

        <div className="px-5 space-y-6">
            {/* Points */}
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-5 text-white shadow-md relative overflow-hidden">
                <div className="relative z-10">
                    <p className="text-sm font-medium opacity-90 mb-1">健康积分余额</p>
                    <h3 className="text-4xl font-bold">2,450</h3>
                    <button className="mt-4 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full text-sm font-bold border border-white/30">
                        兑换商城
                    </button>
                </div>
                <Trophy className="absolute right-[-20px] bottom-[-20px] text-white/20 w-40 h-40 rotate-12" />
            </div>

            {/* Subscription Plans */}
            <div>
                <h3 className="font-bold text-gray-900 mb-3">订阅计划</h3>
                <div className="space-y-3">
                    {SUBSCRIPTION_PLANS.map(plan => (
                        <div key={plan.name} className={`rounded-2xl p-4 border-2 ${plan.isActive ? 'border-[#007AFF] bg-blue-50' : 'border-gray-100 bg-white'}`}>
                            <div className="flex justify-between items-center mb-2">
                                <h4 className="font-bold text-gray-900">{plan.name}</h4>
                                <span className="font-bold text-[#007AFF]">{plan.price}</span>
                            </div>
                            <ul className="text-xs text-gray-500 space-y-1">
                                {plan.features.map(f => <li key={f} className="flex gap-2">✓ {f}</li>)}
                            </ul>
                            {!plan.isActive && (
                                <button className="w-full mt-3 bg-gray-900 text-white py-2 rounded-xl text-sm font-bold">
                                    立即升级
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
);

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [activeMemberId, setActiveMemberId] = useState(MOCK_FAMILY[0].id);

  // Helper to get current active member object
  const activeUser = MOCK_FAMILY.find(m => m.id === activeMemberId) || MOCK_FAMILY[0];

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <DashboardView members={MOCK_FAMILY} activeMemberId={activeMemberId} setActiveMemberId={setActiveMemberId} />;
      case 'family': return <FamilyHubView tasks={MOCK_TASKS} />;
      case 'devices': return <DeviceView devices={MOCK_DEVICES} />;
      case 'ai': return <AICoachView user={activeUser} />;
      case 'profile': return <ProfileView />;
      default: return <DashboardView members={MOCK_FAMILY} activeMemberId={activeMemberId} setActiveMemberId={setActiveMemberId} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F2F2F7] text-gray-900 max-w-md mx-auto relative overflow-hidden shadow-2xl border-x border-gray-200/50">
      <div className="h-screen overflow-y-auto no-scrollbar">
        {renderContent()}
      </div>
      <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}