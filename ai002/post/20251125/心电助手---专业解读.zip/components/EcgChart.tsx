import React, { useMemo } from 'react';
import { LineChart, Line, ResponsiveContainer, YAxis } from 'recharts';
import { generateEcgData } from '../constants';

interface EcgChartProps {
  isBlurred?: boolean;
}

export const EcgChart: React.FC<EcgChartProps> = ({ isBlurred = false }) => {
  const data = useMemo(() => generateEcgData(150), []);

  return (
    <div className={`w-full h-32 bg-white rounded-xl overflow-hidden relative ${isBlurred ? 'opacity-40 filter blur-sm' : ''}`}>
       {/* Apple Health style grid - subtle red grid on white */}
      <div className="absolute inset-0 z-0 opacity-[0.08] pointer-events-none" 
           style={{ 
             backgroundImage: 'linear-gradient(#ff3b30 1px, transparent 1px), linear-gradient(90deg, #ff3b30 1px, transparent 1px)', 
             backgroundSize: '20px 20px' 
           }}>
      </div>

      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <YAxis hide domain={['auto', 'auto']} />
          <Line 
            type="monotone" 
            dataKey="value" 
            stroke="#ff3b30" 
            strokeWidth={2} 
            dot={false} 
            isAnimationActive={true}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};