import React, { useState } from 'react';
import BottomNav from './components/BottomNav';
import Home from './pages/Home';
import Health from './pages/Health';
import Reports from './pages/Reports';
import Assistant from './pages/Assistant';
import Profile from './pages/Profile';
import MetricDetail from './components/MetricDetail';
import { Tab, HealthMetric } from './types';

const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<Tab>(Tab.HOME);
  const [selectedMetric, setSelectedMetric] = useState<HealthMetric | null>(null);

  const handleMetricClick = (metric: HealthMetric) => {
    setSelectedMetric(metric);
  };

  const handleCloseDetail = () => {
    setSelectedMetric(null);
  };

  const handleAskAI = () => {
    setSelectedMetric(null);
    setCurrentTab(Tab.ASSISTANT);
    // In a real app, we would pass the context of the selected metric to the Assistant here
  };

  const renderContent = () => {
    switch (currentTab) {
      case Tab.HOME:
        return <Home onMetricClick={handleMetricClick} />;
      case Tab.HEALTH:
        return <Health />;
      case Tab.REPORTS:
        return <Reports />;
      case Tab.ASSISTANT:
        return <Assistant />;
      case Tab.PROFILE:
        return <Profile />;
      default:
        return <Home onMetricClick={handleMetricClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F2F2F7] text-gray-900 font-sans relative">
      {renderContent()}
      
      <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* Metric Detail Overlay */}
      {selectedMetric && (
        <MetricDetail 
          metric={selectedMetric} 
          onClose={handleCloseDetail} 
          onAskAI={handleAskAI}
        />
      )}
    </div>
  );
};

export default App;