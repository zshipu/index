import React from 'react';
import * as LucideIcons from 'lucide-react';
import { Brain } from 'lucide-react';
import { HealthMetric } from '../types';

interface MetricCardProps {
  metric: HealthMetric;
  onClick?: () => void;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric, onClick }) => {
  // Dynamic icon rendering
  const IconComponent = (LucideIcons as any)[metric.icon] || LucideIcons.Activity;

  const hasAIAnalysis = !!(metric.analysis || (metric.recommendations && metric.recommendations.length > 0));

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-2xl p-4 shadow-sm active:scale-95 transition-transform duration-200 flex flex-col justify-between h-32 relative overflow-hidden"
    >
      <div className="flex justify-between items-start">
        <div className={`p-2 rounded-full bg-gray-50 ${metric.color}`}>
          <IconComponent size={20} />
        </div>
        <span className="text-xs text-gray-400 font-medium">{metric.date}</span>
      </div>
      
      <div className="mt-2">
        <h3 className="text-sm text-gray-500 font-medium">{metric.title}</h3>
        <div className="flex items-baseline space-x-1">
          <span className="text-2xl font-bold text-gray-900">{metric.value}</span>
          <span className="text-xs text-gray-500">{metric.unit}</span>
        </div>
      </div>
      
      {/* Warning Indicator */}
      {metric.status !== 'Normal' && (
        <div className="absolute top-2 right-2 p-1">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
        </div>
      )}

      {/* AI Badge */}
      {hasAIAnalysis && metric.status === 'Normal' && (
        <div className="absolute top-2 right-2 p-1 bg-indigo-50 rounded-full text-indigo-500">
           <Brain size={12} />
        </div>
      )}
      
      {hasAIAnalysis && metric.status !== 'Normal' && (
         <div className="absolute top-2 right-6 p-1 bg-indigo-50 rounded-full text-indigo-500">
           <Brain size={12} />
        </div>
      )}
    </div>
  );
};

export default MetricCard;