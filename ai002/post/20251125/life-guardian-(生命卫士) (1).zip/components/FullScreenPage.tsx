import React from 'react';
import { ChevronLeft, X } from 'lucide-react';

interface FullScreenPageProps {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  action?: React.ReactNode;
}

const FullScreenPage: React.FC<FullScreenPageProps> = ({ title, onClose, children, action }) => {
  return (
    <div className="fixed inset-0 z-[60] bg-[#F2F2F7] flex flex-col animate-fade-in-up">
      <div className="bg-white px-4 py-3 safe-top flex items-center justify-between shadow-sm sticky top-0 z-10">
        <button onClick={onClose} className="p-2 -ml-2 text-gray-900 active:opacity-70">
          <ChevronLeft size={24} />
        </button>
        <h1 className="text-lg font-bold text-gray-900">{title}</h1>
        <div className="w-10 flex justify-end">
          {action}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto pb-safe">
        {children}
      </div>
    </div>
  );
};

export default FullScreenPage;