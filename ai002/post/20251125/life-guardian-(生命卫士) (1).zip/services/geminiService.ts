import { GoogleGenAI, Chat } from "@google/genai";
import { User, HealthMetric, RiskProfile } from "../types";

const apiKey = process.env.API_KEY || ''; 

// Initialize the client
let ai: GoogleGenAI | null = null;
try {
  if (apiKey) {
    ai = new GoogleGenAI({ apiKey });
  }
} catch (error) {
  console.error("Failed to initialize Gemini Client", error);
}

export const createChatSession = (user: User, metrics: HealthMetric[], risk: RiskProfile): Chat | null => {
  if (!ai) return null;

  // Construct a context string from user data
  const metricsContext = metrics.map(m => `${m.title}: ${m.value} ${m.unit} (${m.status})`).join(', ');
  const conditionsContext = user.conditions.join(', ');
  const riskContext = `心血管风险: ${risk.cvdRisk}, 睡眠质量: ${risk.sleepQuality}`;

  const systemPrompt = `你是“生命卫士”APP的专属健康AI助手。
  
  【当前用户信息】
  姓名: ${user.name}, 年龄: ${user.age}, 性别: ${user.gender}
  已知病史: ${conditionsContext || '无'}
  
  【今日实时健康数据】
  ${metricsContext}
  
  【健康风险画像】
  ${riskContext}

  【你的任务】
  1. 主动式管理：如果数据有“Warning”或“Critical”，请优先询问用户感觉，并给出安全建议（非医疗处方）。
  2. 你的语气应该是专业、亲切、富有同理心的私人医生助理。
  3. 不要提供确诊（Diagnosis）或开具处方（Prescription）。
  4. 遇到严重问题（如剧烈胸痛、极高血压），强烈建议就医。
  5. 回答关于健康饮食、运动、睡眠改善的问题时，要结合用户的高血压/糖尿病等情况（如果有）。`;
  
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: systemPrompt,
    },
  });
};

export const sendMessageStream = async (chat: Chat, message: string) => {
  try {
    const result = await chat.sendMessageStream({ message });
    return result;
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    throw error;
  }
};