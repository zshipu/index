
import { User, HealthMetric, DeviceType, Alert, DailyTask, RiskProfile, HealthForecast, Medicine, HealthFormula, HealthReport } from './types';

export const CURRENT_USER: User = {
  id: 'u1',
  name: '张伟',
  avatar: 'https://picsum.photos/200/200',
  age: 45,
  gender: 'Male',
  height: 175,
  weight: 80,
  conditions: ['高血压I级', '轻度脂肪肝'],
  role: 'Self'
};

export const FAMILY_MEMBERS: User[] = [
  CURRENT_USER,
  {
    id: 'u2',
    name: '父亲',
    avatar: 'https://picsum.photos/201/201',
    age: 72,
    gender: 'Male',
    height: 170,
    weight: 65,
    conditions: ['房颤', '糖尿病'],
    role: 'Family'
  }
];

export const RISK_PROFILE: RiskProfile = {
  cvdRisk: 'Medium',
  diabetesRisk: 'Low',
  sleepQuality: 'Fair',
  healthScore: 88
};

// New: Health Forecast based on "Algorithms"
export const TODAY_FORECAST: HealthForecast = {
  energyScore: 65,
  status: 'Fatigued',
  drivingFactors: ['昨夜深睡不足', '晨间HRV偏低'],
  suggestion: '今日身体机能略有下降，建议避免高强度无氧运动，午间安排20分钟小憩。'
};

// New: Medicine Inventory
export const MEDICINE_CABINET: Medicine[] = [
  { 
    id: 'm1', 
    name: '苯磺酸氨氯地平片', 
    dosage: '5mg x 1片/天', 
    stock: 4, 
    totalStock: 28, 
    expiryDate: '2025-06',
    tags: ['高血压', '处方药']
  },
  { 
    id: 'm2', 
    name: '二甲双胍缓释片', 
    dosage: '0.5g x 2片/天', 
    stock: 45, 
    totalStock: 60, 
    expiryDate: '2024-12',
    tags: ['糖尿病']
  }
];

// User has slightly high BP today - proactive scenario
export const MOCK_METRICS: HealthMetric[] = [
  { 
    id: '1', 
    title: '心率', 
    value: '78', 
    unit: 'bpm', 
    status: 'Normal', 
    icon: 'Heart', 
    color: 'text-red-500', 
    date: '10:00', 
    trend: 'stable',
    history: [
      { time: '06:00', value: 65 }, { time: '08:00', value: 72 }, { time: '10:00', value: 78 }
    ],
    analysis: '心率处于正常范围。运动后恢复速度良好，心脏负荷正常。',
    recommendations: ['保持当前运动频率', '关注静息心率变化']
  },
  { 
    id: '2', 
    title: '血压', 
    value: '142/91', 
    unit: 'mmHg', 
    status: 'Warning', 
    icon: 'Activity', 
    color: 'text-blue-500', 
    date: '09:30', 
    trend: 'up',
    history: [
      { time: '周一', value: 128, value2: 82 },
      { time: '周二', value: 130, value2: 85 },
      { time: '周三', value: 135, value2: 88 },
      { time: '昨日', value: 138, value2: 89 },
      { time: '今日', value: 142, value2: 91 }
    ],
    analysis: '检测到收缩压呈现连续上升趋势，且今日读数超出正常范围（<140/90）。算法分析可能与近期“睡眠质量差”及“运动量不足”有关。',
    recommendations: [
      '立即静坐休息 10 分钟后复测',
      '今日饮食请严格控制盐分摄入（<5g）',
      '如复测仍高于 140/90，建议启动视频医生咨询'
    ]
  },
  { 
    id: '3', 
    title: '血氧', 
    value: '98', 
    unit: '%', 
    status: 'Normal', 
    icon: 'Droplet', 
    color: 'text-cyan-500', 
    date: '10:00', 
    trend: 'stable',
     history: [
      { time: '08:00', value: 97 }, { time: '09:00', value: 98 }, { time: '10:00', value: 98 }
    ]
  },
  { 
    id: '4', 
    title: '睡眠', 
    value: '6h 15m', 
    unit: '', 
    status: 'Warning', 
    icon: 'Moon', 
    color: 'text-indigo-500', 
    date: '昨晚', 
    trend: 'down',
    analysis: '深睡比例不足 15%，属于低质量睡眠。可能导致次日血压波动。',
    recommendations: ['尝试睡前温水泡脚', '避免睡前查看手机']
  },
  { id: '5', title: '体温', value: '36.5', unit: '°C', status: 'Normal', icon: 'Thermometer', color: 'text-orange-500', date: '08:00', trend: 'stable' },
  { id: '6', title: '血糖', value: '5.8', unit: 'mmol/L', status: 'Normal', icon: 'Utensils', color: 'text-pink-500', date: '空腹', trend: 'up' },
];

export const ACTIVE_ALERTS: Alert[] = [
  {
    id: 'a1',
    type: 'Warning',
    message: '监测到您的血压偏高 (142/91)，且今日尚未记录服药。',
    actionLabel: '确认已服药',
    actionType: 'measure',
    timestamp: '09:35'
  }
];

export const DAILY_TASKS: DailyTask[] = [
  { id: 't1', title: '服用降压药', description: '苯磺酸氨氯地平片 5mg', type: 'medication', completed: false, time: '08:00', urgent: true },
  { id: 't2', title: '血压测量', description: '早晨空腹测量', type: 'measurement', completed: true, time: '09:30' },
  { id: 't3', title: '有氧运动', description: '快走或慢跑 30分钟', type: 'exercise', completed: false, time: '17:00' },
  { id: 't4', title: '睡前心电监测', description: '佩戴心电贴监测睡眠', type: 'measurement', completed: false, time: '22:00' },
];

export const MY_DEVICES = [
  { name: DeviceType.WATCH, status: '已连接', battery: 80 },
  { name: DeviceType.ECG_STICKER, status: '未佩戴', battery: 0 },
  { name: DeviceType.BP_MONITOR, status: '离线', battery: 45 },
];

export const HEART_RATE_DATA = [
  { time: '00:00', value: 65 },
  { time: '04:00', value: 62 },
  { time: '08:00', value: 75 },
  { time: '09:30', value: 88 }, // Peak during BP measurement
  { time: '12:00', value: 80 },
  { time: '16:00', value: 76 },
];

// Comprehensive Health Formula Library
export const HEALTH_FORMULAS: HealthFormula[] = [
  {
    id: 'f1',
    category: '慢病干预',
    name: '稳糖控糖配方',
    triggerDesc: '血糖/糖化血红蛋白异常 或 高血糖风险',
    dietPlan: {
      title: '低GI/GL饮食策略',
      description: '平稳餐后血糖波动',
      items: ['推荐全谷物（燕麦、荞麦）', '增加叶菜摄入', '严格控制精制碳水']
    },
    exercisePlan: {
      title: '餐后微动计划',
      description: '利用肌肉收缩促进糖摄取',
      items: ['餐后30-60分钟低强度步行', '简单的抗阻训练']
    },
    matchLogic: '根据血糖及糖化血红蛋白数据自动推荐此方案。'
  },
  {
    id: 'f2',
    category: '慢病干预',
    name: '降压护航配方',
    triggerDesc: '收缩压/舒张压偏高 或 高血压风险',
    dietPlan: {
      title: 'DASH饮食改良版',
      description: '低钠高钾，辅助降压',
      items: ['推荐高钾食物（深色蔬菜、香蕉）', '增加高镁高钙食物（坚果）', '强制限盐提醒（每日<5g）']
    },
    exercisePlan: {
      title: '等长收缩训练',
      description: '改善血管弹性',
      items: ['靠墙静蹲', '握力器训练']
    },
    matchLogic: '基于血压数据监测到数值偏高，自动激活此降压方案。'
  },
  {
    id: 'f3',
    category: '慢病干预',
    name: '降脂护心配方',
    triggerDesc: '血脂超标 或 心脏病家族史/肥胖',
    dietPlan: {
      title: 'Omega-3 强化饮食',
      description: '调节血脂代谢',
      items: ['增加深海鱼类（三文鱼）', '控制反式/饱和脂肪摄入']
    },
    exercisePlan: {
      title: '持续有氧运动',
      description: '促进脂肪氧化',
      items: ['快走/游泳/骑车', '每天至少30分钟']
    },
    matchLogic: '根据血脂数据及个人风险评估推荐。'
  },
  {
    id: 'f4',
    category: '慢病干预',
    name: '肝脏修复配方',
    triggerDesc: '肝功能异常 或 饮酒习惯/脂肪肝',
    dietPlan: {
      title: '低脂高纤护肝餐',
      description: '减轻肝脏代谢负担',
      items: ['富含膳食纤维（绿叶菜、燕麦）', '增加抗氧化食物（蓝莓）']
    },
    exercisePlan: {
      title: '低强度有氧',
      description: '促进代谢，避免过度劳累',
      items: ['快步走', '瑜伽']
    },
    matchLogic: '检测到“轻度脂肪肝”病历记录，自动匹配护肝方案。'
  },
  {
    id: 'f5',
    category: '身心调节',
    name: '助眠舒压配方',
    triggerDesc: '深睡比例低/HRV低 或 睡眠障碍',
    dietPlan: {
      title: '色氨酸与镁强化',
      description: '自然助眠营养素',
      items: ['富含色氨酸（牛奶、小米）', '富含镁（香蕉、菠菜）', '剔除晚餐咖啡因']
    },
    exercisePlan: {
      title: '晚间舒缓引导',
      description: '降低皮质醇水平',
      items: ['晚间冥想', '低强度拉伸']
    },
    matchLogic: '自动识别睡眠质量差（深睡不足）和压力指数，推荐此方案。'
  },
  {
    id: 'f6',
    category: '代谢矫正',
    name: '痛风与高尿酸干预',
    triggerDesc: '尿酸值超标 或 饮酒/BMI超标',
    dietPlan: {
      title: '低嘌呤饮食',
      description: '减少尿酸生成',
      items: ['严格控制动物内脏/海鲜浓汤', '每日饮水 > 2000ml']
    },
    exercisePlan: {
      title: '无酸运动模式',
      description: '避免乳酸堆积抑制尿酸排泄',
      items: ['推荐慢走、太极', '屏蔽快跑、举重']
    },
    matchLogic: '基于代谢风险评估自动推荐。'
  }
];

// Mock Reports Data
export const MOCK_REPORTS: HealthReport[] = [
  { id: 1, title: '每周健康分析周报', type: 'weekly', date: '2023-10-24', status: 'Warning', tag: '血压波动', author: 'Life Guardian AI' },
  { id: 2, title: '湘雅二医院血常规检查', type: 'medical', date: '2023-10-12', status: 'Normal', tag: '定期复查', author: '医院数据同步' },
  { id: 3, title: '9月度健康综合解读', type: 'monthly', date: '2023-10-01', status: 'Normal', tag: '月度总结', author: '王主任 (审核)' },
  { id: 4, title: '24小时动态心电图监测', type: 'special', date: '2023-09-28', status: 'Critical', tag: '房颤预警', author: '设备自动生成' },
];
