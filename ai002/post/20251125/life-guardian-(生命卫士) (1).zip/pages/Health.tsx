import React, { useState, useEffect } from 'react';
import { FileText, ChevronRight, ClipboardList, TrendingUp, Apple, Dumbbell, Activity, HeartPulse, Brain, Pill, ShoppingBag, Check, ChefHat, Play, Clock, Calendar, Wind, Smile, X, Moon, Volume2, CloudRain, Pause, Music, BarChart as BarChartIcon, Users, AlertTriangle, CheckCircle2, ArrowRight, Camera, Scan, Truck, CreditCard, Sparkles, Flame, Shield } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie } from 'recharts';
import { RISK_PROFILE, MEDICINE_CABINET, FAMILY_MEMBERS, HEALTH_FORMULAS, CURRENT_USER, MOCK_METRICS } from '../constants';
import FullScreenPage from '../components/FullScreenPage';
import { HealthFormula } from '../types';

const Health: React.FC = () => {
  const [refillStatus, setRefillStatus] = useState<Record<string, boolean>>({});
  const [activeFormula, setActiveFormula] = useState<HealthFormula | null>(null);
  const [matchedFormulas, setMatchedFormulas] = useState<HealthFormula[]>([]);
  
  // State to track completed action items in the formula detail view
  const [actionPlanProgress, setActionPlanProgress] = useState<Record<string, boolean>>({});

  const [activeService, setActiveService] = useState<'food_scan' | 'medicine_order' | null>(null);
  const [activeQuestionnaire, setActiveQuestionnaire] = useState<string | null>(null);
  const [selectedMedicine, setSelectedMedicine] = useState<string | null>(null);
  const [activeReport, setActiveReport] = useState<'weekly' | 'monthly' | 'family' | null>(null);
  
  // Food Scanner States
  const [scanState, setScanState] = useState<'idle' | 'scanning' | 'analyzing' | 'result'>('idle');

  const [showBreathing, setShowBreathing] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [breathCount, setBreathCount] = useState(0);

  // Smart Matching Engine Logic
  useEffect(() => {
      const matches: HealthFormula[] = [];
      const userConditions = CURRENT_USER.conditions.join(' ');
      
      // 1. Check BP for "Hypertension Guard"
      const bpMetric = MOCK_METRICS.find(m => m.title === '血压');
      if (bpMetric && (bpMetric.status === 'Warning' || bpMetric.status === 'Critical') || userConditions.includes('高血压')) {
          const formula = HEALTH_FORMULAS.find(f => f.name === '降压护航配方');
          if (formula) matches.push(formula);
      }

      // 2. Check Sleep for "Sleep Aid"
      const sleepMetric = MOCK_METRICS.find(m => m.title === '睡眠');
      if ((sleepMetric && sleepMetric.status === 'Warning') || RISK_PROFILE.sleepQuality !== 'Good') {
          const formula = HEALTH_FORMULAS.find(f => f.name === '助眠舒压配方');
          if (formula) matches.push(formula);
      }

      // 3. Check Conditions for "Liver Repair"
      if (userConditions.includes('脂肪肝')) {
          const formula = HEALTH_FORMULAS.find(f => f.name === '肝脏修复配方');
          if (formula) matches.push(formula);
      }
      
      // 4. Fallback or additional checks (Diabetes, etc.)
      if (userConditions.includes('糖尿病') || RISK_PROFILE.diabetesRisk === 'High') {
           const formula = HEALTH_FORMULAS.find(f => f.name === '稳糖控糖配方');
           if (formula) matches.push(formula);
      }

      setMatchedFormulas(matches);
  }, []);

  const handleRefill = (id: string) => {
    setSelectedMedicine(id);
    setActiveService('medicine_order');
  };

  const confirmOrder = () => {
      if (selectedMedicine) {
          setRefillStatus(prev => ({ ...prev, [selectedMedicine]: true }));
      }
      setTimeout(() => { 
          alert("订单已提交！药师审核后发货。");
          setActiveService(null);
          setSelectedMedicine(null);
      }, 500); 
  };

  const toggleProgress = (key: string) => {
      setActionPlanProgress(prev => ({
          ...prev,
          [key]: !prev[key]
      }));
  };

  // Breathing Exercise Logic
  useEffect(() => {
    let interval: any;
    if (showBreathing) {
        let cycle = 0;
        const runCycle = () => {
            setBreathPhase('Inhale');
            setTimeout(() => {
                setBreathPhase('Hold');
                setTimeout(() => {
                    setBreathPhase('Exhale');
                    setTimeout(() => {
                        cycle++;
                        setBreathCount(cycle);
                        if (showBreathing) runCycle();
                    }, 4000); // Exhale 4s
                }, 2000); // Hold 2s
            }, 4000); // Inhale 4s
        };
        runCycle();
    }
    return () => clearTimeout(interval);
  }, [showBreathing]);

  // Mock Scanning Logic
  useEffect(() => {
      if (scanState === 'scanning') {
          setTimeout(() => setScanState('analyzing'), 2000);
      }
      if (scanState === 'analyzing') {
          setTimeout(() => setScanState('result'), 1500);
      }
  }, [scanState]);

  const questionnaires = [
    { title: '饮食筛查问卷_湘', status: '待完成', color: 'text-orange-500' },
    { title: '基础初筛睡眠障碍问卷', status: '已完成', color: 'text-green-500' },
    { title: '心脑血管风险评估', status: '建议重测', color: 'text-red-500' },
  ];

  const getRiskColor = (risk: string) => {
      if (risk === 'High') return 'text-red-500 bg-red-50 border-red-100';
      if (risk === 'Medium') return 'text-orange-500 bg-orange-50 border-orange-100';
      return 'text-green-500 bg-green-50 border-green-100';
  };

  // --- Sub-Page Renderers ---
  
  // Health Formula Detail Page
  const renderFormulaDetail = () => {
      if (!activeFormula) return null;
      
      const isHypertension = activeFormula.name === '降压护航配方';
      
      // Calculate progress
      const totalItems = activeFormula.dietPlan.items.length + activeFormula.exercisePlan.items.length;
      const completedCount = activeFormula.dietPlan.items.filter((_, i) => actionPlanProgress[`${activeFormula.id}-diet-${i}`]).length +
                             activeFormula.exercisePlan.items.filter((_, i) => actionPlanProgress[`${activeFormula.id}-exercise-${i}`]).length;
      const progressPercent = Math.round((completedCount / totalItems) * 100);
      
      return (
        <FullScreenPage title={activeFormula.name} onClose={() => setActiveFormula(null)}>
            <div className="p-4 space-y-6 bg-[#F2F2F7] min-h-screen">
                {/* Match Reason */}
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-5 text-white shadow-lg">
                    <div className="flex items-center space-x-2 mb-2">
                        <Sparkles size={18} className="text-yellow-300" />
                        <span className="font-bold text-sm">AI 智能匹配原因</span>
                    </div>
                    <p className="text-sm text-blue-100 leading-relaxed">
                        {activeFormula.matchLogic}
                    </p>
                </div>

                {/* NEW: Action Plan Section */}
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-blue-50">
                     <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                            <div className="p-2 bg-blue-100 text-blue-600 rounded-xl">
                                <ClipboardList size={24} />
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-900">今日执行计划</h3>
                                <div className="text-xs text-gray-500">跟随指引，达成健康目标</div>
                            </div>
                        </div>
                        <div className="flex flex-col items-end">
                            <span className="text-2xl font-bold text-blue-600">{progressPercent}%</span>
                            <span className="text-[10px] text-gray-400">完成度</span>
                        </div>
                     </div>
                     
                     {/* Progress Bar */}
                     <div className="w-full bg-gray-100 h-2 rounded-full mb-6 overflow-hidden">
                         <div 
                            className="h-full bg-blue-500 rounded-full transition-all duration-500"
                            style={{ width: `${progressPercent}%` }}
                         ></div>
                     </div>

                     <div className="space-y-3">
                         {/* Diet Actions */}
                         {activeFormula.dietPlan.items.map((item, i) => {
                             const key = `${activeFormula.id}-diet-${i}`;
                             const isDone = actionPlanProgress[key];
                             return (
                                 <div key={key} onClick={() => toggleProgress(key)} className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${isDone ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-100 hover:border-blue-200'}`}>
                                     <div className="flex items-center space-x-3">
                                         <div className={`p-2 rounded-full ${isDone ? 'bg-green-200 text-green-700' : 'bg-white text-gray-400'}`}>
                                             {isDone ? <CheckCircle2 size={16} /> : <ChefHat size={16} />}
                                         </div>
                                         <span className={`text-sm ${isDone ? 'text-green-800 font-medium line-through decoration-green-800/50' : 'text-gray-800'}`}>{item}</span>
                                     </div>
                                 </div>
                             )
                         })}

                         {/* Exercise Actions */}
                         {activeFormula.exercisePlan.items.map((item, i) => {
                             const key = `${activeFormula.id}-exercise-${i}`;
                             const isDone = actionPlanProgress[key];
                             return (
                                 <div key={key} onClick={() => toggleProgress(key)} className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${isDone ? 'bg-orange-50 border-orange-200' : 'bg-gray-50 border-gray-100 hover:border-blue-200'}`}>
                                     <div className="flex items-center space-x-3">
                                         <div className={`p-2 rounded-full ${isDone ? 'bg-orange-200 text-orange-700' : 'bg-white text-gray-400'}`}>
                                             {isDone ? <CheckCircle2 size={16} /> : <Dumbbell size={16} />}
                                         </div>
                                         <span className={`text-sm ${isDone ? 'text-orange-800 font-medium line-through decoration-orange-800/50' : 'text-gray-800'}`}>{item}</span>
                                     </div>
                                 </div>
                             )
                         })}
                     </div>
                </div>

                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wide px-1">方案详情百科</h3>

                {/* Diet Plan */}
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-green-50">
                     <div className="flex items-center space-x-2 mb-4">
                        <div className="p-2 bg-green-100 text-green-600 rounded-xl">
                            <Apple size={24} />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-900">{activeFormula.dietPlan.title}</h3>
                            <div className="text-xs text-gray-500">{activeFormula.dietPlan.description}</div>
                        </div>
                     </div>
                     <ul className="space-y-3">
                         {activeFormula.dietPlan.items.map((item, i) => (
                             <li key={i} className="flex items-start space-x-3 bg-green-50/50 p-3 rounded-xl">
                                 <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-green-500 shrink-0"></div>
                                 <span className="text-sm text-gray-800">{item}</span>
                             </li>
                         ))}
                     </ul>
                     {isHypertension && (
                         <button 
                            onClick={() => setActiveService('food_scan')}
                            className="mt-4 w-full flex items-center justify-center space-x-2 py-3 bg-green-50 text-green-700 font-bold rounded-xl active:bg-green-100 transition-colors"
                         >
                             <Camera size={18} />
                             <span>使用 AI 红绿灯扫描食物</span>
                         </button>
                     )}
                </div>

                {/* Exercise Plan */}
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-50">
                     <div className="flex items-center space-x-2 mb-4">
                        <div className="p-2 bg-orange-100 text-orange-600 rounded-xl">
                            <Flame size={24} />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-900">{activeFormula.exercisePlan.title}</h3>
                            <div className="text-xs text-gray-500">{activeFormula.exercisePlan.description}</div>
                        </div>
                     </div>
                     <ul className="space-y-3">
                         {activeFormula.exercisePlan.items.map((item, i) => (
                             <li key={i} className="flex items-start space-x-3 bg-orange-50/50 p-3 rounded-xl">
                                 <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0"></div>
                                 <span className="text-sm text-gray-800">{item}</span>
                             </li>
                         ))}
                     </ul>
                </div>
                
                <div className="h-safe-bottom"></div>
            </div>
        </FullScreenPage>
      );
  };

  // AI Food Scanner (Scenario 3 & 7)
  const renderFoodScanner = () => (
      <FullScreenPage title="AI 膳食红绿灯" onClose={() => { setActiveService(null); setScanState('idle'); }}>
          <div className="h-full flex flex-col bg-black relative">
              {scanState !== 'result' && (
                  <div className="absolute inset-0 bg-gray-900 flex flex-col items-center justify-center overflow-hidden">
                      {/* Viewfinder Overlay */}
                      <div className="absolute inset-0 z-10 border-[30px] border-black/50"></div>
                      
                      {scanState === 'idle' && (
                          <div className="z-20 text-center text-white space-y-8 animate-fade-in-up">
                             <div className="w-64 h-64 border-2 border-white/30 rounded-2xl flex items-center justify-center relative">
                                 <div className="absolute inset-0 border-2 border-dashed border-white/50 rounded-2xl animate-pulse"></div>
                                 <Scan size={48} className="opacity-50" />
                             </div>
                             <p className="font-medium">将食物放入框内</p>
                             <button 
                                onClick={() => setScanState('scanning')}
                                className="w-16 h-16 bg-white rounded-full border-4 border-gray-300 active:scale-95 transition-transform"
                             ></button>
                          </div>
                      )}

                      {scanState === 'scanning' && (
                          <div className="z-20 text-center text-white relative">
                              <div className="w-64 h-64 border-2 border-blue-500 rounded-2xl relative overflow-hidden bg-white/5">
                                  <div className="absolute top-0 left-0 right-0 h-1 bg-blue-500 shadow-[0_0_20px_rgba(59,130,246,1)] animate-[scan_2s_linear_infinite]"></div>
                              </div>
                              <p className="mt-8 font-medium animate-pulse">正在扫描食物成分...</p>
                          </div>
                      )}

                       {scanState === 'analyzing' && (
                          <div className="z-20 text-center text-white">
                              <div className="w-64 h-64 flex items-center justify-center">
                                  <Brain size={64} className="text-blue-500 animate-bounce" />
                              </div>
                              <p className="mt-8 font-medium">AI 正在计算钠含量与升糖指数...</p>
                          </div>
                      )}
                  </div>
              )}

              {scanState === 'result' && (
                  <div className="flex-1 bg-gray-50 flex flex-col animate-fade-in-up pb-safe">
                      <div className="h-64 bg-gray-200 relative">
                          {/* Mock Image */}
                          <div className="absolute inset-0 flex items-center justify-center bg-gray-300 text-gray-500">
                             [食物照片]
                          </div>
                          <div className="absolute bottom-4 right-4 bg-black/60 text-white px-3 py-1 rounded-full text-xs backdrop-blur-md">
                              AI 识别置信度 98%
                          </div>
                      </div>
                      
                      <div className="flex-1 p-6 -mt-6 bg-white rounded-t-3xl relative z-10">
                          <div className="flex justify-between items-start mb-6">
                              <div>
                                  <h2 className="text-2xl font-bold text-gray-900">红烧肉套餐</h2>
                                  <p className="text-sm text-gray-500 mt-1">含：五花肉 (150g), 白米饭 (200g)</p>
                              </div>
                              <div className="flex flex-col items-center">
                                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-1 shadow-sm">
                                      <div className="w-4 h-4 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.6)] animate-pulse"></div>
                                  </div>
                                  <span className="text-xs font-bold text-red-600">红灯预警</span>
                              </div>
                          </div>
                          
                          <div className="space-y-4">
                              <div className="bg-red-50 border border-red-100 p-4 rounded-2xl">
                                  <h3 className="font-bold text-red-800 text-sm mb-2 flex items-center">
                                      <AlertTriangle size={16} className="mr-2" />
                                      高血压风险提示
                                  </h3>
                                  <p className="text-sm text-red-700 leading-relaxed">
                                      检测到该餐<span className="font-bold">钠含量超标 (约 1200mg)</span>，且白米饭属于高 GI 食物。这可能导致您餐后 2 小时血压与血糖双重波动。
                                  </p>
                              </div>

                              <div className="bg-green-50 border border-green-100 p-4 rounded-2xl">
                                  <h3 className="font-bold text-green-800 text-sm mb-2 flex items-center">
                                      <ChefHat size={16} className="mr-2" />
                                      AI 调整建议
                                  </h3>
                                  <ul className="space-y-2 text-sm text-green-800">
                                      <li className="flex items-start">
                                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-1.5 mr-2"></div>
                                          建议只食用 2 块红烧肉。
                                      </li>
                                      <li className="flex items-start">
                                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-1.5 mr-2"></div>
                                          白米饭减半，或更换为随身携带的杂粮包。
                                      </li>
                                      <li className="flex items-start">
                                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-1.5 mr-2"></div>
                                          餐后请务必散步 20 分钟以平抑血糖。
                                      </li>
                                  </ul>
                              </div>
                          </div>

                          <button 
                            onClick={() => { setActiveService(null); setScanState('idle'); }}
                            className="w-full mt-8 bg-gray-900 text-white font-bold py-4 rounded-xl shadow-lg"
                          >
                              记录并采纳建议
                          </button>
                      </div>
                  </div>
              )}
          </div>
      </FullScreenPage>
  );

  // Smart Medicine Order (Scenario 14)
  const renderMedicineOrder = () => {
      const medicine = MEDICINE_CABINET.find(m => m.id === selectedMedicine);
      if (!medicine) return null;

      return (
        <FullScreenPage title="药品一键复购" onClose={() => { setActiveService(null); setSelectedMedicine(null); }}>
             <div className="p-4 space-y-4 bg-gray-50 min-h-full">
                 {/* Product Info */}
                 <div className="bg-white p-4 rounded-2xl shadow-sm flex items-start space-x-4">
                     <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
                         <Pill size={32} />
                     </div>
                     <div className="flex-1">
                         <div className="flex justify-between items-start">
                             <h3 className="font-bold text-gray-900 text-lg">{medicine.name}</h3>
                             <span className="text-lg font-bold text-red-500">¥28.5</span>
                         </div>
                         <p className="text-sm text-gray-500 mt-1">{medicine.dosage}</p>
                         <div className="mt-2 flex items-center text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded w-fit">
                             <CheckCircle2 size={12} className="mr-1" />
                             处方已由互联网医院审核
                         </div>
                     </div>
                 </div>

                 {/* Address */}
                 <div className="bg-white p-4 rounded-2xl shadow-sm">
                     <div className="flex justify-between items-center mb-3">
                         <h3 className="font-bold text-gray-900 text-sm">配送地址</h3>
                         <button className="text-xs text-blue-600">修改</button>
                     </div>
                     <div className="flex items-start space-x-3">
                         <div className="p-2 bg-gray-100 rounded-full">
                             <Truck size={16} className="text-gray-600" />
                         </div>
                         <div>
                             <div className="font-bold text-gray-900 text-sm">张伟 (先生) 138****8293</div>
                             <div className="text-xs text-gray-500 mt-0.5">北京市朝阳区... 生命卫士家园 2-301</div>
                             <div className="text-xs text-orange-500 mt-2 font-medium">预计明日 (周五) 10:00 前送达</div>
                         </div>
                     </div>
                 </div>

                 {/* Payment */}
                 <div className="bg-white p-4 rounded-2xl shadow-sm">
                     <h3 className="font-bold text-gray-900 text-sm mb-3">支付方式</h3>
                     <div className="flex items-center justify-between p-3 border border-blue-500 bg-blue-50 rounded-xl">
                         <div className="flex items-center space-x-3">
                             <CreditCard size={20} className="text-blue-600" />
                             <div>
                                 <div className="font-bold text-gray-900 text-sm">医保个人账户支付</div>
                                 <div className="text-xs text-gray-500">余额充足</div>
                             </div>
                         </div>
                         <CheckCircle2 size={20} className="text-blue-600" />
                     </div>
                 </div>

                 {/* Footer Action */}
                 <div className="fixed bottom-0 left-0 right-0 bg-white p-4 border-t border-gray-100 safe-bottom">
                     <div className="flex justify-between items-center mb-4 px-2">
                         <span className="text-gray-500 text-sm">合计</span>
                         <span className="text-2xl font-bold text-red-500">¥28.50</span>
                     </div>
                     <button 
                        onClick={confirmOrder}
                        className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg active:scale-95 transition-transform"
                     >
                         立即支付并极速发货
                     </button>
                 </div>
             </div>
        </FullScreenPage>
      );
  };

  const renderBreathingExercise = () => (
      <div className="fixed inset-0 z-[70] bg-[#1a2332] flex flex-col items-center justify-center text-white animate-fade-in-up">
          <button onClick={() => setShowBreathing(false)} className="absolute top-12 right-6 p-2 bg-white/10 rounded-full">
              <X size={24} />
          </button>
          
          <h2 className="text-2xl font-light mb-8 opacity-90">身心减压</h2>
          
          <div className="relative flex items-center justify-center w-64 h-64 mb-12">
              <div className={`absolute inset-0 rounded-full border border-blue-400/30 transition-all duration-[4000ms] ease-in-out ${breathPhase === 'Inhale' ? 'scale-110 opacity-100' : breathPhase === 'Exhale' ? 'scale-50 opacity-50' : 'scale-110 opacity-80'}`}></div>
              <div className={`absolute inset-4 rounded-full bg-gradient-to-b from-blue-500 to-indigo-600 shadow-2xl shadow-blue-500/50 transition-all duration-[4000ms] ease-in-out flex items-center justify-center ${breathPhase === 'Inhale' ? 'scale-100' : breathPhase === 'Exhale' ? 'scale-50' : 'scale-100'}`}>
                   <span className="text-3xl font-bold">{breathPhase === 'Inhale' ? '吸气' : breathPhase === 'Hold' ? '屏气' : '呼气'}</span>
              </div>
          </div>
          
          <p className="text-lg opacity-80 font-medium">
              {breathPhase === 'Inhale' ? '用鼻子深深吸气...' : breathPhase === 'Hold' ? '保持气息...' : '用嘴缓慢呼气...'}
          </p>

          <div className="absolute bottom-20 text-sm text-gray-400">
              已完成 {breathCount} 次循环
          </div>
      </div>
  );

  const renderQuestionnaire = () => (
    <FullScreenPage title={activeQuestionnaire || "健康问卷"} onClose={() => setActiveQuestionnaire(null)}>
        <div className="p-4 flex flex-col h-full">
            <div className="flex-1 space-y-6">
                 <div className="w-full h-2 bg-gray-100 rounded-full mb-6">
                    <div className="w-1/3 h-full bg-blue-500 rounded-full"></div>
                 </div>
                 <h2 className="text-xl font-bold text-gray-900">1. 您过去一周摄入腌制食品（如咸菜、腊肉）的频率是？</h2>
                 <div className="space-y-3">
                    {['从不', '每周 1-2 次', '每周 3-5 次', '几乎每天'].map(opt => (
                        <button key={opt} className="w-full p-4 text-left bg-white border border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 font-medium transition-colors">
                            {opt}
                        </button>
                    ))}
                 </div>
            </div>
            <div className="pt-4">
                <p className="text-center text-xs text-gray-400 mb-4">本问卷由湘雅医院提供专业支持</p>
            </div>
        </div>
    </FullScreenPage>
  );

  return (
    <div className="pb-24 bg-[#F2F2F7] min-h-screen">
      {activeFormula && renderFormulaDetail()}
      {activeService === 'food_scan' && renderFoodScanner()}
      {activeService === 'medicine_order' && renderMedicineOrder()}
      
      {activeQuestionnaire && renderQuestionnaire()}
      {showBreathing && renderBreathingExercise()}

      <div className="bg-[#F2F2F7]/90 backdrop-blur-md pt-12 pb-4 px-4 sticky top-0 z-10 safe-top flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">健康画像</h1>
        <div className="flex items-center space-x-1 bg-white px-3 py-1 rounded-full shadow-sm">
            <span className="text-sm font-bold text-blue-600">{RISK_PROFILE.healthScore}</span>
            <span className="text-xs text-gray-400">/100</span>
        </div>
      </div>

      <div className="px-4 space-y-6">
        
        {/* Risk Assessment Radar */}
        <section>
            <div className="bg-white rounded-3xl p-5 shadow-sm">
                <h2 className="text-sm font-bold text-gray-900 mb-4 flex items-center">
                    <Activity size={16} className="mr-2 text-blue-500" />
                    当前风险评估
                </h2>
                <div className="grid grid-cols-2 gap-3">
                    <div className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${getRiskColor(RISK_PROFILE.cvdRisk)}`}>
                        <HeartPulse size={24} className="mb-2" />
                        <span className="text-xs font-medium opacity-70">心血管风险</span>
                        <span className="text-lg font-bold">{RISK_PROFILE.cvdRisk === 'Medium' ? '中风险' : RISK_PROFILE.cvdRisk === 'High' ? '高风险' : '低风险'}</span>
                    </div>
                    <div className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${getRiskColor(RISK_PROFILE.diabetesRisk)}`}>
                        <TrendingUp size={24} className="mb-2" />
                        <span className="text-xs font-medium opacity-70">糖尿病风险</span>
                        <span className="text-lg font-bold">{RISK_PROFILE.diabetesRisk === 'Medium' ? '中风险' : RISK_PROFILE.diabetesRisk === 'High' ? '高风险' : '低风险'}</span>
                    </div>
                    <div className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center active:scale-95 transition-transform cursor-pointer ${getRiskColor(RISK_PROFILE.sleepQuality === 'Poor' ? 'High' : RISK_PROFILE.sleepQuality === 'Fair' ? 'Medium' : 'Low')}`}>
                        <Brain size={24} className="mb-2" />
                        <span className="text-xs font-medium opacity-70">睡眠质量</span>
                        <span className="text-lg font-bold flex items-center">{RISK_PROFILE.sleepQuality === 'Poor' ? '差' : RISK_PROFILE.sleepQuality === 'Fair' ? '一般' : '优'}</span>
                    </div>
                    <div className="p-3 rounded-2xl border border-gray-100 bg-gray-50 flex flex-col items-center justify-center text-center text-gray-400">
                         <span className="text-xs">更多风险维度</span>
                         <span className="text-xs">计算中...</span>
                    </div>
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-xl text-xs text-blue-700 leading-relaxed">
                    💡 建议：由于心血管风险评估为中风险，且近期血压波动，建议增加有氧运动频次，并严格控制盐分摄入。
                </div>
            </div>
        </section>

        {/* NEW: AI Smart Formulas */}
        <section>
          <div className="flex justify-between items-center mb-3 px-1">
             <div className="flex items-center space-x-2">
                 <Sparkles size={18} className="text-indigo-600" />
                 <h2 className="text-lg font-bold text-gray-900">AI 专属配方</h2>
             </div>
             <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full font-bold">已匹配 {matchedFormulas.length} 个方案</span>
          </div>
          
          <div className="space-y-3">
              {matchedFormulas.map(formula => (
                  <div 
                    key={formula.id}
                    onClick={() => setActiveFormula(formula)}
                    className="bg-white p-4 rounded-2xl shadow-sm border border-indigo-50 active:scale-95 transition-transform relative overflow-hidden group"
                  >
                      {/* Decoration */}
                      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-indigo-50 to-white rounded-bl-full -z-0"></div>
                      
                      <div className="flex justify-between items-start relative z-10">
                          <div>
                              <div className="flex items-center space-x-2">
                                  <h3 className="font-bold text-gray-900">{formula.name}</h3>
                                  <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">{formula.category}</span>
                              </div>
                              <p className="text-xs text-indigo-500 mt-1 font-medium flex items-center">
                                  <Shield size={12} className="mr-1" />
                                  触发：{formula.triggerDesc}
                              </p>
                          </div>
                          <ChevronRight size={18} className="text-gray-300" />
                      </div>
                      
                      <div className="mt-4 grid grid-cols-2 gap-3 relative z-10">
                          <div className="flex items-center space-x-2 text-xs text-gray-600 bg-gray-50 p-2 rounded-lg">
                              <Apple size={14} className="text-green-600" />
                              <span className="truncate">{formula.dietPlan.title}</span>
                          </div>
                          <div className="flex items-center space-x-2 text-xs text-gray-600 bg-gray-50 p-2 rounded-lg">
                              <Flame size={14} className="text-orange-600" />
                              <span className="truncate">{formula.exercisePlan.title}</span>
                          </div>
                      </div>
                  </div>
              ))}
              
              {matchedFormulas.length === 0 && (
                  <div className="bg-white p-6 rounded-2xl shadow-sm text-center text-gray-500 text-sm">
                      暂无需要特别干预的健康问题，继续保持！
                  </div>
              )}
          </div>
        </section>

        {/* Scenario 2: Smart Medicine Cabinet */}
        <section>
          <div className="flex justify-between items-center mb-3 px-1">
             <h2 className="text-lg font-bold text-gray-900 flex items-center">
                 <Pill className="mr-2 text-indigo-500" size={20} />
                 智能药箱
             </h2>
             <button className="text-xs text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg font-medium">用药记录</button>
          </div>
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
             {MEDICINE_CABINET.map((med, idx) => {
                 const percentage = (med.stock / med.totalStock) * 100;
                 const isLow = percentage < 20;

                 return (
                    <div key={med.id} className="p-4 border-b border-gray-100 last:border-0">
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="font-bold text-gray-900">{med.name}</h3>
                                <p className="text-xs text-gray-500 mt-0.5">{med.dosage}</p>
                                <div className="flex space-x-1 mt-1.5">
                                    {med.tags.map(tag => (
                                        <span key={tag} className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{tag}</span>
                                    ))}
                                </div>
                            </div>
                            <div className="text-right">
                                <span className={`text-sm font-bold ${isLow ? 'text-red-500' : 'text-gray-900'}`}>{med.stock}</span>
                                <span className="text-xs text-gray-400">/{med.totalStock}</span>
                            </div>
                        </div>
                        {/* Progress Bar */}
                        <div className="mt-3 relative h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div 
                                className={`absolute left-0 top-0 h-full rounded-full ${isLow ? 'bg-red-500' : 'bg-green-500'}`} 
                                style={{ width: `${percentage}%` }}
                            />
                        </div>
                        {isLow && (
                            <div className="mt-3 flex items-center justify-between bg-red-50 p-2 rounded-lg">
                                {refillStatus[med.id] ? (
                                    <div className="flex items-center space-x-2 text-green-600 animate-fade-in-up">
                                        <Check size={16} />
                                        <span className="text-xs font-bold">续药申请已提交</span>
                                    </div>
                                ) : (
                                    <>
                                        <span className="text-xs text-red-700 font-medium">余量不足，建议及时续方</span>
                                        <button 
                                            onClick={() => handleRefill(med.id)}
                                            className="flex items-center space-x-1 bg-white text-red-600 px-3 py-1 rounded-full text-xs font-bold shadow-sm border border-red-100 active:scale-95 transition-transform"
                                        >
                                            <ShoppingBag size={12} />
                                            <span>一键续药</span>
                                        </button>
                                    </>
                                )}
                            </div>
                        )}
                    </div>
                 );
             })}
          </div>
        </section>

        {/* Questionnaires */}
        <section>
          <h2 className="text-lg font-bold text-gray-900 mb-3 px-1">待办评估</h2>
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            {questionnaires.map((q, idx) => (
              <div 
                key={idx} 
                onClick={() => setActiveQuestionnaire(q.title)}
                className="flex items-center justify-between p-4 border-b border-gray-100 last:border-0 active:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3">
                  <ClipboardList size={18} className="text-gray-400" />
                  <span className="text-sm font-medium text-gray-900">{q.title}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`text-xs ${q.color}`}>{q.status}</span>
                  <ChevronRight size={14} className="text-gray-300" />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Health;