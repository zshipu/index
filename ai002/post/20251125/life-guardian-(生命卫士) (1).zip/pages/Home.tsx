import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Plus, ShieldCheck, Video, Zap, Bell, CheckCircle2, Circle, AlertTriangle, ArrowRight, Battery, Phone, Activity, AlertCircle, Clock, Star, Calendar, Upload, FileText, Camera, Save, MapPin, Navigation, Siren, X, Radio, HeartPulse, Wind, Armchair, PlayCircle, RotateCw, Play, Pause, Music } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { CURRENT_USER, FAMILY_MEMBERS, MOCK_METRICS, HEART_RATE_DATA, ACTIVE_ALERTS, DAILY_TASKS, TODAY_FORECAST } from '../constants';
import MetricCard from '../components/MetricCard';
import FullScreenPage from '../components/FullScreenPage';
import { HealthMetric, Alert, DailyTask } from '../types';

interface HomeProps {
  onMetricClick?: (metric: HealthMetric) => void;
}

const Home: React.FC<HomeProps> = ({ onMetricClick }) => {
  const [showFamilyMenu, setShowFamilyMenu] = useState(false);
  const [currentUser, setCurrentUser] = useState(CURRENT_USER);
  const [activeService, setActiveService] = useState<'video' | 'report' | 'location' | 'stress_relief' | null>(null);
  const [activeTask, setActiveTask] = useState<DailyTask | null>(null);
  const [showAddFamily, setShowAddFamily] = useState(false);
  
  // Stress Relief States
  const [stressTimer, setStressTimer] = useState(180); // 3 minutes
  const [isStressPlaying, setIsStressPlaying] = useState(false);

  // SOS States
  const [sosActive, setSosActive] = useState(false);
  const [sosCountdown, setSosCountdown] = useState(10);
  const [sosStatus, setSosStatus] = useState<'counting' | 'calling'>('counting');

  // SOS Countdown Logic
  useEffect(() => {
      let timer: any;
      if (sosActive && sosStatus === 'counting') {
          if (sosCountdown > 0) {
              timer = setTimeout(() => setSosCountdown(c => c - 1), 1000);
          } else {
              setSosStatus('calling');
          }
      }
      return () => clearTimeout(timer);
  }, [sosActive, sosStatus, sosCountdown]);

  // Stress Timer Logic
  useEffect(() => {
      let interval: any;
      if (isStressPlaying && stressTimer > 0) {
          interval = setInterval(() => {
              setStressTimer(prev => prev - 1);
          }, 1000);
      } else if (stressTimer === 0) {
          setIsStressPlaying(false);
      }
      return () => clearInterval(interval);
  }, [isStressPlaying, stressTimer]);

  const triggerSOS = () => {
      setSosActive(true);
      setSosStatus('counting');
      setSosCountdown(10);
  };

  const cancelSOS = () => {
      setSosActive(false);
      setSosStatus('counting');
      setSosCountdown(10);
  };

  const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const displayAlerts: Alert[] = currentUser.id === 'u1' ? ACTIVE_ALERTS : [{
      id: 'fa1', type: 'Critical', message: '父亲的心电监测显示可能有房颤迹象 (AFib)。', actionLabel: '一键提醒父亲', actionType: 'remind_family', timestamp: '10:15'
  }];

  const handleAlertAction = (actionType?: string) => {
      if (actionType === 'remind_family') alert(`已发送语音提醒给 ${currentUser.name}，并同步通知了家庭医生。`);
      if (actionType === 'measure' && onMetricClick) {
         const bpMetric = MOCK_METRICS.find(m => m.title === '血压');
         if (bpMetric) onMetricClick(bpMetric);
      }
  };

  const handleProcessTask = (task: DailyTask) => {
      setActiveTask(task);
  };

  const closeTask = () => {
      setActiveTask(null);
  };

  // --- Sub-Page Renderers ---
  
  // 1. Video Doctor Service
  const renderVideoDoctor = () => (
    <FullScreenPage title="视频医生" onClose={() => setActiveService(null)}>
        <div className="p-4 space-y-4">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-6 text-white text-center shadow-lg">
                <Video size={48} className="mx-auto mb-4 opacity-90" />
                <h2 className="text-2xl font-bold mb-2">7x24小时 实时连线</h2>
                <p className="text-emerald-100 mb-6">三甲全科医生在线坐诊，平均接通时间 &lt; 30秒</p>
                <button className="w-full bg-white text-teal-600 font-bold py-3 rounded-full shadow-md active:scale-95 transition-transform flex items-center justify-center space-x-2">
                    <Phone size={20} />
                    <span>立即呼叫</span>
                </button>
            </div>
            
            <h3 className="font-bold text-gray-900 mt-6">在线专家</h3>
            <div className="space-y-3">
                {[1, 2, 3].map(i => (
                    <div key={i} className="bg-white p-4 rounded-xl shadow-sm flex items-center space-x-4">
                        <img src={`https://picsum.photos/10${i}/10${i}`} className="w-12 h-12 rounded-full object-cover" />
                        <div className="flex-1">
                            <div className="font-bold text-gray-900">李医生 <span className="text-xs font-normal text-gray-500">主治医师</span></div>
                            <div className="text-xs text-gray-500">擅长：高血压、心血管慢病管理</div>
                            <div className="flex items-center text-xs text-orange-500 mt-1">
                                <Star size={10} fill="currentColor" /> 4.9 (2000+ 咨询)
                            </div>
                        </div>
                        <button className="px-4 py-2 bg-gray-100 text-gray-900 text-xs font-bold rounded-lg">预约</button>
                    </div>
                ))}
            </div>
        </div>
    </FullScreenPage>
  );

  // 2. Report Interpretation Service
  const renderReportService = () => (
    <FullScreenPage title="报告专家解读" onClose={() => setActiveService(null)}>
        <div className="p-4 space-y-6">
            <div className="bg-purple-50 border border-purple-100 p-4 rounded-xl flex items-start space-x-3">
                <ShieldCheck className="text-purple-600 mt-1" size={24} />
                <div>
                    <h3 className="font-bold text-purple-900">专业二次诊断</h3>
                    <p className="text-xs text-purple-700 mt-1">上传您的医院检查报告（CT、核磁、血检等），由三甲医院副主任以上医师为您详细解读。</p>
                </div>
            </div>

            <div>
                <h3 className="font-bold text-gray-900 mb-3">上传报告</h3>
                <div className="grid grid-cols-2 gap-4">
                    <button className="aspect-square bg-white border-2 border-dashed border-gray-300 rounded-2xl flex flex-col items-center justify-center text-gray-400 active:bg-gray-50 transition-colors">
                        <Camera size={32} className="mb-2" />
                        <span className="text-xs font-medium">拍照上传</span>
                    </button>
                    <button className="aspect-square bg-white border-2 border-dashed border-gray-300 rounded-2xl flex flex-col items-center justify-center text-gray-400 active:bg-gray-50 transition-colors">
                        <Upload size={32} className="mb-2" />
                        <span className="text-xs font-medium">从相册选择</span>
                    </button>
                </div>
            </div>

            <div>
                 <h3 className="font-bold text-gray-900 mb-3">历史解读记录</h3>
                 <div className="bg-white rounded-xl shadow-sm p-4 flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <FileText className="text-blue-500" size={20} />
                        <div>
                            <div className="text-sm font-medium">血生化检查报告.jpg</div>
                            <div className="text-xs text-gray-400">2023-10-12 • 已解读</div>
                        </div>
                    </div>
                    <ArrowRight size={16} className="text-gray-300" />
                 </div>
            </div>
        </div>
    </FullScreenPage>
  );

  // 3. Location/Safety Map
  const renderLocationMap = () => (
    <FullScreenPage title="家庭守护地图" onClose={() => setActiveService(null)}>
        <div className="relative w-full h-full bg-gray-100">
            {/* Mock Map Background */}
            <div className="absolute inset-0 bg-gray-200 flex items-center justify-center overflow-hidden">
                <div className="w-[200%] h-[200%] opacity-20 bg-[radial-gradient(circle,_#000_1px,_transparent_1px)] bg-[size:20px_20px]"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                     <div className="w-64 h-64 border-2 border-blue-500 rounded-full bg-blue-50/20 animate-pulse"></div>
                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                         <div className="relative">
                            <img src={FAMILY_MEMBERS[1].avatar} className="w-12 h-12 rounded-full border-2 border-white shadow-lg" />
                            <div className="absolute -bottom-2 -right-2 bg-green-500 rounded-full p-1 border border-white">
                                <Navigation size={10} className="text-white" />
                            </div>
                         </div>
                     </div>
                </div>
                <div className="absolute top-1/3 right-1/4">
                    <div className="bg-white p-2 rounded-lg shadow-md text-xs font-bold text-gray-700 whitespace-nowrap">
                        父亲 • 步行中
                    </div>
                </div>
            </div>

            {/* Bottom Status Card */}
            <div className="absolute bottom-12 left-4 right-4 bg-white rounded-2xl p-4 shadow-xl safe-bottom">
                 <div className="flex items-center space-x-4 mb-4">
                     <img src={FAMILY_MEMBERS[1].avatar} className="w-14 h-14 rounded-full object-cover" />
                     <div>
                         <h3 className="font-bold text-gray-900 text-lg">父亲</h3>
                         <div className="flex items-center text-sm text-green-600 mt-1">
                             <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                             安全区域内 (朝阳公园)
                         </div>
                     </div>
                 </div>
                 <div className="grid grid-cols-2 gap-3 text-center">
                     <div className="bg-gray-50 p-3 rounded-xl">
                         <div className="text-xs text-gray-500">离家时长</div>
                         <div className="font-bold text-gray-900 mt-1">45 分钟</div>
                     </div>
                     <div className="bg-gray-50 p-3 rounded-xl">
                         <div className="text-xs text-gray-500">今日步数</div>
                         <div className="font-bold text-gray-900 mt-1">3,421 步</div>
                     </div>
                 </div>
                 <button className="w-full mt-4 bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg">
                     联系家人
                 </button>
            </div>
        </div>
    </FullScreenPage>
  );

  // 5. Office Stress Relief (New Scenario)
  const renderStressRelief = () => (
      <FullScreenPage title="办公室身心重置" onClose={() => setActiveService(null)}>
          <div className="flex flex-col h-full bg-[#1a2332] text-white">
              <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8">
                  <div className="relative">
                      {/* Pulse Animation Circle */}
                      <div className={`w-64 h-64 bg-blue-500/10 rounded-full flex items-center justify-center transition-all duration-1000 ${isStressPlaying ? 'animate-pulse scale-105' : ''}`}>
                          <div className="w-48 h-48 bg-blue-500/20 rounded-full flex items-center justify-center relative">
                             {/* Progress Ring */}
                             <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                                 <circle cx="50" cy="50" r="46" stroke="currentColor" strokeWidth="4" fill="transparent" className="text-blue-900/50" />
                                 <circle 
                                    cx="50" cy="50" r="46" 
                                    stroke="currentColor" strokeWidth="4" fill="transparent" 
                                    className="text-blue-400 transition-all duration-1000 ease-linear"
                                    strokeDasharray={289}
                                    strokeDashoffset={289 - (289 * (180 - stressTimer) / 180)}
                                 />
                             </svg>
                             <div className="absolute inset-0 flex flex-col items-center justify-center">
                                 <Wind size={40} className="text-blue-400 mb-2" />
                                 <span className="text-3xl font-light font-mono">{formatTime(stressTimer)}</span>
                             </div>
                          </div>
                      </div>
                  </div>
                  
                  <div className="text-center space-y-2">
                      <h2 className="text-2xl font-bold">颈椎放松引导</h2>
                      <p className="text-blue-200/60 text-sm">跟随音频指示，放松肩颈肌肉，平复心率。</p>
                  </div>
                  
                  <div className="w-full bg-white/5 p-4 rounded-2xl border border-white/10 backdrop-blur-sm">
                      <div className="flex justify-between items-center mb-4">
                          <span className="text-sm font-bold flex items-center">
                              <Music size={16} className="mr-2 text-blue-400" />
                              当前动作
                          </span>
                      </div>
                      <div className="text-lg font-medium text-center py-4">
                          {stressTimer > 150 ? "头部向左侧倾斜 45度" : stressTimer > 120 ? "头部向右侧倾斜 45度" : stressTimer > 60 ? "缓慢旋转颈部" : "闭眼深呼吸"}
                      </div>
                  </div>
              </div>
              
              <div className="p-6 safe-bottom">
                  <div className="grid grid-cols-2 gap-4">
                       <button 
                        onClick={() => setIsStressPlaying(!isStressPlaying)}
                        className={`w-full py-4 rounded-2xl font-bold shadow-lg flex items-center justify-center space-x-2 transition-colors ${isStressPlaying ? 'bg-yellow-500 text-white' : 'bg-blue-600 text-white'}`}
                      >
                          {isStressPlaying ? <Pause size={20} /> : <Play size={20} />}
                          <span>{isStressPlaying ? '暂停' : '开始训练'}</span>
                      </button>
                      <button 
                        onClick={() => { alert("训练完成！压力指数已下降。"); setActiveService(null); }}
                        className="w-full bg-white/10 text-white font-bold py-4 rounded-2xl border border-white/20"
                      >
                          结束
                      </button>
                  </div>
              </div>
          </div>
      </FullScreenPage>
  );

  // 4. Task Execution (Measurement/Medication)
  const renderTaskExecution = () => {
      if (!activeTask) return null;

      return (
        <FullScreenPage 
            title={activeTask.type === 'medication' ? '服药打卡' : '健康测量'} 
            onClose={closeTask}
        >
            <div className="p-6 flex flex-col items-center pt-12">
                <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-6 ${activeTask.type === 'medication' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'}`}>
                    {activeTask.type === 'medication' ? <CheckCircle2 size={48} /> : <Activity size={48} />}
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{activeTask.title}</h2>
                <p className="text-gray-500 text-center mb-8">{activeTask.description}</p>

                {activeTask.type === 'measurement' && (
                    <div className="w-full bg-white p-6 rounded-2xl shadow-sm space-y-4 mb-6">
                        <div className="text-sm font-bold text-gray-700">手动录入数值</div>
                        <div className="flex items-center border-b border-gray-200 py-2">
                             <input type="number" placeholder="120" className="text-3xl font-bold text-center w-full outline-none" autoFocus />
                             <span className="text-gray-400 font-medium">mmHg</span>
                        </div>
                        <div className="flex items-center border-b border-gray-200 py-2">
                             <input type="number" placeholder="80" className="text-3xl font-bold text-center w-full outline-none" />
                             <span className="text-gray-400 font-medium">mmHg</span>
                        </div>
                        <p className="text-xs text-gray-400 text-center">或连接蓝牙设备自动采集</p>
                    </div>
                )}
                
                {activeTask.type === 'medication' && (
                     <div className="w-full bg-white p-4 rounded-2xl shadow-sm space-y-4 mb-6 text-center">
                         <div className="text-sm text-gray-500">为了您的健康，请拍照记录服药</div>
                         <button className="w-full h-32 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center text-gray-400">
                             <Camera size={32} className="mb-2" />
                             <span className="text-xs">点击拍照上传</span>
                         </button>
                     </div>
                )}

                <button 
                    onClick={() => { alert('任务已完成！'); closeTask(); }}
                    className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg flex items-center justify-center space-x-2 active:scale-95 transition-transform"
                >
                    <Save size={20} />
                    <span>{activeTask.type === 'medication' ? '确认并上传' : '保存记录'}</span>
                </button>
            </div>
        </FullScreenPage>
      );
  };

  const renderAddFamily = () => (
    <FullScreenPage title="添加亲友" onClose={() => setShowAddFamily(false)}>
        <div className="p-4 space-y-4">
            <div className="text-center py-8">
                <div className="w-20 h-20 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center text-gray-400">
                    <Plus size={32} />
                </div>
                <p className="text-gray-500 text-sm">上传头像</p>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm space-y-4">
                <input type="text" placeholder="真实姓名" className="w-full border-b border-gray-200 py-3 outline-none" />
                <div className="flex space-x-4">
                    <label className="flex items-center space-x-2"><input type="radio" name="gender" /> <span>男</span></label>
                    <label className="flex items-center space-x-2"><input type="radio" name="gender" /> <span>女</span></label>
                </div>
                <input type="number" placeholder="年龄" className="w-full border-b border-gray-200 py-3 outline-none" />
                <input type="tel" placeholder="手机号码 (用于接收预警)" className="w-full border-b border-gray-200 py-3 outline-none" />
            </div>
            <button 
                onClick={() => { alert('添加成功'); setShowAddFamily(false); }}
                className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg mt-8"
            >
                保存并关联
            </button>
        </div>
    </FullScreenPage>
  );

  const renderSOSOverlay = () => (
      <div className="fixed inset-0 z-[100] bg-red-600 text-white flex flex-col items-center justify-center animate-fade-in-up">
          {sosStatus === 'counting' ? (
              <>
                  <div className="w-24 h-24 rounded-full border-4 border-white/30 flex items-center justify-center mb-8 animate-pulse">
                      <span className="text-5xl font-bold">{sosCountdown}</span>
                  </div>
                  <h1 className="text-3xl font-bold mb-2">SOS 紧急呼救</h1>
                  <p className="opacity-80 mb-12">正在检测您的位置...</p>
                  
                  <div className="w-full px-8 space-y-4">
                      <button 
                        onClick={cancelSOS}
                        className="w-full bg-white text-red-600 font-bold py-4 rounded-xl shadow-lg active:scale-95 transition-transform"
                      >
                          我是误触，取消
                      </button>
                      <button 
                        onClick={() => setSosStatus('calling')}
                        className="w-full bg-red-800 text-white font-bold py-4 rounded-xl border border-red-400 active:scale-95 transition-transform"
                      >
                          立即呼叫 (120/亲友)
                      </button>
                  </div>
              </>
          ) : (
              <>
                  <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center mb-8 animate-ping">
                      <Siren size={48} className="text-red-600" />
                  </div>
                  <h2 className="text-2xl font-bold mb-4">正在呼叫紧急联系人...</h2>
                  <div className="bg-red-700/50 p-6 rounded-2xl max-w-xs w-full mb-8 backdrop-blur-sm">
                      <div className="flex items-center space-x-3 mb-4">
                          <MapPin size={20} />
                          <span className="text-sm">位置已发送: 北京市朝阳区...</span>
                      </div>
                      <div className="flex items-center space-x-3">
                          <FileText size={20} />
                          <span className="text-sm">医疗卡已同步: 高血压/O型血</span>
                      </div>
                  </div>
                  <button 
                    onClick={cancelSOS}
                    className="px-8 py-3 bg-transparent border border-white/50 rounded-full text-sm"
                  >
                      结束呼救
                  </button>
              </>
          )}
      </div>
  );

  return (
    <div className="pb-24 bg-[#F2F2F7] min-h-screen">
      {activeService === 'video' && renderVideoDoctor()}
      {activeService === 'report' && renderReportService()}
      {activeService === 'location' && renderLocationMap()}
      {activeService === 'stress_relief' && renderStressRelief()}
      {activeTask && renderTaskExecution()}
      {showAddFamily && renderAddFamily()}
      {sosActive && renderSOSOverlay()}
      
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#F2F2F7]/90 backdrop-blur-lg px-4 pt-12 pb-4 flex justify-between items-center safe-top">
        <div className="relative">
          <button 
            onClick={() => setShowFamilyMenu(!showFamilyMenu)}
            className="flex items-center space-x-2 bg-white px-3 py-1.5 rounded-full shadow-sm active:scale-95 transition-transform"
          >
            <img src={currentUser.avatar} alt="Avatar" className="w-8 h-8 rounded-full object-cover border border-gray-100" />
            <div>
                <div className="font-semibold text-gray-900 text-sm leading-tight flex items-center">
                    {currentUser.name} <ChevronDown size={12} className="ml-1 text-gray-500" />
                </div>
                <div className="text-[10px] text-gray-500 leading-tight">
                    {currentUser.role === 'Family' ? '远程监护中' : '主动健康管理中'}
                </div>
            </div>
          </button>
          
          {showFamilyMenu && (
            <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 p-2 animate-fade-in-down z-50">
              {FAMILY_MEMBERS.map(member => (
                <button
                  key={member.id}
                  onClick={() => {
                    setCurrentUser(member);
                    setShowFamilyMenu(false);
                  }}
                  className="w-full flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg"
                >
                  <img src={member.avatar} alt={member.name} className="w-8 h-8 rounded-full object-cover" />
                  <div className="text-left">
                      <span className="text-sm font-medium text-gray-900 block">{member.name}</span>
                      <span className="text-[10px] text-gray-400 block">风险等级: {member.id === 'u1' ? '中' : '高'}</span>
                  </div>
                </button>
              ))}
              <div className="h-px bg-gray-100 my-1" />
              <button 
                onClick={() => { setShowAddFamily(true); setShowFamilyMenu(false); }}
                className="w-full flex items-center space-x-3 p-2 text-blue-600 rounded-lg hover:bg-blue-50"
              >
                <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center">
                  <Plus size={16} />
                </div>
                <span className="text-sm font-medium">添加亲友</span>
              </button>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-3">
             <button 
                onClick={triggerSOS}
                className="relative p-2 bg-red-100 rounded-full shadow-sm text-red-600 active:bg-red-200 transition-colors"
             >
                <Siren size={20} />
             </button>
             <button className="relative p-2 bg-white rounded-full shadow-sm text-gray-600">
                <Bell size={20} />
                <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
        </div>
      </div>

      <div className="px-4 space-y-5">
        
        {/* Scenario: Family Guardian Dashboard OR Health Forecast */}
        {currentUser.role === 'Family' ? (
             <div className="bg-gray-900 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
                {/* Header */}
                <div className="flex justify-between items-start mb-4">
                    <div>
                    <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                        <span className="text-xs font-medium text-gray-300">实时连接中</span>
                    </div>
                    <h2 className="text-xl font-bold mt-1">父亲的健康监护</h2>
                    </div>
                    <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
                        <Battery size={14} className="text-green-400" />
                        <span className="text-xs">82%</span>
                    </div>
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                    <div className="bg-white/10 p-3 rounded-xl text-center">
                        <HeartPulse size={20} className="mx-auto mb-1 text-red-400 animate-pulse" />
                        <div className="text-lg font-bold">78</div>
                        <div className="text-[10px] text-gray-400">bpm</div>
                    </div>
                    <div className="bg-white/10 p-3 rounded-xl text-center">
                        <Activity size={20} className="mx-auto mb-1 text-blue-400" />
                        <div className="text-lg font-bold">135/88</div>
                        <div className="text-[10px] text-gray-400">mmHg</div>
                    </div>
                    <div className="bg-white/10 p-3 rounded-xl text-center">
                        <Wind size={20} className="mx-auto mb-1 text-cyan-400" />
                        <div className="text-lg font-bold">96%</div>
                        <div className="text-[10px] text-gray-400">SpO2</div>
                    </div>
                </div>

                {/* Map Snippet */}
                <div className="bg-white/5 rounded-xl p-3 flex items-center justify-between active:bg-white/10" onClick={() => setActiveService('location')}>
                    <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-500/20 rounded-full text-blue-400">
                            <MapPin size={16} />
                        </div>
                        <div>
                            <div className="text-sm font-bold">朝阳公园 • 散步中</div>
                            <div className="text-xs text-gray-400">已离家 45 分钟</div>
                        </div>
                    </div>
                    <ChevronDown size={16} className="-rotate-90 text-gray-500" />
                </div>
             </div>
        ) : (
             <>
                 {/* Scenario 9: Workplace Stress/Sedentary Guardian */}
                 <div className="bg-white rounded-3xl p-5 shadow-sm border border-orange-100 relative overflow-hidden">
                    <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center space-x-2">
                             <div className="p-1.5 bg-orange-100 text-orange-600 rounded-lg">
                                 <Armchair size={18} />
                             </div>
                             <h3 className="font-bold text-gray-900 text-sm">职场状态卫士</h3>
                        </div>
                        <span className="text-[10px] bg-red-50 text-red-500 px-2 py-0.5 rounded-full font-bold">高压预警</span>
                    </div>
                    
                    <div className="flex items-center space-x-4 mb-4">
                        <div className="flex-1">
                            <div className="text-xs text-gray-500">久坐时长</div>
                            <div className="text-xl font-bold text-gray-900">2h 15m</div>
                        </div>
                        <div className="w-px h-8 bg-gray-100"></div>
                        <div className="flex-1">
                            <div className="text-xs text-gray-500">压力指数 (HRV)</div>
                            <div className="text-xl font-bold text-red-500">78 <span className="text-xs font-normal text-gray-400">/100</span></div>
                        </div>
                    </div>

                    <button 
                        onClick={() => setActiveService('stress_relief')}
                        className="w-full bg-orange-50 text-orange-700 font-bold py-3 rounded-xl flex items-center justify-center space-x-2 active:scale-95 transition-transform"
                    >
                        <PlayCircle size={18} />
                        <span>3分钟办公室减压操</span>
                    </button>
                 </div>
             </>
        )}

        {/* Proactive Alerts Section */}
        {displayAlerts.length > 0 && (
            <div className="space-y-3">
                {displayAlerts.map(alert => (
                    <div key={alert.id} className={`rounded-2xl p-4 shadow-sm flex items-start space-x-3 ${alert.type === 'Warning' ? 'bg-orange-50 border border-orange-100' : 'bg-red-50 border border-red-100'}`}>
                        <div className={`p-2 rounded-full ${alert.type === 'Warning' ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'}`}>
                            {alert.type === 'Critical' ? <Phone size={20} className="animate-pulse" /> : <AlertTriangle size={20} />}
                        </div>
                        <div className="flex-1">
                            <h3 className={`text-sm font-bold ${alert.type === 'Warning' ? 'text-orange-800' : 'text-red-800'}`}>
                                {currentUser.role === 'Family' ? '家人健康预警' : '健康异常预警'}
                            </h3>
                            <p className="text-xs text-gray-600 mt-1 leading-relaxed">{alert.message}</p>
                            {alert.actionLabel && (
                                <button 
                                    onClick={() => handleAlertAction(alert.actionType)}
                                    className={`mt-3 px-4 py-1.5 rounded-full text-xs font-semibold flex items-center space-x-1 active:scale-95 transition-transform ${alert.type === 'Warning' ? 'bg-orange-600 text-white' : 'bg-red-600 text-white shadow-md shadow-red-200'}`}
                                >
                                    <span>{alert.actionLabel}</span>
                                    <ArrowRight size={12} />
                                </button>
                            )}
                        </div>
                        <span className="text-[10px] text-gray-400">{alert.timestamp}</span>
                    </div>
                ))}
            </div>
        )}
        
        {/* NEW FEATURE: Family Location Guardian (Only for self when family is active, handled by dashboard above for family role) */}
        {currentUser.id === 'u1' && (
            <div 
                onClick={() => setActiveService('location')}
                className="bg-white rounded-3xl p-1 shadow-sm border border-blue-100 active:scale-95 transition-transform cursor-pointer"
            >
                <div className="p-4 flex items-center justify-between">
                     <div className="flex items-center space-x-3">
                         <div className="p-2 bg-blue-50 text-blue-600 rounded-full">
                             <MapPin size={20} />
                         </div>
                         <div>
                             <h3 className="font-bold text-gray-900 text-sm">家庭位置守护</h3>
                             <p className="text-xs text-gray-500 mt-0.5">父亲 • 已离家散步 20 分钟</p>
                         </div>
                     </div>
                     <div className="flex items-center space-x-2">
                         <span className="text-[10px] bg-green-50 text-green-600 px-2 py-0.5 rounded-full">安全</span>
                         <ChevronDown size={16} className="text-gray-300 -rotate-90" />
                     </div>
                </div>
                {/* Mini Map Representation */}
                <div className="h-16 bg-gray-100 rounded-b-[20px] relative overflow-hidden mx-1 mb-1">
                    <div className="absolute inset-0 bg-[radial-gradient(circle,_#dbeafe_1px,_transparent_1px)] bg-[size:10px_10px] opacity-50"></div>
                     <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex items-center space-x-8">
                         <div className="w-8 h-8 rounded-full border-2 border-blue-400 bg-white flex items-center justify-center">
                            <span className="text-[10px] font-bold text-blue-600">家</span>
                         </div>
                         <div className="w-20 border-t-2 border-dashed border-blue-300"></div>
                         <div className="relative">
                            <img src={FAMILY_MEMBERS[1].avatar} className="w-8 h-8 rounded-full border-2 border-white shadow-sm" />
                            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border border-white rounded-full"></div>
                         </div>
                     </div>
                </div>
            </div>
        )}

        {/* Daily Tasks */}
        <div className="bg-white rounded-3xl p-5 shadow-sm">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-gray-900">
                    {currentUser.role === 'Family' ? `${currentUser.name} 的任务` : '今日健康任务'}
                </h3>
                <span className="text-xs text-blue-600 font-medium">2/4 完成</span>
            </div>
            <div className="space-y-3">
                {DAILY_TASKS.map(task => (
                    <div key={task.id} className={`flex items-center justify-between p-2 rounded-xl transition-colors ${task.urgent && !task.completed ? 'bg-red-50 border border-red-100' : ''}`}>
                        <div className="flex items-center space-x-3">
                            {task.urgent && !task.completed ? (
                                <div className="p-1.5 bg-red-100 rounded-full">
                                    <AlertCircle size={20} className="text-red-500 animate-pulse" />
                                </div>
                            ) : (
                                <div className="w-[28px]"></div>
                            )}
                            
                            {task.completed ? (
                                <CheckCircle2 size={22} className="text-green-500" />
                            ) : (
                                <Circle size={22} className={task.urgent ? "text-red-400" : "text-gray-300"} />
                            )}
                            <div>
                                <div className={`text-sm font-medium ${task.completed ? 'text-gray-400 line-through' : 'text-gray-900'}`}>
                                    {task.title}
                                    {task.urgent && !task.completed && <span className="ml-2 text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded">重要</span>}
                                </div>
                                <div className="text-[10px] text-gray-500">{task.description} • {task.time}</div>
                            </div>
                        </div>
                        
                        {!task.completed && task.urgent ? (
                             <button 
                                onClick={() => handleProcessTask(task)}
                                className="px-3 py-1 bg-red-600 text-white text-xs rounded-full font-medium shadow-md active:scale-95 transition-transform"
                             >
                                立即处理
                             </button>
                        ) : !task.completed && (
                             <button 
                                onClick={() => handleProcessTask(task)}
                                className="px-3 py-1 bg-blue-50 text-blue-600 text-xs rounded-full font-medium"
                             >
                                {task.type === 'medication' ? '去服药' : task.type === 'exercise' ? '去运动' : '去测量'}
                             </button>
                        )}
                    </div>
                ))}
            </div>
        </div>

        {/* Premium Services - Connected to Sub-Pages */}
        <div className="grid grid-cols-2 gap-3">
            <button 
                onClick={() => setActiveService('video')}
                className="bg-gradient-to-r from-emerald-50 to-teal-50 p-4 rounded-2xl shadow-sm border border-emerald-100 flex flex-col justify-between h-28 active:scale-95 transition-transform"
            >
                <div className="flex justify-between w-full">
                    <div className="p-2 bg-white rounded-full text-emerald-600 shadow-sm">
                        <Video size={20} />
                    </div>
                    {ACTIVE_ALERTS.some(a => a.type === 'Warning') && (
                        <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full animate-pulse">建议咨询</span>
                    )}
                </div>
                <div className="text-left mt-2">
                    <div className="text-sm font-bold text-gray-900">视频医生</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">7x24小时 实时连线</div>
                </div>
            </button>
             <button 
                onClick={() => setActiveService('report')}
                className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex flex-col justify-between h-28 active:scale-95 transition-transform"
             >
                <div className="p-2 bg-purple-50 rounded-full text-purple-600 w-fit">
                    <ShieldCheck size={20} />
                </div>
                <div className="text-left mt-2">
                    <div className="text-sm font-bold text-gray-900">报告专家解读</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">三甲名医 二次诊断</div>
                </div>
            </button>
        </div>

        {/* Metrics Grid */}
        <div>
            <div className="flex justify-between items-end mb-3 px-1">
                <h3 className="font-bold text-gray-900">今日数据概览</h3>
                <span className="text-xs text-gray-400">上次更新 10:05</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
                {MOCK_METRICS.map(metric => (
                    <MetricCard 
                      key={metric.id} 
                      metric={metric} 
                      onClick={() => onMetricClick && onMetricClick(metric)}
                    />
                ))}
            </div>
        </div>
        
        <div className="h-4"></div>
      </div>
    </div>
  );
};

export default Home;