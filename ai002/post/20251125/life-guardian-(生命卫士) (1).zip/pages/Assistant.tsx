import React, { useEffect, useRef, useState } from 'react';
import { Send, Mic, Bot, User as UserIcon, Loader2, Zap, Sparkles, Camera } from 'lucide-react';
import { createChatSession, sendMessageStream } from '../services/geminiService';
import { GenerateContentResponse, Chat } from "@google/genai";
import { Message } from '../types';
import { CURRENT_USER, MOCK_METRICS, RISK_PROFILE } from '../constants';

const Assistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [dynamicSuggestion, setDynamicSuggestion] = useState<string | null>(null);
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize chat session on mount with user context
    chatSessionRef.current = createChatSession(CURRENT_USER, MOCK_METRICS, RISK_PROFILE);

    // Initial proactive message logic based on data
    const hasWarning = MOCK_METRICS.some(m => m.status === 'Warning' || m.status === 'Critical');
    
    setTimeout(() => {
        let initialText = `你好 ${CURRENT_USER.name}，我是你的生命卫士 AI 助手。`;
        if (hasWarning) {
            initialText += " 我注意到你今天的血压偏高（142/91），现在感觉头晕或不适吗？建议我们可以聊聊如何调整今天的饮食。";
        } else {
            initialText += " 今天各项指标看起来都很平稳，继续保持！有什么我可以帮你的吗？";
        }

        setMessages([{
            id: 'welcome',
            role: 'model',
            text: initialText,
            timestamp: new Date()
        }]);
    }, 500);
    
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, dynamicSuggestion]);

  const extractSuggestion = (text: string) => {
    // Robust regex to capture suggestions starting with "建议" or "推荐"
    // Handles colon, spaces, and captures text until punctuation
    if (!text) return;
    
    const match = text.match(/(?:建议|推荐)(?:[:：\s]*)([^。！\n]+)/);
    if (match && match[1]) {
      const suggestion = match[1].trim();
      if (suggestion.length > 4) { // Filter out too short
        // Limit display length but keep full text for sending if needed
        setDynamicSuggestion(suggestion);
      }
    }
  };

  const handleSend = async (textInput?: string) => {
    const textToSend = textInput || input;
    if (!textToSend.trim() || !chatSessionRef.current) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setDynamicSuggestion(null); // Clear previous suggestions

    try {
      const streamResult = await sendMessageStream(chatSessionRef.current, userMsg.text);
      
      const botMsgId = (Date.now() + 1).toString();
      let fullText = "";

      // Add a placeholder message for the model
      setMessages(prev => [...prev, {
        id: botMsgId,
        role: 'model',
        text: '',
        timestamp: new Date()
      }]);

      for await (const chunk of streamResult) {
        const c = chunk as GenerateContentResponse;
        const text = c.text || "";
        fullText += text;
        
        setMessages(prev => prev.map(msg => 
          msg.id === botMsgId ? { ...msg, text: fullText } : msg
        ));
      }
      
      // Post-processing for suggestion extraction
      extractSuggestion(fullText);

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: '抱歉，我遇到了一点连接问题，请稍后再试。',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCamera = () => {
      // Proactive Feature: Mock AI Vision Analysis
      const userMsg: Message = {
        id: Date.now().toString(),
        role: 'user',
        text: "[图片：午餐照片]",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, userMsg]);
      setIsLoading(true);

      setTimeout(() => {
          setIsLoading(false);
          const replyText = '我已识别您的午餐照片。看起来这顿饭包含红烧肉和白米饭。⚠️ 提示：红烧肉钠含量和饱和脂肪较高，对于您当前的高血压状况（142/91），建议少吃肥肉，多搭配一些绿叶蔬菜。需要我为您推荐一份晚餐补救方案吗？';
          setMessages(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: replyText,
            timestamp: new Date()
          }]);
          extractSuggestion(replyText);
      }, 2000);
  };

  const defaultQuickActions = [
      "高血压饮食建议",
      "解读今日数据",
      "预约视频医生"
  ];

  return (
    <div className="flex flex-col h-screen bg-[#F2F2F7]">
        {/* Header */}
        <div className="bg-[#F2F2F7]/90 backdrop-blur-md pt-12 pb-4 px-4 sticky top-0 z-10 border-b border-gray-200 safe-top flex justify-center items-center relative">
            <h1 className="text-lg font-bold">AI 健康助手</h1>
            <div className="absolute right-4 top-12 p-1.5 bg-blue-100 rounded-full text-blue-600">
                <Zap size={16} fill="currentColor" />
            </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24">
            {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} items-end gap-2`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${msg.role === 'user' ? 'bg-blue-600' : 'bg-green-500'}`}>
                            {msg.role === 'user' ? <UserIcon size={16} className="text-white" /> : <Bot size={16} className="text-white" />}
                        </div>
                        <div className={`px-4 py-3 rounded-2xl text-[15px] leading-relaxed shadow-sm whitespace-pre-wrap ${
                            msg.role === 'user' 
                                ? 'bg-blue-600 text-white rounded-br-none' 
                                : 'bg-white text-gray-800 rounded-bl-none'
                        }`}>
                            {msg.text}
                        </div>
                    </div>
                </div>
            ))}
            {isLoading && messages[messages.length-1]?.role === 'user' && (
                <div className="flex justify-start">
                    <div className="flex items-center gap-2 bg-white px-4 py-3 rounded-2xl rounded-bl-none shadow-sm">
                        <Loader2 size={16} className="animate-spin text-gray-400" />
                        <span className="text-xs text-gray-400">正在思考...</span>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions & Input Area */}
        <div className="bg-white safe-bottom border-t border-gray-200 z-20 mb-[60px] pb-2"> {/* mb-60px for BottomNav */}
            
            {/* Standard Quick Actions (Above input) */}
            {(messages.length < 3 && !dynamicSuggestion) && (
                <div className="flex space-x-2 px-4 py-3 overflow-x-auto hide-scrollbar">
                    {defaultQuickActions.map((action, idx) => (
                        <button 
                            key={idx}
                            onClick={() => handleSend(action)}
                            className="px-3 py-1.5 bg-gray-100 text-gray-700 text-xs font-medium rounded-full whitespace-nowrap active:bg-gray-200 transition-colors"
                        >
                            {action}
                        </button>
                    ))}
                </div>
            )}

            <div className="px-3 pb-2 pt-1">
                <div className="flex items-center space-x-2 bg-gray-100 rounded-3xl px-2 py-1">
                    <button 
                        onClick={handleCamera}
                        className="p-2 text-gray-500 hover:text-blue-600 active:scale-90 transition-transform"
                    >
                        <Camera size={22} />
                    </button>
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="输入健康问题..."
                        className="flex-1 bg-transparent border-none focus:ring-0 text-base py-3 px-1 placeholder:text-gray-400"
                    />
                    <button 
                        onClick={() => handleSend()}
                        disabled={!input.trim() || isLoading}
                        className={`p-2 rounded-full transition-colors ${
                            input.trim() ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-300 text-gray-100'
                        }`}
                    >
                        <Send size={20} />
                    </button>
                </div>
            </div>

            {/* AI Dynamic Suggestion (Below input as requested) */}
            {dynamicSuggestion && (
                <div className="px-4 pb-2 animate-fade-in-up">
                    <button 
                        onClick={() => handleSend(dynamicSuggestion)}
                        className="w-full flex items-center justify-between px-4 py-3 bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-100 rounded-xl active:scale-95 transition-transform shadow-sm"
                    >
                        <div className="flex items-center space-x-2 overflow-hidden">
                            <Sparkles size={16} className="text-indigo-600 flex-shrink-0" />
                            <div className="flex flex-col items-start overflow-hidden">
                                <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">AI 推荐追问</span>
                                <span className="text-xs font-bold text-indigo-700 truncate w-full text-left">
                                    {dynamicSuggestion}
                                </span>
                            </div>
                        </div>
                        <div className="bg-white p-1 rounded-full text-indigo-400">
                            <Send size={12} />
                        </div>
                    </button>
                </div>
            )}
        </div>
    </div>
  );
};

export default Assistant;