import React, { useState } from 'react';
import { Settings, ChevronRight, Watch, Users, FileText, ShoppingBag, CreditCard, LogOut, Scan, RefreshCw, Bluetooth, Package, Clock, Pill, Video, CheckCircle2 } from 'lucide-react';
import { CURRENT_USER, MY_DEVICES } from '../constants';
import FullScreenPage from '../components/FullScreenPage';

const Profile: React.FC = () => {
  const [showDeviceManager, setShowDeviceManager] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);

  const startScan = () => {
      setIsScanning(true);
      setTimeout(() => setIsScanning(false), 3000);
  };

  const renderDeviceManager = () => (
    <FullScreenPage title="设备管理" onClose={() => setShowDeviceManager(false)}>
        <div className="p-4 space-y-4">
            <div className="bg-blue-600 rounded-2xl p-6 text-white text-center shadow-lg relative overflow-hidden">
                <div className="absolute inset-0 bg-blue-500 opacity-20 animate-pulse"></div>
                <Bluetooth size={48} className="mx-auto mb-4 relative z-10" />
                <h2 className="text-lg font-bold relative z-10">{isScanning ? '正在搜索设备...' : '绑定新设备'}</h2>
                <p className="text-blue-100 text-xs mb-6 relative z-10">请确保设备已开机并开启蓝牙</p>
                <button 
                    onClick={startScan}
                    className="w-full bg-white text-blue-600 font-bold py-3 rounded-full shadow-md active:scale-95 transition-transform flex items-center justify-center space-x-2 relative z-10"
                >
                    {isScanning ? <RefreshCw size={20} className="animate-spin" /> : <Scan size={20} />}
                    <span>{isScanning ? '搜索中' : '开始扫描'}</span>
                </button>
            </div>

            <h3 className="font-bold text-gray-900 mt-2">已绑定设备</h3>
            <div className="space-y-3">
                 {MY_DEVICES.map((device, idx) => (
                   <div key={idx} className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm">
                     <div className="flex items-center space-x-3">
                       <div className="p-2 bg-gray-50 rounded-lg">
                         <Watch size={24} className="text-gray-700" />
                       </div>
                       <div>
                         <div className="text-sm font-medium text-gray-900">{device.name}</div>
                         <div className="text-xs text-gray-500">ID: 8839201 • v2.1.0</div>
                       </div>
                     </div>
                     <button className="text-xs text-red-500 border border-red-200 px-3 py-1 rounded-full">解绑</button>
                   </div>
                 ))}
            </div>
        </div>
    </FullScreenPage>
  );

  const renderHealthRecords = () => (
    <FullScreenPage title="健康档案" onClose={() => setActiveMenu(null)}>
        <div className="p-4 space-y-4">
            <div className="bg-white rounded-xl p-4 shadow-sm flex items-start space-x-4">
                <img src={CURRENT_USER.avatar} className="w-16 h-16 rounded-full object-cover" alt="avatar" />
                <div>
                    <h2 className="font-bold text-gray-900">{CURRENT_USER.name}</h2>
                    <p className="text-sm text-gray-500">男 • 45岁 • O型血</p>
                    <div className="mt-2 flex space-x-2">
                        {CURRENT_USER.conditions.map(c => (
                            <span key={c} className="text-xs bg-red-50 text-red-600 px-2 py-0.5 rounded-md">{c}</span>
                        ))}
                    </div>
                </div>
            </div>

            <div>
                <h3 className="font-bold text-gray-900 mb-2">过往病史</h3>
                <div className="space-y-2">
                    <div className="bg-white p-3 rounded-xl border-l-4 border-blue-500 shadow-sm">
                        <div className="text-sm font-bold">确诊高血压</div>
                        <div className="text-xs text-gray-500">2020年05月 • 湘雅二医院</div>
                    </div>
                    <div className="bg-white p-3 rounded-xl border-l-4 border-orange-500 shadow-sm">
                        <div className="text-sm font-bold">轻度脂肪肝</div>
                        <div className="text-xs text-gray-500">2021年11月 • 社区体检</div>
                    </div>
                </div>
            </div>
            
             <div>
                <h3 className="font-bold text-gray-900 mb-2">过敏史</h3>
                <div className="bg-white p-3 rounded-xl shadow-sm text-sm text-gray-600">
                    无明确药物过敏史。
                </div>
            </div>
        </div>
    </FullScreenPage>
  );

  const renderOrders = () => (
    <FullScreenPage title="药品订单" onClose={() => setActiveMenu(null)}>
        <div className="p-4 space-y-4">
            <div className="flex items-center space-x-4 bg-white p-4 rounded-xl shadow-sm">
                <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Pill className="text-gray-400" />
                </div>
                <div className="flex-1">
                    <div className="flex justify-between">
                        <h3 className="font-bold text-gray-900">苯磺酸氨氯地平片</h3>
                        <span className="text-xs font-bold text-blue-600">配送中</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">2盒 • 5mg*14片</p>
                    <div className="mt-2 flex items-center text-xs text-gray-400">
                        <Package size={12} className="mr-1" />
                        预计明日送达
                    </div>
                </div>
            </div>
             <div className="flex items-center space-x-4 bg-white p-4 rounded-xl shadow-sm opacity-60">
                <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Pill className="text-gray-400" />
                </div>
                <div className="flex-1">
                    <div className="flex justify-between">
                        <h3 className="font-bold text-gray-900">二甲双胍缓释片</h3>
                        <span className="text-xs font-bold text-gray-500">已完成</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">5盒 • 0.5g*24片</p>
                    <div className="mt-2 flex items-center text-xs text-gray-400">
                        <CheckCircle2 size={12} className="mr-1" />
                        2023-09-15 送达
                    </div>
                </div>
            </div>
        </div>
    </FullScreenPage>
  );

  const renderServiceRecords = () => (
    <FullScreenPage title="服务记录" onClose={() => setActiveMenu(null)}>
         <div className="p-4 space-y-4">
            <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center space-x-2">
                        <div className="p-1.5 bg-emerald-100 text-emerald-600 rounded-lg">
                            <Video size={16} />
                        </div>
                        <span className="font-bold text-gray-900">视频医生咨询</span>
                    </div>
                    <span className="text-xs text-gray-400">10-24 14:30</span>
                </div>
                <p className="text-sm text-gray-600 pl-8">主诉头晕、血压波动。医生建议调整用药时间。</p>
                <div className="mt-3 pl-8 flex space-x-2">
                    <span className="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded">李医生</span>
                    <span className="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded">时长 12分</span>
                </div>
            </div>

            <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center space-x-2">
                        <div className="p-1.5 bg-purple-100 text-purple-600 rounded-lg">
                            <FileText size={16} />
                        </div>
                        <span className="font-bold text-gray-900">报告专家解读</span>
                    </div>
                    <span className="text-xs text-gray-400">10-12 09:15</span>
                </div>
                <p className="text-sm text-gray-600 pl-8">血生化报告解读：低密度脂蛋白偏高，建议饮食控制。</p>
            </div>
         </div>
    </FullScreenPage>
  );

  return (
    <div className="pb-24 bg-[#F2F2F7] min-h-screen">
       {showDeviceManager && renderDeviceManager()}
       {activeMenu === 'health_records' && renderHealthRecords()}
       {activeMenu === 'orders' && renderOrders()}
       {activeMenu === 'services' && renderServiceRecords()}

       {/* Top Banner */}
       <div className="bg-white p-6 pt-16 pb-8 rounded-b-[2rem] shadow-sm safe-top">
         <div className="flex items-center space-x-4">
           <img src={CURRENT_USER.avatar} alt="Profile" className="w-20 h-20 rounded-full border-4 border-white shadow-md" />
           <div className="flex-1">
             <h1 className="text-2xl font-bold text-gray-900">{CURRENT_USER.name}</h1>
             <p className="text-sm text-gray-500">ID: 8829102</p>
             <div className="mt-2 flex space-x-2">
               <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-md">VIP 会员</span>
               <span className="px-2 py-0.5 bg-blue-100 text-blue-600 text-xs rounded-md">家人共享</span>
             </div>
           </div>
           <Settings className="text-gray-400" />
         </div>
       </div>

       <div className="px-4 -mt-4 space-y-4">
         
         {/* Devices Section */}
         <div className="bg-white rounded-2xl shadow-sm p-4">
           <div className="flex justify-between items-center mb-3">
             <h3 className="font-semibold text-gray-900">我的设备</h3>
             <button onClick={() => setShowDeviceManager(true)} className="text-xs text-blue-600">管理</button>
           </div>
           <div className="space-y-3">
             {MY_DEVICES.map((device, idx) => (
               <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                 <div className="flex items-center space-x-3">
                   <div className="p-2 bg-white rounded-lg shadow-sm">
                     <Watch size={20} className="text-gray-700" />
                   </div>
                   <div>
                     <div className="text-sm font-medium text-gray-900">{device.name}</div>
                     <div className="text-xs text-gray-500">{device.status} {device.battery > 0 && `• 电量 ${device.battery}%`}</div>
                   </div>
                 </div>
                 {device.status === '已连接' ? (
                   <div className="w-2 h-2 rounded-full bg-green-500"></div>
                 ) : (
                   <div className="w-2 h-2 rounded-full bg-gray-300"></div>
                 )}
               </div>
             ))}
             <button 
                onClick={() => setShowDeviceManager(true)}
                className="w-full py-2 border border-dashed border-gray-300 rounded-xl text-gray-500 text-sm font-medium"
             >
               + 绑定新设备
             </button>
           </div>
         </div>

         {/* Menu Groups */}
         <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
           <MenuItem icon={Users} label="亲友管理" value="2人" />
           <div className="h-px bg-gray-50 mx-4" />
           <MenuItem icon={CreditCard} label="高端增值服务" value="已开通" color="text-yellow-600" />
           <div className="h-px bg-gray-50 mx-4" />
           <MenuItem icon={FileText} label="健康档案" onClick={() => setActiveMenu('health_records')} />
         </div>

         <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
           <MenuItem icon={FileText} label="服务记录" onClick={() => setActiveMenu('services')} />
           <div className="h-px bg-gray-50 mx-4" />
           <MenuItem icon={ShoppingBag} label="药品订单" onClick={() => setActiveMenu('orders')} />
         </div>

         <button className="w-full bg-white text-red-500 font-medium py-3 rounded-2xl shadow-sm flex items-center justify-center space-x-2">
           <LogOut size={18} />
           <span>退出登录</span>
         </button>

         <p className="text-center text-xs text-gray-400 pb-4">Life Guardian v1.0.2</p>
       </div>
    </div>
  );
};

interface MenuItemProps {
  icon: React.ElementType;
  label: string;
  value?: string;
  color?: string;
  onClick?: () => void;
}

const MenuItem: React.FC<MenuItemProps> = ({ icon: Icon, label, value, color, onClick }) => (
  <button onClick={onClick} className="w-full flex items-center justify-between p-4 active:bg-gray-50 transition-colors">
    <div className="flex items-center space-x-3">
      <Icon size={20} className="text-gray-500" />
      <span className="text-sm font-medium text-gray-900">{label}</span>
    </div>
    <div className="flex items-center space-x-2">
      {value && <span className={`text-xs ${color || 'text-gray-400'}`}>{value}</span>}
      <ChevronRight size={16} className="text-gray-300" />
    </div>
  </button>
);

export default Profile;