import React, { useState } from 'react';
import { FileText, ChevronDown, Upload, Search, Filter, AlertCircle, CheckCircle2, ChevronRight, Sparkles, Activity, FileBarChart, Stethoscope, ClipboardPlus, Plus, Brain, Share2, ArrowUpRight, Loader2, ChefHat, Bell, Calendar } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line, ReferenceLine } from 'recharts';
import { CURRENT_USER, FAMILY_MEMBERS, MOCK_REPORTS } from '../constants';
import FullScreenPage from '../components/FullScreenPage';
import { HealthReport } from '../types';

const Reports: React.FC = () => {
  const [selectedUser, setSelectedUser] = useState(CURRENT_USER);
  const [showFamilyMenu, setShowFamilyMenu] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [analysisState, setAnalysisState] = useState<'idle' | 'analyzing' | 'complete'>('idle');

  // Mock Health Score Trend Data
  const scoreData = [
    { month: '5月', score: 72 },
    { month: '6月', score: 75 },
    { month: '7月', score: 74 },
    { month: '8月', score: 78 },
    { month: '9月', score: 82 },
    { month: '10月', score: 78 },
  ];
  
  // Mock Correlation Data (BP vs LDL) for AI Analysis
  const correlationData = [
    { day: 'W1', bp: 130, ldl: 3.2 },
    { day: 'W2', bp: 132, ldl: 3.3 },
    { day: 'W3', bp: 135, ldl: 3.6 },
    { day: 'W4', bp: 142, ldl: 3.8 },
  ];

  const handleOpenAnalysis = () => {
      setShowAnalysis(true);
      setAnalysisState('analyzing');
      // Simulate synthesis process to give a sense of "AI Computing"
      setTimeout(() => {
          setAnalysisState('complete');
      }, 2000);
  };

  const renderCategoryDetail = () => {
      if (!activeCategory) return null;
      
      // Filter reports based on category for demonstration
      let filteredReports = MOCK_REPORTS;
      if (activeCategory === '体检报告') filteredReports = MOCK_REPORTS.filter(r => r.type === 'medical');
      else if (activeCategory === '监测周报') filteredReports = MOCK_REPORTS.filter(r => r.type === 'weekly');
      else if (activeCategory === '专项评估') filteredReports = MOCK_REPORTS.filter(r => r.type === 'special');
      else if (activeCategory === '就医记录') filteredReports = MOCK_REPORTS.filter(r => r.type === 'history');

      return (
          <FullScreenPage title={activeCategory} onClose={() => setActiveCategory(null)}>
              <div className="p-4 bg-[#F2F2F7] min-h-screen">
                  {filteredReports.length > 0 ? (
                      <div className="space-y-3">
                          {filteredReports.map(report => (
                              <div key={report.id} className="bg-white p-4 rounded-xl shadow-sm">
                                  <div className="flex justify-between items-start">
                                      <div>
                                          <div className="font-bold text-gray-900">{report.title}</div>
                                          <div className="text-xs text-gray-500 mt-1">{report.date} • {report.author}</div>
                                      </div>
                                      <span className={`px-2 py-0.5 rounded text-[10px] ${report.status === 'Normal' ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'}`}>
                                          {report.status}
                                      </span>
                                  </div>
                              </div>
                          ))}
                      </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                        <FileText size={48} className="mb-4 opacity-30" />
                        <p>暂无{activeCategory}记录</p>
                    </div>
                  )}
              </div>
          </FullScreenPage>
      )
  };

  const renderAIAnalysis = () => (
    <FullScreenPage title="AI 深度档案解读" onClose={() => setShowAnalysis(false)}>
        {analysisState === 'analyzing' ? (
             <div className="flex flex-col items-center justify-center h-[80vh] space-y-8 animate-fade-in-up">
                 <div className="relative">
                     <div className="w-24 h-24 rounded-full border-4 border-indigo-200 border-t-indigo-600 animate-spin"></div>
                     <div className="absolute inset-0 flex items-center justify-center">
                         <Brain size={32} className="text-indigo-600" />
                     </div>
                 </div>
                 <div className="text-center space-y-2">
                     <h3 className="text-xl font-bold text-gray-900">正在聚合多维健康档案...</h3>
                     <div className="text-sm text-gray-500 flex flex-col items-center space-y-1">
                         <span className="animate-pulse">分析血压周报趋势...</span>
                         <span className="animate-pulse delay-75">比对血生化指标...</span>
                         <span className="animate-pulse delay-150">关联用药记录...</span>
                     </div>
                 </div>
             </div>
        ) : (
            <div className="p-4 space-y-6 bg-[#F2F2F7] min-h-screen animate-fade-in-up">
                {/* Header: The Synthesis Engine Visualization */}
                <div className="bg-[#1a2332] rounded-3xl p-6 text-white relative overflow-hidden shadow-xl">
                    {/* Animated Gradient Line */}
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500 opacity-80"></div>
                    
                    <div className="flex justify-between items-center mb-8">
                         <div className="space-y-1 relative z-10">
                             <h2 className="text-xl font-bold flex items-center gap-2">
                                 <Brain className="text-indigo-400" size={24} />
                                 多维数据聚合
                             </h2>
                             <p className="text-xs text-gray-400">AI 已关联 3 份核心档案进行交叉验证</p>
                         </div>
                    </div>

                    {/* Sources Visualization */}
                    <div className="flex justify-between items-center relative z-10 mx-2">
                        {/* Connecting lines */}
                        <div className="absolute top-4 left-0 w-full h-0.5 bg-gray-700 -z-10"></div>
                        
                        {['血压周报', '血生化单', '用药记录'].map((src, i) => (
                            <div key={i} className="flex flex-col items-center group cursor-pointer">
                                <div className="w-9 h-9 rounded-full bg-gray-800 border-2 border-indigo-500 flex items-center justify-center text-sm font-bold shadow-lg shadow-indigo-500/20 transition-transform group-hover:scale-110">
                                    {i + 1}
                                </div>
                                <span className="text-[10px] text-gray-300 mt-2 bg-[#1a2332] px-1">{src}</span>
                            </div>
                        ))}
                    </div>
                    
                    {/* Result Tag */}
                    <div className="mt-8 bg-white/5 rounded-xl p-3 flex items-center justify-between border border-white/10 backdrop-blur-sm">
                        <span className="text-xs text-gray-300">综合置信度</span>
                        <span className="text-sm font-bold text-green-400">98.5%</span>
                    </div>
                </div>

                {/* Core Insight: Correlation */}
                <div className="bg-white rounded-3xl p-5 shadow-sm border border-indigo-50">
                    <div className="flex items-center space-x-2 mb-4">
                        <div className="p-2 bg-indigo-50 rounded-lg">
                            <Activity size={20} className="text-indigo-600" />
                        </div>
                        <h3 className="font-bold text-gray-900">核心关联发现</h3>
                    </div>
                    
                    <p className="text-sm text-gray-700 leading-relaxed mb-5">
                        <strong className="text-gray-900 block mb-1">血压波动与血脂异常呈正相关趋势</strong> 
                        AI 分析发现：您近四周的<span className="text-red-500 font-medium">收缩压上升</span>趋势，与上月体检报告中的<span className="text-orange-500 font-medium">低密度脂蛋白(LDL-C)偏高</span>存在强相关性。且在漏服药（W3）期间，波动最为明显。
                    </p>

                    {/* Correlation Chart */}
                    <div className="h-40 bg-gray-50 rounded-xl p-2 relative overflow-hidden">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={correlationData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                                <Tooltip contentStyle={{borderRadius: '8px', fontSize: '12px'}} />
                                <ReferenceLine y={140} stroke="red" strokeDasharray="3 3" label={{ value: 'BP警戒线', fill: 'red', fontSize: 10 }} />
                                <Line type="monotone" dataKey="bp" stroke="#ef4444" strokeWidth={2} dot={{r: 3}} name="收缩压" />
                                <Line type="monotone" dataKey="ldl" stroke="#f97316" strokeWidth={2} dot={{r: 3}} name="LDL-C (*40)" /> 
                            </LineChart>
                        </ResponsiveContainer>
                        <div className="absolute top-2 right-2 flex space-x-3 text-[10px]">
                            <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-red-500 mr-1"></span>血压</span>
                            <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-orange-500 mr-1"></span>血脂</span>
                        </div>
                    </div>
                </div>

                {/* Actionable Plan - Updated with Specific Execution Steps */}
                <div className="bg-white rounded-3xl p-5 shadow-sm border border-green-50">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                            <div className="p-2 bg-green-50 rounded-lg">
                                <ClipboardPlus size={20} className="text-green-600" />
                            </div>
                            <h3 className="font-bold text-gray-900">AI 生成执行计划</h3>
                        </div>
                        <span className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded-full font-bold">已生成 3 项待办</span>
                    </div>

                    <div className="relative pl-4 border-l-2 border-gray-100 space-y-8 my-2">
                        {/* Step 1: Immediate Action - Diet */}
                        <div className="relative">
                            <div className="absolute -left-[21px] top-0 w-4 h-4 rounded-full bg-green-500 border-2 border-white shadow-sm"></div>
                            <div className="mb-1 flex justify-between items-start">
                                <h4 className="font-bold text-gray-900 text-sm">立刻执行：饮食干预</h4>
                                <span className="text-[10px] text-gray-400 bg-gray-50 px-1.5 rounded">Today</span>
                            </div>
                            <p className="text-xs text-gray-600 mb-3 leading-relaxed">
                                已根据您的口味偏好，生成了<span className="text-green-700 font-bold">“高纤低脂”7日食谱</span>。重点增加了早餐燕麦和晚餐深海鱼的比例。
                            </p>
                            <button className="w-full flex items-center justify-center space-x-2 py-2.5 bg-green-50 text-green-700 rounded-xl text-xs font-bold active:bg-green-100 transition-colors">
                                <ChefHat size={16} />
                                <span>查看并采纳食谱</span>
                            </button>
                        </div>

                        {/* Step 2: Medication - Reminder */}
                        <div className="relative">
                            <div className="absolute -left-[21px] top-0 w-4 h-4 rounded-full bg-blue-500 border-2 border-white shadow-sm"></div>
                            <div className="mb-1 flex justify-between items-start">
                                <h4 className="font-bold text-gray-900 text-sm">持续跟进：用药依从性</h4>
                                <span className="text-[10px] text-gray-400 bg-gray-50 px-1.5 rounded">Daily</span>
                            </div>
                            <p className="text-xs text-gray-600 mb-3 leading-relaxed">
                                分析显示 W3 血压波动与漏服药有关。建议开启<span className="text-blue-700 font-bold">“强提醒模式”</span>，确保每日 08:00 准时服药。
                            </p>
                            <button className="w-full flex items-center justify-center space-x-2 py-2.5 bg-blue-50 text-blue-700 rounded-xl text-xs font-bold active:bg-blue-100 transition-colors">
                                <Bell size={16} />
                                <span>开启强提醒</span>
                            </button>
                        </div>

                        {/* Step 3: Medical Appointment */}
                        <div className="relative">
                            <div className="absolute -left-[21px] top-0 w-4 h-4 rounded-full bg-orange-500 border-2 border-white shadow-sm"></div>
                             <div className="mb-1 flex justify-between items-start">
                                <h4 className="font-bold text-gray-900 text-sm">关键节点：专项复查</h4>
                                <span className="text-[10px] text-gray-400 bg-gray-50 px-1.5 rounded">2023-11-08</span>
                            </div>
                            <p className="text-xs text-gray-600 mb-3 leading-relaxed">
                                需复查“血脂四项”以评估干预效果。AI 建议预约<span className="text-orange-700 font-bold">湘雅二医院心内科</span>。
                            </p>
                            <button className="w-full flex items-center justify-center space-x-2 py-2.5 bg-orange-50 text-orange-700 rounded-xl text-xs font-bold active:bg-orange-100 transition-colors">
                                <Calendar size={16} />
                                <span>一键预约挂号</span>
                            </button>
                        </div>
                    </div>
                </div>
                
                <button className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2">
                    <Share2 size={18} />
                    生成 PDF 报告并分享给医生
                </button>
                <div className="h-safe-bottom"></div>
            </div>
        )}
    </FullScreenPage>
  );

  return (
    <div className="pb-24 bg-[#F2F2F7] min-h-screen">
      {renderCategoryDetail()}
      {showAnalysis && renderAIAnalysis()}

      {/* Header: Family Switcher & Add Button */}
      <div className="bg-[#F2F2F7]/90 backdrop-blur-md pt-12 pb-2 px-4 sticky top-0 z-40 safe-top flex justify-between items-center">
        <div className="relative">
          <button 
            onClick={() => setShowFamilyMenu(!showFamilyMenu)}
            className="flex items-center space-x-2 bg-white px-4 py-2 rounded-full shadow-sm active:scale-95 transition-transform"
          >
            <img src={selectedUser.avatar} alt="Avatar" className="w-8 h-8 rounded-full object-cover border border-gray-100" />
            <div className="text-left">
                <div className="font-bold text-gray-900 text-sm leading-none flex items-center">
                    {selectedUser.name} 的档案 <ChevronDown size={14} className="ml-1 text-gray-400" />
                </div>
            </div>
          </button>
           {showFamilyMenu && (
            <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 p-2 animate-fade-in-down z-50">
              {FAMILY_MEMBERS.map(member => (
                <button
                  key={member.id}
                  onClick={() => {
                    setSelectedUser(member);
                    setShowFamilyMenu(false);
                  }}
                  className="w-full flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg"
                >
                  <img src={member.avatar} alt={member.name} className="w-8 h-8 rounded-full object-cover" />
                  <span className="text-sm font-medium text-gray-900">{member.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <button className="p-2 bg-blue-600 text-white rounded-full shadow-lg shadow-blue-200 active:scale-95 transition-transform">
            <Plus size={20} />
        </button>
      </div>

      <div className="px-4 space-y-5 mt-2">
        
        {/* 1. Health Trends Chart Card */}
        <div className="bg-white rounded-3xl p-5 shadow-sm">
            <div className="flex justify-between items-center mb-4">
                <div>
                    <h2 className="text-gray-500 text-xs font-medium uppercase tracking-wider">健康评分趋势</h2>
                    <div className="flex items-baseline space-x-2">
                        <span className="text-3xl font-bold text-gray-900">78</span>
                        <span className="text-sm text-green-500 font-bold flex items-center">
                            +4 <Activity size={12} className="ml-0.5" />
                        </span>
                    </div>
                </div>
                <div className="bg-gray-50 px-3 py-1 rounded-lg text-xs text-gray-500">
                    近6个月
                </div>
            </div>
            
            <div className="h-32 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={scoreData}>
                        <defs>
                            <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <Tooltip 
                            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', fontSize: '12px' }}
                            cursor={{ stroke: '#e5e7eb' }}
                        />
                        <Area 
                            type="monotone" 
                            dataKey="score" 
                            stroke="#3b82f6" 
                            strokeWidth={3} 
                            fill="url(#colorScore)" 
                        />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </div>

        {/* 2. AI Meta-Analysis Card (The "Brain" of the page) */}
        <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-3xl p-5 text-white shadow-lg relative overflow-hidden">
             {/* Background Decoration */}
             <Sparkles className="absolute top-[-10px] right-[-10px] opacity-20 text-white" size={80} />
             
             <div className="flex items-center space-x-2 mb-3 relative z-10">
                 <div className="p-1.5 bg-white/20 backdrop-blur-sm rounded-lg">
                     <Sparkles size={16} className="text-yellow-300" />
                 </div>
                 <h3 className="font-bold text-lg">AI 综合档案解读</h3>
             </div>
             
             <p className="text-sm text-indigo-100 leading-relaxed relative z-10 line-clamp-2">
                 基于您本周的<span className="font-bold text-white border-b border-white/30">血压监测周报</span>与上月上传的<span className="font-bold text-white border-b border-white/30">血生化检查</span>，AI 发现您的低密度脂蛋白与血压波动存在关联。
             </p>

             <div className="mt-4 flex items-center justify-between relative z-10">
                 <span className="text-xs bg-black/20 px-2 py-1 rounded-md text-indigo-200 border border-white/10">
                     关联档案: 3份
                 </span>
                 <button 
                    onClick={handleOpenAnalysis}
                    className="flex items-center space-x-1 text-sm font-bold bg-white text-blue-700 px-4 py-2 rounded-full shadow-md active:scale-95 transition-transform"
                 >
                     <span>查看深度分析</span>
                     <ArrowUpRight size={16} />
                 </button>
             </div>
        </div>

        {/* 3. Report Categories Grid */}
        <div className="grid grid-cols-2 gap-3">
            {[
                { title: '体检报告', sub: '医院数据同步', icon: ClipboardPlus, color: 'text-blue-600', bg: 'bg-blue-50', type: 'medical' },
                { title: '监测周报', sub: '设备自动生成', icon: FileBarChart, color: 'text-emerald-600', bg: 'bg-emerald-50', type: 'weekly' },
                { title: '专项评估', sub: '心脏/睡眠/心理', icon: Activity, color: 'text-orange-600', bg: 'bg-orange-50', type: 'special' },
                { title: '就医记录', sub: '门诊/住院病历', icon: Stethoscope, color: 'text-purple-600', bg: 'bg-purple-50', type: 'history' },
            ].map((cat, idx) => (
                <button 
                    key={idx}
                    onClick={() => setActiveCategory(cat.title)}
                    className="bg-white p-4 rounded-2xl shadow-sm flex flex-col items-start active:scale-95 transition-transform"
                >
                    <div className={`p-2.5 rounded-xl ${cat.bg} ${cat.color} mb-3`}>
                        <cat.icon size={24} />
                    </div>
                    <div className="font-bold text-gray-900">{cat.title}</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">{cat.sub}</div>
                </button>
            ))}
        </div>

        {/* 4. Recent Reports Timeline */}
        <div>
            <div className="flex justify-between items-center mb-3 px-1">
                <h3 className="font-bold text-gray-900 text-lg">最新动态</h3>
                <button className="p-2 bg-white rounded-full shadow-sm text-gray-500">
                    <Search size={16} />
                </button>
            </div>
            
            <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
                {MOCK_REPORTS.map((report) => (
                    <div key={report.id} className="p-4 border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors cursor-pointer flex items-center justify-between group">
                        <div className="flex items-start space-x-3">
                            <div className={`mt-1 p-2 rounded-lg flex-shrink-0 ${
                                report.type === 'weekly' ? 'bg-emerald-100 text-emerald-600' :
                                report.type === 'medical' ? 'bg-blue-100 text-blue-600' :
                                report.type === 'monthly' ? 'bg-purple-100 text-purple-600' :
                                'bg-orange-100 text-orange-600'
                            }`}>
                                <FileText size={18} />
                            </div>
                            <div>
                                <h4 className="font-bold text-gray-900 text-sm mb-0.5">{report.title}</h4>
                                <div className="flex items-center space-x-2 text-xs text-gray-400">
                                    <span>{report.date}</span>
                                    <span>•</span>
                                    <span>{report.author}</span>
                                </div>
                                <div className="mt-2 flex space-x-1">
                                    <span className="px-1.5 py-0.5 bg-gray-100 text-gray-500 rounded text-[10px]">{report.tag}</span>
                                    {report.status !== 'Normal' && (
                                        <span className={`px-1.5 py-0.5 rounded text-[10px] flex items-center ${
                                            report.status === 'Critical' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                                        }`}>
                                            {report.status === 'Critical' ? <AlertCircle size={10} className="mr-1"/> : null}
                                            {report.status === 'Critical' ? '异常预警' : '需关注'}
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                        <ChevronRight size={18} className="text-gray-300 group-hover:text-gray-400 transition-colors" />
                    </div>
                ))}
                <button className="w-full py-3 text-center text-xs text-blue-600 font-medium active:bg-gray-50">
                    查看全部 12 份档案
                </button>
            </div>
        </div>
        
        {/* Floating Upload Button (Optional UX enhancement) */}
        <div className="fixed bottom-24 right-4 z-30">
             <button className="flex items-center space-x-2 bg-gray-900 text-white px-4 py-3 rounded-full shadow-xl shadow-gray-400/30 active:scale-95 transition-transform">
                 <Upload size={18} />
                 <span className="text-sm font-bold">上传报告</span>
             </button>
        </div>

      </div>
    </div>
  );
};

export default Reports;