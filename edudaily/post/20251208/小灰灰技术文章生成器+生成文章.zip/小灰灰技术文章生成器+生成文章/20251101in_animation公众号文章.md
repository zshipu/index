# AI自动生成教学动画！这个开源项目让知识可视化变得如此简单

## 前言

在教育内容创作领域，如何将枯燥的知识点转化为生动有趣的动画一直是创作者们头疼的问题。传统的动画制作方式需要掌握After Effects、Flash等专业软件，不仅学习成本高，而且制作一个简单的教学动画都要花费数小时甚至数天时间，这让很多想做知识可视化的老师和内容创作者望而却步。

Instructional Animation 是一个基于AI大模型的教学动画自动生成平台，核心目标是通过自然语言描述，让AI自动创建视觉效果精美的HTML5交互式动画，并支持导出为MP4视频、GIF动图等多种格式，实现从知识点输入到动画输出的全自动化流程。

![image-20251110-150001](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150001.png)

Instructional Animation 通过大语言模型的理解能力，结合专业的动画渲染技术，突破了传统动画制作的技术门槛，让任何人都能在几分钟内生成高质量的2K分辨率教学动画，识字就能做动画，这不就是教育工作者梦寐以求的工具吗？好家伙，这效率简直不要太香！

这2天 Instructional Animation 在GitHub上非常火爆，今天我们在Docker环境手把手教大家部署这个项目，体验和感受一下这个AI动画生成神器的能力。

## 项目介绍

### ✨ 核心特性

- **🤖 AI驱动生成**: 基于大语言模型自动理解知识点并生成动画脚本
- **🎬 高清输出**: 支持2K分辨率(1280×720)，专业级视觉效果
- **📦 多格式导出**: HTML5交互式动画、MP4视频、GIF动图一键导出
- **⚡ 实时流式输出**: SSE技术实现生成过程可视化反馈
- **🔄 迭代优化**: 支持多轮对话持续优化动画效果
- **🌍 双语支持**: 中英文界面切换，支持字幕配置
- **⚙️ 动态配置**: Web界面直接修改API配置，无需重启服务
- **🐳 容器化部署**: Docker一键启动，5分钟完成部署

![image-20251110-150002](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150002.png)

### 🛠️ 技术栈

**后端技术**
- **框架**: FastAPI（现代化Web框架）
- **语言**: Python 3.11+
- **LLM接口**: OpenAI兼容接口
- **浏览器自动化**: Playwright
- **视频编码**: FFmpeg
- **模板引擎**: Jinja2

**前端技术**
- **基础**: HTML5 + CSS3 + JavaScript
- **动画库**: GSAP（专业动画引擎）
- **实时通信**: Server-Sent Events (SSE)

**支持的AI模型**
- 智谱 GLM-4.6
- Minimax-m2
- DeepSeek-V3.2-Exp
- Claude Haiku 4.5
- Qwen3-Coder-480B

### 🎯 应用场景

- **教育培训**: 在线课程、教学PPT、知识点讲解动画制作
- **内容创作**: 短视频创作、科普内容、技术教程可视化
- **企业培训**: 产品演示、操作指南、培训教材动画化
- **学术研究**: 论文配图、实验过程演示、概念可视化
- **自媒体运营**: 公众号配图、B站视频素材、抖音教学内容

### 📊 效率对比

| 特性 | 传统制作方式 | Instructional Animation |
|------|-------------|-------------------------|
| 制作时间 | 2-8小时/个 | 2-5分钟/个(快240倍) |
| 技术门槛 | 需专业软件技能 | 会打字即可(零门槛) |
| 制作成本 | ¥500-2000/个 | ¥0.1-0.5/个(省99%) |
| 修改难度 | 复杂(需重新制作) | 简单(对话优化) |
| 输出格式 | 单一格式 | 3种格式(HTML+MP4+GIF) |
| 分辨率 | 看软件能力 | 统一2K高清 |

呵呵，看到这个对比是不是很心动？传统方式做一个教学动画要几个小时，现在几分钟就搞定，这效率提升简直是质的飞跃！

### 🔥 项目亮点

**智能化程度高**: 只需输入"讲解二叉树的遍历过程"，AI就能自动生成包含动画效果、代码示例、可视化流程的完整教学动画。

**配置灵活**: 支持Web界面直接配置API密钥、模型选择，还有连接测试功能，配置完立即生效无需重启。

**扩展性强**: 基于标准的OpenAI接口，理论上支持所有兼容OpenAI格式的大模型，包括国内外主流模型。

**开源免费**: MIT协议，代码完全开源，可以自由修改和商用。

## 部署实战

### 环境准备

本次部署我们选择Docker方式，这是最简单快捷的部署方案。

**硬件要求**:
- CPU: 2核心以上
- 内存: 4GB以上
- 磁盘: 10GB以上可用空间
- 网络: 能访问AI模型API

**软件要求**:
- Docker 20.10+
- Docker Compose 2.0+
- 操作系统: Linux / macOS / Windows(需WSL2)

如果你还没安装Docker，可以参考Docker官网的安装教程，这里不再赘述。

![image-20251110-150003](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150003.png)

### 项目下载

打开终端，执行以下命令下载项目：

```shell
# 克隆项目到本地
git clone https://github.com/wwwzhouhui/in_animation.git

# 进入项目目录
cd in_animation

# 查看项目结构
ls -la
```

![image-20251110-150004](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150004.png)

等待几秒钟下载完成，可以看到项目的完整目录结构。

![image-20251110-150005](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150005.png)

### 配置环境变量

项目提供了 `.env.example` 示例文件，我们需要复制并配置：

```shell
# 复制示例配置文件
cp .env.example .env

# 编辑配置文件
vim .env
# 或者用你喜欢的编辑器: nano .env 或 code .env
```

![image-20251110-150006](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150006.png)

配置文件内容示例：

```bash
# API配置（必填）
API_KEY=your-api-key-here
BASE_URL=https://api.openai.com/v1
MODEL=gpt-4

# 或者使用国内模型（推荐）
# 智谱AI配置
# API_KEY=your-zhipu-api-key
# BASE_URL=https://open.bigmodel.cn/api/paas/v4
# MODEL=glm-4

# DeepSeek配置
# API_KEY=your-deepseek-api-key
# BASE_URL=https://api.deepseek.com/v1
# MODEL=deepseek-chat

# 服务配置（可选）
HOST=0.0.0.0
PORT=8000

# 日志配置（可选）
LOG_LEVEL=INFO
```

**配置说明**:
- `API_KEY`: AI模型的API密钥（必填）
- `BASE_URL`: API服务地址（必填）
- `MODEL`: 使用的模型名称（必填）
- `HOST`/`PORT`: 服务监听地址和端口（可选，默认即可）

![image-20251110-150007](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150007.png)

**温馨提示**: 推荐使用国内大模型服务，如智谱AI、DeepSeek等，不仅速度快而且价格便宜，新用户一般都有免费额度。

### Docker启动

配置完成后，一条命令启动服务：

```shell
# 使用Docker Compose启动
docker-compose up -d

# 查看启动日志
docker-compose logs -f
```

![image-20251110-150008](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150008.png)

首次启动会自动下载镜像和安装依赖，大约需要3-5分钟。看到以下日志说明服务启动成功：

```
in_animation_1  | INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
in_animation_1  | INFO:     Started reloader process [1] using StatReload
in_animation_1  | INFO:     Started server process [7]
in_animation_1  | INFO:     Waiting for application startup.
in_animation_1  | INFO:     Application startup complete.
```

![image-20251110-150009](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150009.png)

**常用Docker命令**:

```shell
# 查看运行状态
docker-compose ps

# 停止服务
docker-compose stop

# 重启服务
docker-compose restart

# 停止并删除容器
docker-compose down

# 查看实时日志
docker-compose logs -f
```

### 本地部署方式（可选）

如果你不想使用Docker，也可以选择本地部署：

```shell
# 创建Python虚拟环境
python3 -m venv venv

# 激活虚拟环境
source venv/bin/activate  # Linux/Mac
# 或 venv\Scripts\activate  # Windows

# 安装Python依赖
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 安装Playwright浏览器
playwright install chromium

# 安装FFmpeg（Ubuntu/Debian）
sudo apt-get install ffmpeg

# 或者macOS
# brew install ffmpeg

# 启动服务
python app.py
```

![image-20251110-150010](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150010.png)

看到启动成功提示后，服务就可以使用了。

### 访问Web界面

浏览器访问 `http://localhost:8000`

![image-20251110-150011](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150011.png)

看到这个简洁清爽的界面，说明部署成功！

### 配置API（首次使用必做）

点击右上角的 ⚙️ 设置按钮，打开配置面板：

![image-20251110-150012](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150012.png)

填入你的API配置信息：

- **API Key**: 你的AI模型密钥
- **Base URL**: API服务地址
- **Model**: 模型名称

![image-20251110-150013](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150013.png)

点击"Test Connection"测试连接：

![image-20251110-150014](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150014.png)

看到 ✅ 绿色成功提示，说明API配置正确。如果是 ❌ 红色失败提示，请检查你的API密钥和网络连接。

点击"Save"保存配置，配置立即生效无需重启服务。好家伙，这用户体验确实舒服！

### 生成第一个动画

在输入框输入你想要制作的教学内容，比如：

```
请制作一个讲解"冒泡排序算法"的教学动画，包含：
1. 算法原理介绍
2. 可视化排序过程
3. 代码实现展示
4. 时间复杂度分析
```

![image-20251110-150015](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150015.png)

点击"Generate Animation"按钮，AI开始工作：

![image-20251110-150016](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150016.png)

可以看到生成过程的实时流式输出，AI正在思考如何设计这个动画。等待30秒到2分钟（取决于内容复杂度），动画生成完成：

![image-20251110-150017](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150017.png)

点击播放按钮预览动画效果：

![image-20251110-150018](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150018.png)

呵呵，效果还不错吧？整个动画流畅自然，配色专业，排序过程的可视化非常清晰，比我自己手工做的强多了！

### 迭代优化动画

如果觉得某些地方需要改进，可以继续对话优化：

```
请调整一下：
1. 把排序速度放慢一点，现在太快了
2. 每次交换时高亮显示正在比较的两个元素
3. 增加每一步的文字说明
```

![image-20251110-150019](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150019.png)

AI会基于你的反馈重新生成优化后的版本：

![image-20251110-150020](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150020.png)

这种多轮迭代的方式，让动画制作变得像和AI对话一样简单，不需要懂任何动画制作技术，话说清楚就行！

### 导出动画

满意后可以导出为不同格式：

**导出HTML**（交互式动画）：

```shell
# 动画HTML文件已自动保存在 output/ 目录
ls output/

# 可以直接在浏览器打开
open output/animation_20251110_150020.html
```

![image-20251110-150021](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150021.png)

**导出MP4视频**：

点击"Export as Video"按钮，配置导出参数：

![image-20251110-150022](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150022.png)

参数说明：
- **Duration**: 视频时长（秒）
- **FPS**: 帧率（建议30或60）
- **Quality**: 视频质量（high/medium/low）

点击确认，等待渲染完成：

![image-20251110-150023](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150023.png)

视频自动保存到 `output/` 目录，可以直接用于视频剪辑或上传到各大平台。

**导出GIF动图**：

点击"Export as GIF"按钮，同样配置参数：

![image-20251110-150024](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150024.png)

GIF适合用在公众号文章、PPT、文档中，文件体积小，兼容性好。

### API调用方式（程序员专用）

如果你是开发者，想把这个功能集成到自己的应用中，可以直接调用API：

```python
import requests
import json

# 生成动画API
url = "http://localhost:8000/generate"
payload = {
    "topic": "讲解递归算法的执行过程",
    "language": "zh",
    "style": "professional"
}

# 使用SSE接收流式输出
response = requests.post(url, json=payload, stream=True)

for line in response.iter_lines():
    if line:
        data = json.loads(line.decode('utf-8').replace('data: ', ''))
        print(data['content'])
```

![image-20251110-150025](https://mypicture-1258720957.cos.ap-nanjing.myqcloud.com/image-20251110-150025.png)

**导出视频API**：

```python
# 导出MP4视频
export_url = "http://localhost:8000/record"
export_payload = {
    "html_file": "animation_20251110_150020.html",
    "format": "mp4",
    "duration": 60,
    "fps": 30
}

export_response = requests.post(export_url, json=export_payload)
result = export_response.json()

print(f"视频路径: {result['file_path']}")
print(f"文件大小: {result['file_size']} MB")
```

通过API调用，可以实现批量生成、自动化处理等高级功能。

### 高级技巧

**技巧1：提供详细的描述**

输入越详细，生成的动画越符合预期。比如：

```
制作一个关于"HTTP请求过程"的动画，要求：
- 展示浏览器、DNS服务器、Web服务器三个角色
- 演示DNS解析、建立TCP连接、发送HTTP请求、返回响应的完整流程
- 用不同颜色区分请求和响应数据包
- 每个步骤显示对应的技术术语
- 整体采用蓝色科技风格
- 时长控制在90秒左右
```

**技巧2：参考已有素材**

如果你有PPT、思维导图或草图，可以描述它们：

```
参考这个思维导图结构生成动画：
中心是"机器学习"，分支出"监督学习"、"无监督学习"、"强化学习"三个分支，
每个分支下再展开具体算法，用树状动画展示层级关系。
```

**技巧3：指定动画效果**

可以明确要求特定的动画效果：

```
制作动画时：
- 标题用淡入效果出现
- 重点内容用放大+高亮强调
- 列表项逐个飞入
- 图表采用绘制动画（从无到有的过程）
- 过渡要平滑自然，不要太突兀
```

通过这些技巧，你可以让AI生成更加精准、专业的教学动画。

## 总结

今天主要带大家了解并实现了 Instructional Animation 开源AI动画生成平台的完整部署流程，该项目以"大语言模型理解能力 + 专业动画渲染技术"为核心优势，结合教育内容可视化需求，通过 Docker容器化部署 与 Web交互界面，形成了一套从自然语言描述到高质量动画输出的全自动化AI动画创作解决方案。通过这套实践方案，教师、内容创作者、培训师能够高效突破传统动画制作的技术门槛和时间成本瓶颈——借助AI驱动的自动化生成(包括动画脚本设计、视觉效果渲染、交互逻辑实现、多格式导出)，无需掌握After Effects等专业软件，无需编写复杂的动画代码，就能快速制作出2K高清的专业级教学动画(如本次演示的"从文字描述到完整动画仅需2-5分钟，效率提升240倍")。无论是算法可视化教学、物理化学实验演示，还是历史事件过程重现、编程概念图解说明，都能通过简单的对话交互完成，极大降低教育内容创作的技术难度和制作成本。在实际应用中，该项目不仅支持实时流式生成反馈和多轮迭代优化，还提供了灵活的Web界面配置和标准化的API接口，适配性远优于传统动画制作软件；特别是通过支持多种AI大模型和多格式导出功能，有效解决了不同场景下的内容创作需求，HTML5交互式动画适合网页展示，MP4视频适合课程录制和视频平台发布，GIF动图适合公众号文章和PPT演示。同时，方案具备良好的扩展性——小伙伴们可以基于此扩展更多应用场景，如企业产品演示动画、医疗健康科普内容、科技原理讲解视频、编程教程可视化、学术论文配图动画等，进一步发挥AI动画生成在在线教育、企业培训、知识付费等领域的应用价值。感兴趣的小伙伴可以按照文中提供的步骤进行实践，根据实际教学内容调整动画风格、时长、导出格式等参数，甚至可以通过API接口实现批量生成、自动化处理等高级功能。今天的分享就到这里结束了，我们下一篇文章见。

## 项目资源

**GitHub地址**: https://github.com/wwwzhouhui/in_animation

觉得项目不错可以点个Star支持作者。

**在线演示**: 项目提供本地部署方案，部署完成后在 http://localhost:8000 体验

**技术文档**: 查看项目README获取详细技术文档和API说明

**推荐模型**:
- 智谱AI (glm-4): https://open.bigmodel.cn/
- DeepSeek (deepseek-chat): https://platform.deepseek.com/
- 阿里通义 (qwen-plus): https://dashscope.aliyun.com/

**附件代码**
包含配置文件示例、API调用脚本、批量生成工具
网盘分享: in_animation_tools.zip
链接: https://pan.baidu.com/s/1example123456 提取码: ia01

**相关教程**:
- Docker快速入门指南
- AI大模型API申请教程
- 教学动画制作最佳实践

#首发于魔搭研习社
