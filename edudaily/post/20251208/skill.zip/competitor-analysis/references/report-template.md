# Competitive Brief Template

## Executive summary

- Market/category:
- Scope and timeframe:
- Bottom line:
- Highest-priority opportunity:
- Highest-priority threat:

## Competitor landscape

| Type | Competitors | Why they matter |
|---|---|---|
| Direct |  |  |
| Indirect |  |  |
| Adjacent |  |  |
| Emerging |  |  |

## Competitive matrix

| Dimension | Us | Competitor 1 | Competitor 2 | Competitor 3 | Implication |
|---|---|---|---|---|---|
| Segment |  |  |  |  |  |
| Positioning |  |  |  |  |  |
| Core capabilities |  |  |  |  |  |
| Pricing/packaging |  |  |  |  |  |
| Distribution/GTM |  |  |  |  |  |
| Proof/customer sentiment |  |  |  |  |  |
| Recent moves |  |  |  |  |  |

## Strategic implications

- Differentiation opportunities:
- Product gaps:
- Pricing/packaging opportunities:
- Sales/marketing implications:
- Risks to monitor:

## Recommendations

| Priority | Action | Owner | Impact | Confidence | Evidence |
|---|---|---|---|---|---|
| P0 |  |  |  |  |  |
| P1 |  |  |  |  |  |
| P2 |  |  |  |  |  |

## Assumptions and evidence gaps

- Assumptions:
- Unknowns:
- Recommended follow-up research:
