# Competitive Research Checklist

Use this reference when the task requires deeper research.

## Primary public sources

- Company website, product pages, docs, changelog, pricing, security/compliance pages
- App stores, marketplace listings, integrations directories
- Public filings, investor decks, funding announcements, acquisition announcements
- Press releases, official blogs, webinars, conference talks
- Case studies, customer logos, partner pages

## Market and customer signal sources

- Review sites such as G2, Capterra, Trustpilot, Gartner Peer Insights, app stores
- Social media, communities, forums, Reddit/Hacker News/Product Hunt where relevant
- Job postings for roadmap and GTM signals
- SEO/content tools when available, otherwise SERP inspection and content inventory
- Analyst reports only when accessible and current

## Internal sources when available

- Win/loss notes, CRM excerpts, sales call summaries, customer interviews
- Product roadmap, support tickets, churn reasons, NPS/CSAT comments
- Sales enablement decks, objection handling, pricing/packaging notes

## Evidence grading

- **A**: primary source, current, directly supports claim
- **B**: credible third-party source or corroborated customer/review pattern
- **C**: indirect signal such as hiring, content activity, anecdotal review trend
- **D**: weak, stale, or uncorroborated; use only as hypothesis
