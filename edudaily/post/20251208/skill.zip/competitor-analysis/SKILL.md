---
name: competitor-analysis
description: analyze competitive landscapes and produce practical competitor intelligence. use when the user asks for competitor analysis, competitive research, market positioning, feature/pricing comparison, swot, differentiation, market-entry planning, win/loss insights, seo/aso competitor review, or executive-ready competitive briefs. this skill can use web search for current public data and connected/internal sources when the user asks about their company, product, customers, sales context, or internal roadmap.
---

# Competitor Analysis

## Core principles

Produce decision-grade competitive intelligence, not a generic comparison. Anchor claims in current evidence, separate facts from judgment, and convert findings into product, marketing, sales, and GTM actions.

Always make the scope explicit: market/category, geography, segment, buyer, timeframe, and whether the analysis is for product strategy, positioning, sales enablement, pricing, investment, SEO/content, ASO/app-store, or board/executive use.

## Default workflow

1. **Clarify the analysis frame only when missing details materially change the answer.** If enough information exists, proceed with reasonable assumptions and state them.
2. **Identify competitor types.** Include direct, indirect, adjacent, substitute, and emerging competitors. Do not limit the analysis to obvious feature-for-feature rivals.
3. **Collect evidence.** Prefer primary/current sources: official product pages, pricing pages, release notes, docs, filings, job postings, customer reviews, case studies, app-store listings, marketplace profiles, credible news, and internal sources the user has access to.
4. **Normalize comparison criteria.** Use the same dimensions for every competitor: target customer, positioning, core capabilities, pricing/packaging, distribution/GTM, proof points, integrations/ecosystem, customer sentiment, recent moves, and likely strategy.
5. **Score only where useful.** Use a transparent 1-5 or 1-10 scale. Explain scoring logic and avoid false precision when evidence is thin.
6. **Synthesize implications.** Highlight market gaps, defensible differentiation, vulnerabilities, potential threats, and strategic options.
7. **Recommend actions.** Prioritize recommendations by impact, urgency, confidence, and owner: product, marketing, sales, partnerships, pricing, customer success, or leadership.

## Evidence and tool use

- Use web search for current competitor data, pricing, product changes, funding, leadership, launches, reviews, and market news.
- Use internal/connected sources when the user asks about their own company, product, roadmap, customers, sales notes, win/loss, research, or internal projects.
- For recent or volatile information, cite source dates and distinguish current facts from historical context.
- If sources conflict, call out the discrepancy and use the more authoritative/current source as primary.
- Never invent metrics such as market share, revenue, NPS, retention, review counts, or pricing. Mark unknowns explicitly.

## Output formats

Choose the smallest format that fits the request.

### Fast scan

Use for quick requests or early exploration:

1. **Bottom line**: 2-4 sentence conclusion.
2. **Competitor set**: direct, indirect, adjacent, emerging.
3. **Key differences**: product, pricing, positioning, GTM.
4. **Opportunities**: 3-5 actionable openings.
5. **Risks**: 3-5 threats or watch items.
6. **Next checks**: missing evidence or follow-up research.

### Executive brief

Use for strategy, leadership, board, or investor contexts:

1. **Executive summary**
2. **Market/category definition**
3. **Competitor landscape map**
4. **Competitive matrix**
5. **Positioning analysis**
6. **Pricing/packaging analysis**
7. **Recent moves and signals**
8. **SWOT or strategic implications**
9. **Recommended actions** with impact, confidence, and owner
10. **Source notes and assumptions**

### Competitive matrix

Use this structure unless the user provides custom columns:

| Dimension | Our product | Competitor A | Competitor B | Competitor C | Implication |
|---|---:|---:|---:|---:|---|
| Target customer |  |  |  |  |  |
| Core use case |  |  |  |  |  |
| Positioning |  |  |  |  |  |
| Key features |  |  |  |  |  |
| Pricing/packaging |  |  |  |  |  |
| Integrations/ecosystem |  |  |  |  |  |
| Distribution/GTM |  |  |  |  |  |
| Customer sentiment |  |  |  |  |  |
| Recent moves |  |  |  |  |  |
| Strengths |  |  |  |  |  |
| Weaknesses |  |  |  |  |  |

## Analysis lenses

Use these lenses selectively:

- **Product**: feature breadth/depth, UX, integrations, reliability, data/AI capabilities, implementation effort, admin/security/compliance.
- **Market**: target segments, geography, vertical focus, brand awareness, ecosystem, channel strength.
- **Pricing**: free tier, entry price, packaging gates, usage limits, enterprise pricing signals, discounting, switching costs.
- **GTM**: sales motion, PLG/SLG balance, partner channel, content strategy, events, communities, marketplaces.
- **Customer proof**: case studies, reviews, churn indicators, complaints, adoption signals, support quality.
- **Momentum**: hiring, funding, acquisitions, release cadence, partnerships, analyst coverage, leadership changes.
- **SEO/GEO/content**: ranking pages, content clusters, backlink/citation patterns, AI answer visibility, keyword gaps.
- **ASO/app-store**: metadata, ratings/reviews, screenshots, localization, keyword targeting, update cadence.

## Recommendation rules

- Make recommendations specific enough to execute: action, rationale, expected outcome, owner, timeframe, and confidence.
- Separate short-term defensive moves from long-term strategic bets.
- Avoid blindly copying competitors. Prefer differentiation, wedge expansion, sales enablement, pricing clarity, or customer proof improvements.
- Include a monitoring plan when the market is dynamic: what to watch, where to watch, and cadence.

## Quality checks

Before finalizing:

- Confirm all competitor claims are supported or labeled as assumptions.
- Include non-obvious competitors and substitutes.
- Include recent moves when recency matters.
- Show implications for the user's strategy, not just observations.
- State confidence levels and evidence gaps.
- Keep confidential/internal context separate from public competitor evidence when relevant.
