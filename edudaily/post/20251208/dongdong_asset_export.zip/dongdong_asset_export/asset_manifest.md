# Asset Manifest

Source image used: `health_app_ui_design_showcase.png`

## Exported transparent PNG assets

| File name | Category | Usage | Size | Format |
|---|---|---|---:|---|
| mascot_dongdong_header.png | Mascot | Primary Dongdong mascot from the top header, suitable for brand header / splash / onboarding accent. | 69x68 | PNG (transparent background) |
| mascot_dongdong_footer.png | Mascot | Secondary Dongdong mascot from the footer, suitable for page footer or empty-state decoration. | 58x65 | PNG (transparent background) |
| mascot_dongdong_smile.png | Mascot | Large smiling Dongdong mascot, suitable for encouragement, success, and celebration states. | 88x73 | PNG (transparent background) |
| mascot_dongdong_peek.png | Mascot | Peeking Dongdong mascot, suitable for progress cards or level widgets. | 55x54 | PNG (transparent background) |
| mascot_dongdong_wave.png | Mascot | Small waving Dongdong mascot, suitable for helper tips, nudges, and compact status cards. | 42x40 | PNG (transparent background) |
| mascot_dongdong_streak.png | Mascot | Mini Dongdong streak mascot with confetti accent, suitable for streak / reward surfaces. | 48x49 | PNG (transparent background) |
| illustration_evening_recipe_scene.png | Illustration | Illustrated evening recipe scene, suitable for smart recipe modules and care-plan cards. | 146x79 | PNG (transparent background) |
| illustration_running_plan_scene.png | Illustration | Running plan illustration, suitable for exercise-plan modules and campaign banners. | 141x136 | PNG (transparent background) |
| illustration_hydration_glass.png | Illustration | Hydration glass illustration, suitable for water reminder / water intake cards. | 66x96 | PNG (transparent background) |
| illustration_breathing_ring.png | Illustration | Breathing training ring illustration, suitable for breathwork / meditation modules. | 103x78 | PNG (transparent background) |
| illustration_city_walk_map.png | Illustration | City walk map illustration, suitable for step challenge / walking challenge cards. | 142x91 | PNG (transparent background) |
| component_health_book_cover_card.png | Component | Health Book cover-style card component, suitable for article preview or content entry card. | 124x88 | PNG (transparent background) |
| badge_early_riser.png | Badge | Achievement badge for early-riser type rewards. | 42x40 | PNG (transparent background) |
| badge_sleep_expert.png | Badge | Achievement badge for sleep-expert type rewards. | 40x40 | PNG (transparent background) |
| badge_steps_champion.png | Badge | Achievement badge for steps-champion type rewards. | 40x40 | PNG (transparent background) |
| emotion_face_happy.png | Status | Happy emotion face icon, suitable for mood logging. | 31x41 | PNG (transparent background) |
| emotion_face_calm.png | Status | Calm emotion face icon, suitable for mood logging. | 35x38 | PNG (transparent background) |
| emotion_face_tired.png | Status | Tired emotion face icon, suitable for mood logging. | 33x36 | PNG (transparent background) |
| emotion_face_anxious.png | Status | Anxious emotion face icon, suitable for mood logging. | 33x35 | PNG (transparent background) |

## Code-friendly elements not exported

| Element | Why not exported |
|---|---|
| primary_green_button | Simple rounded CTA button; better implemented in code for scalable states and text replacement. |
| secondary_button / pill_button | Simple button shape; better implemented in code. |
| progress_ring / score_ring | Vector ring component; better implemented in code for dynamic values and animation. |
| progress_bar / step_bar | Basic progress component; better implemented in code. |
| line_chart / trend_chart | Data-driven chart; should be generated in code for live values. |
| gauge_arc / pressure_meter | Data-driven meter; should be rendered in code or SVG. |
| toggle_switch | Standard switch; better implemented in code for interactive states. |
| tab_bar / nav_bar | Reusable navigation structure; better implemented in code. |
| status_chip / feature_chip | Simple pill tags; better implemented in code. |
| calendar_dots / streak_dots | Stateful indicators; better implemented in code. |
| simple_icons such as heart, check, leaf, shield, person | Basic vector icons; better handled by icon font / SVG set in code. |
| generic_cards and list rows | Layout containers; better implemented in code for responsiveness. |
