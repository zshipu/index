# UI Asset Inventory

Source image: `health_app_ui_design_showcase.png`

## 1. Exported assets

| Asset name | Type | Suggested format | Export size | Usage | Transparent background | Remarks |
|---|---|---|---:|---|---|---|
| mascot_dongdong_header.png | single_asset | PNG | 69x68 | Header mascot / brand mark decoration | yes | Best used as standalone mascot asset. |
| mascot_dongdong_footer.png | single_asset | PNG | 58x65 | Footer mascot / bottom decoration | yes | Standalone mascot variation. |
| mascot_dongdong_smile.png | single_asset | PNG | 88x73 | Large positive feedback mascot for success / encouragement | yes | Suitable for success / onboarding / empty states. |
| mascot_dongdong_peek.png | single_asset | PNG | 55x54 | Peeking mascot for progress or status cards | yes | Useful in card corners or progress modules. |
| mascot_dongdong_wave.png | single_asset | PNG | 42x40 | Compact waving mascot for helper tips | yes | Tiny decorative mascot. |
| mascot_dongdong_streak.png | single_asset | PNG | 48x49 | Mascot with confetti for streak and reward surfaces | yes | Use in streak / reward modules. |
| illustration_evening_recipe_scene.png | single_asset | PNG | 146x79 | Recipe illustration for evening care / sleep recipe card | yes | Bitmap illustration with gradients. |
| illustration_running_plan_scene.png | single_asset | PNG | 141x136 | Exercise / running plan illustration | yes | Bitmap illustration with shadow and background. |
| illustration_hydration_glass.png | single_asset | PNG | 66x96 | Hydration / water reminder illustration | yes | Use inside hydration cards or reminders. |
| illustration_breathing_ring.png | single_asset | PNG | 103x78 | Breathing training visual ring | yes | Can be used as a combined component preview. |
| illustration_city_walk_map.png | single_asset | PNG | 142x91 | Walking / steps challenge map illustration | yes | Bitmap map scene. |
| component_health_book_cover_card.png | component | PNG | 124x88 | Health Book preview card as a combined component | yes | Exported as combined component because text + illustration are tightly integrated in the raster source. |
| badge_early_riser.png | single_asset | PNG | 42x40 | Achievement badge for early-riser milestone | yes | Could be redrawn as SVG later. |
| badge_sleep_expert.png | single_asset | PNG | 40x40 | Achievement badge for sleep-expert milestone | yes | Could be redrawn as SVG later. |
| badge_steps_champion.png | single_asset | PNG | 40x40 | Achievement badge for steps-champion milestone | yes | Could be redrawn as SVG later. |
| emotion_face_happy.png | single_asset | PNG | 31x41 | Mood selector icon - happy | yes | Small status icon. |
| emotion_face_calm.png | single_asset | PNG | 35x38 | Mood selector icon - calm | yes | Small status icon. |
| emotion_face_tired.png | single_asset | PNG | 33x36 | Mood selector icon - tired | yes | Small status icon. |
| emotion_face_anxious.png | single_asset | PNG | 33x35 | Mood selector icon - anxious | yes | Small status icon. |

## 2. Elements identified but not recommended for slicing

| Asset name | Type | Suggested implementation | Usage | Remarks |
|---|---|---|---|---|
| btn_primary_default | button | SVG/CODE | Primary CTA button | Do not slice. Simple rounded rectangle + text; implement by code for scalability and states. |
| btn_primary_disabled | button | SVG/CODE | Disabled CTA button | Do not slice. Implement by code. |
| btn_secondary_default | button | SVG/CODE | Secondary button | Do not slice. Implement by code. |
| btn_secondary_disabled | button | SVG/CODE | Disabled secondary button | Do not slice. Implement by code. |
| tab_item_default | navigation | SVG/CODE | Default tab item | Do not slice. Use code + icon set. |
| tab_item_active | navigation | SVG/CODE | Active tab item | Do not slice. Use code + icon set. |
| nav_icon_home | icon | SVG | Home navigation icon | Recommend redrawing as SVG from design source rather than raster cutting. |
| nav_icon_book | icon | SVG | Book / Health Book navigation icon | Recommend SVG redraw. |
| nav_icon_profile | icon | SVG | Profile navigation icon | Recommend SVG redraw. |
| icon_leaf | icon | SVG | Leaf feature tag icon | Recommend code / SVG. |
| icon_shield | icon | SVG | Privacy / shield icon | Recommend code / SVG. |
| icon_star | icon | SVG | Gamification icon | Recommend code / SVG. |
| progress_ring | data_component | CODE/SVG | Dynamic score / ring charts | Do not slice. Render dynamically for values and animation. |
| progress_bar | data_component | CODE/SVG | Progress bars and completion bars | Do not slice. Render in code. |
| line_chart | data_component | CODE/SVG | Trend line charts | Do not slice. Render in code for live data. |
| gauge_arc | data_component | CODE/SVG | Pressure / gauge arc charts | Do not slice. Render in code. |
| list_card_container | container | CODE | Simple card backgrounds with radius and shadow | Do not slice. Use code. |
| divider_line | divider | CODE | Thin divider line | Do not slice. Use code. |
| tag_chip_default | chip | CODE | Feature / category chip | Do not slice. Use code. |
| toggle_switch | control | CODE | Toggle switch | Do not slice. Use code for interactive states. |
| avatar_row_item | list_item | CODE | Family-share row / avatar list item | Container and text should be coded; avatars supplied separately if needed. |
